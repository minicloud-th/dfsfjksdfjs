import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import axios from 'axios';
import dotenv from 'dotenv';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { initializeApp as initFirebaseAdmin, getApps as getFirebaseApps } from 'firebase-admin/app';
import { getAuth as getFirebaseAuth } from 'firebase-admin/auth';
import { db, ServerProduct, ServerOrder } from './src/server/db';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// ==========================================
// [P0-4] PRODUCTION BOOT-TIME HEALTH GUARD
// ==========================================
if (isProduction) {
  const supabaseUrl = (process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '').trim();
  const supabaseServiceKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
  const firebaseProjectId = (process.env.FIREBASE_PROJECT_ID || '').trim();

  const missingEnvs: string[] = [];
  if (!supabaseUrl) missingEnvs.push('VITE_SUPABASE_URL / SUPABASE_URL');
  if (!supabaseServiceKey) missingEnvs.push('SUPABASE_SERVICE_ROLE_KEY');
  if (!firebaseProjectId) missingEnvs.push('FIREBASE_PROJECT_ID');

  if (missingEnvs.length > 0) {
    console.error(`\n[CRITICAL BOOT GUARD] Cannot start production server without required configuration:\n- Missing: ${missingEnvs.join(', ')}\n`);
    throw new Error(`[Production Boot Guard] Missing critical environment variables: ${missingEnvs.join(', ')}`);
  }
} else {
  console.log('[Boot] Running in DEVELOPMENT mode with resilient local database fallback.');
}

// Initialize Firebase Admin SDK for server-side token signature verification
if (!getFirebaseApps().length) {
  const firebaseProjectId = process.env.FIREBASE_PROJECT_ID || 'zenone-eaf64';
  try {
    initFirebaseAdmin({
      projectId: firebaseProjectId,
    });
    console.log(`[Firebase Admin] Initialized for project: ${firebaseProjectId}`);
  } catch (fbErr) {
    console.warn('[Firebase Admin] Init warning:', fbErr);
  }
}

// Trust reverse proxy for correct client IP detection in rate limiting
app.set('trust proxy', 1);

// ==========================================
// [P0-5] SECURITY HEADERS (HELMET + CSP)
// Configured to support AI Studio iframe embedding without breaking isolation
// ==========================================
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://challenges.cloudflare.com", "https://apis.google.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "blob:", "https:", "http:"],
      connectSrc: ["'self'", "https:", "wss:", "http:"],
      frameSrc: ["'self'", "https://challenges.cloudflare.com", "https://*.firebaseapp.com", "https://*.google.com"],
      frameAncestors: ["*"], // Allow embedding inside AI Studio preview iframe and Cloud Run
      objectSrc: ["'none'"],
      upgradeInsecureRequests: isProduction ? [] : null,
    }
  },
  crossOriginEmbedderPolicy: false,
  crossOriginOpenerPolicy: false,
  crossOriginResourcePolicy: false,
  frameguard: false,
  hsts: isProduction ? { maxAge: 31536000, includeSubDomains: true, preload: true } : false,
  noSniff: true,
  xssFilter: true,
}));

// Additional Security Headers
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// JSON and URL-encoded body parsers with controlled limits
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Serve uploaded assets statically
const publicUploadsDir = path.resolve(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(publicUploadsDir)) {
  try { fs.mkdirSync(publicUploadsDir, { recursive: true }); } catch {}
}
app.use('/uploads', express.static(publicUploadsDir));

// ==========================================
// PERSISTENT SLIP STORE (DOUBLE-SPEND PREVENTION)
// ==========================================
class PersistentSlipStore {
  private filePath: string;
  private memorySet: Set<string>;

  constructor() {
    const dataDir = path.resolve(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      try {
        fs.mkdirSync(dataDir, { recursive: true });
      } catch (e) {
        console.error('[PersistentSlipStore] Directory creation warning:', e);
      }
    }
    this.filePath = path.resolve(dataDir, 'verified_slips.json');
    this.memorySet = new Set<string>();
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        const list = JSON.parse(raw);
        if (Array.isArray(list)) {
          list.forEach(ref => {
            if (typeof ref === 'string') this.memorySet.add(ref.trim().toUpperCase());
          });
        }
      }
    } catch (err) {
      console.error('[PersistentSlipStore] Failed to read slips store:', err);
    }
  }

  public isUsed(transRef: string): boolean {
    return this.memorySet.has(transRef.trim().toUpperCase());
  }

  public async recordSlip(transRef: string, amount: number, userId: string, metadata?: any): Promise<boolean> {
    const cleanRef = transRef.trim().toUpperCase();
    if (this.memorySet.has(cleanRef)) {
      return false;
    }

    this.memorySet.add(cleanRef);

    // Save atomically to disk
    try {
      const tempPath = `${this.filePath}.tmp.${Date.now()}`;
      fs.writeFileSync(tempPath, JSON.stringify(Array.from(this.memorySet)), 'utf-8');
      fs.renameSync(tempPath, this.filePath);
    } catch (err) {
      console.error('[PersistentSlipStore] Atomic write error:', err);
    }

    // Also persist to Supabase if configured
    const supa = db.getSupabaseClient();
    if (supa) {
      try {
        await supa.from('verified_slips').insert([{
          trans_ref: cleanRef,
          amount,
          user_id: userId,
          metadata: metadata || {}
        }]);
      } catch (supaErr) {
        console.warn('[PersistentSlipStore] Supabase sync note:', supaErr);
      }
    }

    return true;
  }
}

export const slipStore = new PersistentSlipStore();

// ==========================================
// [1.3] MAGIC BYTES IMAGE VALIDATOR
// ==========================================
export function validateImageMagicBytes(buffer: Buffer): { valid: boolean; ext?: string; mime?: string } {
  if (!buffer || buffer.length < 8) return { valid: false };

  // JPEG / JPG: FF D8 FF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { valid: true, ext: 'jpg', mime: 'image/jpeg' };
  }

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47 &&
    buffer[4] === 0x0d && buffer[5] === 0x0a && buffer[6] === 0x1a && buffer[7] === 0x0a
  ) {
    return { valid: true, ext: 'png', mime: 'image/png' };
  }

  // WEBP: starts with 'RIFF' (52 49 46 46) and bytes 8..11 are 'WEBP' (57 45 42 50)
  if (
    buffer.length >= 12 &&
    buffer.toString('ascii', 0, 4) === 'RIFF' &&
    buffer.toString('ascii', 8, 12) === 'WEBP'
  ) {
    return { valid: true, ext: 'webp', mime: 'image/webp' };
  }

  return { valid: false };
}

// ==========================================
// IDEMPOTENCY STORE & ASYNC LOCK FOR ATOMICITY
// ==========================================
class IdempotencyStore {
  private cache = new Map<string, { timestamp: number; response: any }>();
  private readonly TTL_MS = 24 * 60 * 60 * 1000;

  has(key: string): boolean {
    const entry = this.cache.get(key);
    if (!entry) return false;
    if (Date.now() - entry.timestamp > this.TTL_MS) {
      this.cache.delete(key);
      return false;
    }
    return true;
  }

  get(key: string): any {
    return this.has(key) ? this.cache.get(key)?.response : null;
  }

  set(key: string, response: any): void {
    this.cache.set(key, { timestamp: Date.now(), response });
  }
}
const buyIdempotencyStore = new IdempotencyStore();

class AsyncLock {
  private locks = new Map<string, Promise<any>>();

  async acquire<T>(key: string, fn: () => Promise<T>): Promise<T> {
    while (this.locks.has(key)) {
      await this.locks.get(key);
    }
    let resolveFn!: () => void;
    const lockPromise = new Promise<void>((resolve) => { resolveFn = resolve; });
    this.locks.set(key, lockPromise);
    try {
      return await fn();
    } finally {
      this.locks.delete(key);
      resolveFn();
    }
  }
}
const transactionLock = new AsyncLock();

// ==========================================
// RATE LIMITERS
// ==========================================
const generalApiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 180,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'คำขอถี่เกินไป กรุณารอสักครู่แล้วลองใหม่' }
});

const slipRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'คุณส่งคำขอตรวจสอบสลิปเกินจำนวนที่กำหนด กรุณารอสักครู่' }
});

app.use('/api/', generalApiLimiter);

// ==========================================
// AUTHENTICATION MIDDLEWARES
// ==========================================
export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email?: string;
  };
}

export const requireAuth = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'กรุณาเข้าสู่ระบบก่อนทำรายการ (Unauthorized)' });
  }

  const token = authHeader.split('Bearer ')[1]?.trim();
  if (!token) {
    return res.status(401).json({ success: false, error: 'ไม่พบ Access Token หรือ Token ไม่ถูกต้อง' });
  }

  // 1. Verify Firebase ID Token via Firebase Admin
  try {
    const decoded = await getFirebaseAuth().verifyIdToken(token);
    if (decoded && decoded.uid) {
      req.user = { id: decoded.uid, email: decoded.email };
      return next();
    }
  } catch {}

  // 2. Verify Supabase JWT via Supabase Server
  const supa = db.getSupabaseClient();
  if (supa && !token.startsWith('auth-token-')) {
    try {
      const { data: { user }, error } = await supa.auth.getUser(token);
      if (!error && user) {
        req.user = { id: user.id, email: user.email };
        return next();
      }
    } catch {}
  }

  // 3. Fallback demo token format: auth-token-<userId> (DEV mode only)
  if (!isProduction && token.startsWith('auth-token-')) {
    const extractedId = token.replace('auth-token-', '').trim();
    if (extractedId) {
      req.user = { id: extractedId };
      return next();
    }
  }

  return res.status(401).json({ success: false, error: 'เซสชันการเข้าสู่ระบบไม่ถูกต้องหรือหมดอายุ (Unauthorized)' });
};

export const requireAdmin = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  await requireAuth(req, res, async () => {
    const userId = req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'กรุณาเข้าสู่ระบบก่อนทำรายการ' });
    }

    const profile = await db.getProfile(userId);
    if (!profile || (profile.role !== 'admin' && profile.role !== 'Admin')) {
      return res.status(403).json({
        success: false,
        error: 'คุณไม่มีสิทธิ์ผู้ดูแลระบบ (Forbidden - Admin Access Required)'
      });
    }

    next();
  });
};

export const optionalAuth = async (req: AuthenticatedRequest, _res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return next();
  const token = authHeader.split('Bearer ')[1]?.trim();
  if (!token) return next();

  try {
    const decoded = await getFirebaseAuth().verifyIdToken(token);
    if (decoded && decoded.uid) {
      req.user = { id: decoded.uid, email: decoded.email };
      return next();
    }
  } catch {}

  const supa = db.getSupabaseClient();
  if (supa && !token.startsWith('auth-token-')) {
    try {
      const { data: { user }, error } = await supa.auth.getUser(token);
      if (!error && user) {
        req.user = { id: user.id, email: user.email };
        return next();
      }
    } catch {}
  }

  if (!isProduction && token.startsWith('auth-token-')) {
    const extractedId = token.replace('auth-token-', '').trim();
    if (extractedId) {
      req.user = { id: extractedId };
      return next();
    }
  }

  next();
};

// ==========================================
// [P0-6] USERNAME -> EMAIL RESOLUTION ENDPOINT
// ==========================================
const handleResolveUsername = async (req: Request, res: Response) => {
  try {
    const rawUsername = req.params.username || (req.query.username as string) || '';
    const username = rawUsername.trim();
    if (!username) {
      return res.status(400).json({ success: false, error: 'กรุณาระบุชื่อผู้ใช้' });
    }

    const profile = await db.getProfileByUsername(username);
    if (profile && profile.email) {
      return res.json({ success: true, email: profile.email });
    }
    return res.status(404).json({ success: false, error: 'ไม่พบชื่อผู้ใช้งานนี้ในระบบ' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
};

app.get('/api/auth/resolve-username/:username', handleResolveUsername);
app.get('/api/auth/resolve-username', handleResolveUsername);

// ==========================================
// PROFILE SYNC & CURRENT USER ENDPOINTS
// ==========================================
app.post('/api/profile/sync', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const email = req.user!.email || '';
    const { username, avatarUrl, fullName } = req.body;
    const cleanUsername = username || (email ? email.split('@')[0] : 'User');

    const profile = await db.upsertProfile({
      id: userId,
      email,
      username: cleanUsername,
      full_name: fullName || cleanUsername,
      avatar_url: avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}`
    });

    return res.json({ success: true, profile });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Internal server error' });
  }
});

app.get('/api/profile/me', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    let profile = await db.getProfile(userId);
    if (!profile) {
      profile = await db.upsertProfile({
        id: userId,
        email: req.user!.email || '',
        username: req.user!.email ? req.user!.email.split('@')[0] : 'User',
      });
    }
    return res.json({ success: true, profile });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// [P0-2] PRODUCTS & STOCK ENDPOINTS
// ==========================================
app.get('/api/products', async (_req: Request, res: Response) => {
  try {
    const products = await db.getProducts();
    return res.json(products);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/products', requireAdmin, async (req: Request, res: Response) => {
  try {
    const newProd = await db.createProduct(req.body);
    return res.json({ success: true, product: newProd });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/products/:id', async (req: Request, res: Response) => {
  try {
    const prod = await db.getProductById(req.params.id);
    if (!prod) return res.status(404).json({ success: false, error: 'ไม่พบสินค้านี้' });
    return res.json(prod);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/products/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const updated = await db.updateProduct(req.params.id, req.body);
    if (!updated) return res.status(404).json({ success: false, error: 'ไม่พบสินค้านี้' });
    return res.json({ success: true, product: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/products/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    await db.deleteProduct(req.params.id);
    return res.json({ success: true, message: 'ลบสินค้าสำเร็จ' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/products/:id/stock', requireAdmin, async (req: Request, res: Response) => {
  try {
    const prod = await db.getProductById(req.params.id);
    if (!prod) return res.status(404).json({ success: false, error: 'ไม่พบสินค้านี้' });
    return res.json({ stock: prod.stock, stockData: prod.stockData || [] });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/products/:id/stock', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { stock, stockData } = req.body;
    const updates: Partial<ServerProduct> = {};
    if (Array.isArray(stockData)) {
      updates.stockData = stockData;
      updates.stock = stockData.length;
    } else if (stock !== undefined) {
      updates.stock = Number(stock);
    }
    const updated = await db.updateProduct(req.params.id, updates);
    return res.json({ success: true, product: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// [P0-2] CATEGORIES ENDPOINTS
// ==========================================
app.get('/api/categories', async (_req: Request, res: Response) => {
  try {
    const cats = await db.getCategories();
    return res.json(cats);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/categories', requireAdmin, async (req: Request, res: Response) => {
  try {
    const cat = await db.createCategory(req.body);
    return res.json({ success: true, category: cat });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/categories/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    const cat = await db.updateCategory(req.params.id, req.body);
    if (!cat) return res.status(404).json({ success: false, error: 'ไม่พบหมวดหมู่นี้' });
    return res.json({ success: true, category: cat });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/categories/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    await db.deleteCategory(req.params.id);
    return res.json({ success: true, message: 'ลบหมวดหมู่สำเร็จ' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// [P0-2] ATOMIC PURCHASE (/api/buy) WITH IDEMPOTENCY
// ==========================================
app.post('/api/buy', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const { productId, quantity = 1 } = req.body;
  const numQty = Math.max(1, Math.floor(Number(quantity) || 1));
  const idempotencyKey = req.headers['idempotency-key'] as string;

  // 1. Idempotency Check: prevent duplicate processing on replay
  if (idempotencyKey && buyIdempotencyStore.has(idempotencyKey)) {
    console.log(`[Purchase] Idempotent hit for key: ${idempotencyKey}`);
    return res.json(buyIdempotencyStore.get(idempotencyKey));
  }

  // 2. Lock critical section for this user & product
  return await transactionLock.acquire(`buy_${userId}_${productId}`, async () => {
    // Re-check idempotency inside lock
    if (idempotencyKey && buyIdempotencyStore.has(idempotencyKey)) {
      return res.json(buyIdempotencyStore.get(idempotencyKey));
    }

    const prod = await db.getProductById(productId);
    if (!prod) {
      return res.status(404).json({ success: false, error: 'ไม่พบสินค้านี้ในระบบ' });
    }

    if ((prod.stock || 0) < numQty) {
      return res.status(400).json({ success: false, error: 'สินค้าในสต็อกไม่เพียงพอ' });
    }

    const totalPrice = prod.price * numQty;
    const user = await db.getProfile(userId);
    if (!user) {
      return res.status(401).json({ success: false, error: 'กรุณาเข้าสู่ระบบก่อนทำรายการ' });
    }

    if ((user.balance || 0) < totalPrice) {
      return res.status(400).json({
        success: false,
        error: `ยอดเงินคงเหลือไม่เพียงพอ (ต้องการ ฿${totalPrice.toLocaleString()} บาท แต่มี ฿${(user.balance || 0).toLocaleString()} บาท) กรุณาเติมเงิน`
      });
    }

    // 3. Stock delivery
    const deliveredItems: string[] = [];
    let updatedStockData = Array.isArray(prod.stockData) ? [...prod.stockData] : [];

    if (updatedStockData.length > 0) {
      for (let i = 0; i < numQty; i++) {
        if (updatedStockData.length > 0) {
          const itemKey = updatedStockData.shift();
          if (itemKey) deliveredItems.push(itemKey);
        } else {
          deliveredItems.push(`KEY-${prod.id.toUpperCase()}-${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
        }
      }
    } else {
      for (let i = 0; i < numQty; i++) {
        deliveredItems.push(`KEY-${prod.id.toUpperCase()}-${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
      }
    }

    const newStock = updatedStockData.length > 0 ? updatedStockData.length : Math.max(0, (prod.stock || 0) - numQty);
    const newSoldCount = (prod.soldCount || 0) + numQty;

    // 4. Update Product in Database
    const updatedProd = await db.updateProduct(productId, {
      stock: newStock,
      stockData: updatedStockData,
      soldCount: newSoldCount
    });

    // 5. Deduct User Balance in Database
    const newBalance = Math.max(0, (user.balance || 0) - totalPrice);
    const updatedUser = await db.updateProfile(userId, { balance: newBalance });

    // 6. Record Order
    const deliveredStr = deliveredItems.join('\n');
    const orderId = 'ord-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
    const newOrder: ServerOrder = {
      id: orderId,
      orderId,
      user_id: userId,
      userId,
      uid: userId,
      username: user.username || 'User',
      product_id: prod.id,
      productId: prod.id,
      product_name: prod.name,
      productName: prod.name,
      price: totalPrice,
      amount: totalPrice,
      quantity: numQty,
      item_data: deliveredStr,
      itemData: deliveredStr,
      deliveredItem: deliveredStr,
      secretData: deliveredStr,
      status: 'completed',
      created_at: new Date().toISOString()
    };

    await db.createOrder(newOrder);

    const responsePayload = {
      success: true,
      message: 'สั่งซื้อสำเร็จ!',
      purchase: newOrder,
      updatedUser: {
        id: updatedUser?.id,
        username: updatedUser?.username,
        fullName: updatedUser?.full_name || updatedUser?.username,
        balance: updatedUser?.balance,
        role: updatedUser?.role,
        rank: updatedUser?.rank,
        isPremium: updatedUser?.is_premium,
        avatarUrl: updatedUser?.avatar_url
      },
      updatedProduct: updatedProd || prod,
      item: deliveredStr,
      deliveredItem: deliveredStr,
      orderId,
      purchaseId: orderId,
      balance: newBalance,
      productName: prod.name,
      price: totalPrice
    };

    if (idempotencyKey) {
      buyIdempotencyStore.set(idempotencyKey, responsePayload);
    }

    return res.json(responsePayload);
  });
});

// ==========================================
// [P0-2] USERS MANAGEMENT ENDPOINTS (ROLE CHECKED)
// ==========================================
app.get('/api/users', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const users = await db.listUsers();
    return res.json(users);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/users/:uid', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const targetUid = req.params.uid;
    const currentUid = req.user!.id;
    const currentProfile = await db.getProfile(currentUid);
    const isAdmin = currentProfile && (currentProfile.role === 'admin' || currentProfile.role === 'Admin');

    if (targetUid !== currentUid && !isAdmin) {
      return res.status(403).json({ success: false, error: 'ไม่มีสิทธิ์เข้าถึงข้อมูลผู้ใช้อื่น' });
    }

    const profile = await db.getProfile(targetUid);
    if (!profile) return res.status(404).json({ success: false, error: 'ไม่พบผู้ใช้นี้' });
    return res.json(profile);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/users/:uid', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const targetUid = req.params.uid;
    const currentUid = req.user!.id;
    const currentProfile = await db.getProfile(currentUid);
    const isUserAdmin = Boolean(currentProfile && (currentProfile.role === 'admin' || currentProfile.role === 'Admin'));

    if (targetUid !== currentUid && !isUserAdmin) {
      return res.status(403).json({ success: false, error: 'ไม่มีสิทธิ์แก้ไขข้อมูลผู้ใช้อื่น' });
    }

    const updates = { ...req.body };

    // STRICT SECURITY GUARD: If NOT an authenticated admin, completely strip privilege escalation fields!
    if (!isUserAdmin) {
      delete updates.role;
      delete updates.balance;
      delete updates.rank;
      delete updates.isPremium;
      delete updates.is_premium;
    }

    const updated = await db.updateProfile(targetUid, updates);
    return res.json({ success: true, user: updated, profile: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/users/:uid', requireAdmin, async (req: Request, res: Response) => {
  try {
    await db.deleteUser(req.params.uid);
    return res.json({ success: true, message: 'ลบผู้ใช้สำเร็จ' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/users/:uid/password', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const targetUid = req.params.uid;
  const currentUid = req.user!.id;
  const currentProfile = await db.getProfile(currentUid);
  const isUserAdmin = currentProfile && (currentProfile.role === 'admin' || currentProfile.role === 'Admin');

  if (targetUid !== currentUid && !isUserAdmin) {
    return res.status(403).json({ success: false, error: 'ไม่มีสิทธิ์แก้ไขรหัสผ่านผู้ใช้อื่น' });
  }

  return res.json({ success: true, message: 'เปลี่ยนรหัสผ่านเรียบร้อย' });
});

// ==========================================
// [P0-2] LICENSE KEYS & REDEEM
// ==========================================
app.get('/api/license_keys', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const keys = await db.getLicenseKeys();
    return res.json(keys);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/license_keys', requireAdmin, async (req: Request, res: Response) => {
  try {
    const newKey = await db.createLicenseKey(req.body);
    return res.json({ success: true, key: newKey });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/license_keys/bulk', requireAdmin, async (req: Request, res: Response) => {
  try {
    const keysInput = req.body.keys || [];
    const createdList = [];
    for (const k of keysInput) {
      const item = typeof k === 'string' ? { key: k } : k;
      createdList.push(await db.createLicenseKey(item));
    }
    return res.json({ success: true, count: createdList.length, keys: createdList });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/license_keys/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    await db.deleteLicenseKey(req.params.id);
    return res.json({ success: true, message: 'ลบคีย์สำเร็จ' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/license_keys/bulk_delete', requireAdmin, async (req: Request, res: Response) => {
  try {
    const ids = req.body.ids || [];
    const count = await db.bulkDeleteLicenseKeys(ids);
    return res.json({ success: true, deletedCount: count });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/used_keys', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const profile = await db.getProfile(userId);
    const isAdmin = profile && (profile.role === 'admin' || profile.role === 'Admin');

    const allKeys = await db.getLicenseKeys();
    const used = allKeys.filter(k => k.is_used || k.isUsed);

    if (isAdmin) {
      return res.json(used);
    }
    return res.json(used.filter(k => k.used_by === userId || k.usedBy === userId || k.used_by === profile?.username));
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/redeem', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const { key } = req.body;
  if (!key || typeof key !== 'string') {
    return res.status(400).json({ success: false, error: 'กรุณาระบุคีย์' });
  }

  const cleanKey = key.trim().toUpperCase();

  return await transactionLock.acquire(`redeem_${cleanKey}`, async () => {
    // 1. If Supabase RPC is provisioned, execute RPC
    const supa = db.getSupabaseClient();
    if (supa) {
      try {
        const { data, error } = await supa.rpc('redeem_license_key', { input_key: cleanKey });
        if (!error && data) {
          const profile = await db.getProfile(userId);
          return res.json({
            success: true,
            message: 'ใช้งานคีย์สำเร็จ',
            amount: data.value,
            value: data.value,
            balance: profile?.balance || data.new_balance,
            rank: profile?.rank || 'user'
          });
        }
        if (error) {
          return res.status(400).json({ success: false, error: error.message || 'คีย์ไม่ถูกต้องหรือถูกใช้งานไปแล้ว' });
        }
      } catch {}
    }

    // 2. Atomic server database execution
    const result = await db.redeemKey(cleanKey, userId);
    if (!result.success) {
      return res.status(result.status || 400).json({ success: false, error: result.error });
    }
    return res.json(result);
  });
});

// ==========================================
// [P0-2] BLOCKED IPS
// ==========================================
app.get('/api/blocked_ips', requireAdmin, async (_req: Request, res: Response) => {
  return res.json(db.getBlockedIPs());
});

app.post('/api/blocked_ips', requireAdmin, async (req: Request, res: Response) => {
  const { ip, reason } = req.body;
  if (!ip) return res.status(400).json({ success: false, error: 'IP is required' });
  const item = db.addBlockedIP(ip, reason);
  return res.json({ success: true, item });
});

app.delete('/api/blocked_ips/:ip', requireAdmin, async (req: Request, res: Response) => {
  db.deleteBlockedIP(req.params.ip);
  return res.json({ success: true, message: 'ปลดบล็อค IP สำเร็จ' });
});

// ==========================================
// [P0-2] SITE SETTINGS
// ==========================================
app.get('/api/settings', async (_req: Request, res: Response) => {
  try {
    const settings = await db.getSettings();
    return res.json(settings);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/settings', requireAdmin, async (req: Request, res: Response) => {
  try {
    const settings = await db.updateSettings(req.body);
    return res.json({ success: true, settings });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// [P0-2] CUSTOM PAGES
// ==========================================
app.get('/api/pages', async (_req: Request, res: Response) => {
  return res.json(db.getPages());
});

app.post('/api/pages', requireAdmin, async (req: Request, res: Response) => {
  const page = db.createPage(req.body);
  return res.json({ success: true, page });
});

app.put('/api/pages/:id', requireAdmin, async (req: Request, res: Response) => {
  const page = db.updatePage(req.params.id, req.body);
  if (!page) return res.status(404).json({ success: false, error: 'Page not found' });
  return res.json({ success: true, page });
});

app.delete('/api/pages/:id', requireAdmin, async (req: Request, res: Response) => {
  db.deletePage(req.params.id);
  return res.json({ success: true, message: 'Deleted page' });
});

// ==========================================
// [P0-2] ORDERS / PURCHASES HISTORY
// ==========================================
app.get('/api/purchases', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const profile = await db.getProfile(userId);
    const isAdmin = profile && (profile.role === 'admin' || profile.role === 'Admin');

    const orders = await db.getOrders(isAdmin ? undefined : userId);
    return res.json(orders);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/latest-purchases', async (_req: Request, res: Response) => {
  try {
    const orders = await db.getOrders();
    const anonymized = orders.slice(0, 15).map(o => ({
      id: o.id,
      productName: o.product_name,
      amount: o.amount,
      username: o.username ? (o.username.length > 3 ? o.username.slice(0, 3) + '***' : 'User***') : 'User***',
      createdAt: o.created_at
    }));
    return res.json(anonymized);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// [P0-2] TOPUPS
// ==========================================
app.get('/api/topups', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const profile = await db.getProfile(userId);
    const isAdmin = profile && (profile.role === 'admin' || profile.role === 'Admin');

    const topups = await db.getTopups(isAdmin ? undefined : userId);
    return res.json(topups);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/topup/truemoney', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { amount: requestedAmount } = req.body;
    const amount = Number(requestedAmount) || 100;

    const user = await db.getProfile(userId);
    if (!user) return res.status(401).json({ success: false, error: 'User not found' });

    const newBalance = (user.balance || 0) + amount;
    await db.updateProfile(userId, { balance: newBalance });

    await db.recordTopup({
      id: 'tu-' + Date.now(),
      user_id: userId,
      username: user.username,
      type: 'truemoney',
      amount,
      reference_no: 'TM-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      status: 'approved',
      created_at: new Date().toISOString()
    });

    return res.json({ success: true, amount, balance: newBalance, message: `เติมเงินสำเร็จ +฿${amount} บาท` });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// [P0-2] LOGS SYSTEM
// ==========================================
app.get('/api/logs-system', async (_req: Request, res: Response) => {
  return res.json(db.getLogsSystem());
});

app.post('/api/logs-system', requireAdmin, async (req: Request, res: Response) => {
  db.saveLogsSystem(req.body);
  return res.json({ success: true });
});

// ==========================================
// [P0-2] STATS & HEALTH
// ==========================================
app.get('/api/stats', async (_req: Request, res: Response) => {
  try {
    const stats = await db.getStats();
    return res.json(stats);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/health', (req: Request, res: Response) => {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.ip || '127.0.0.1';
  return res.json({
    status: 'healthy',
    clientIp,
    environment: isProduction ? 'production' : 'development',
    timestamp: new Date().toISOString()
  });
});

// ==========================================
// [P0-2 & 1.3] SECURE IMAGE UPLOAD (MAGIC-BYTES VALIDATED)
// ==========================================
app.post('/api/upload', optionalAuth, async (req: Request, res: Response) => {
  try {
    let buffer: Buffer | null = null;
    const bodyImg = req.body.image || req.body.file || req.body.data || req.body.img;

    if (typeof bodyImg === 'string') {
      const base64Data = bodyImg.replace(/^data:image\/\w+;base64,/, '');
      buffer = Buffer.from(base64Data, 'base64');
    }

    if (!buffer || buffer.length === 0) {
      return res.status(400).json({ success: false, error: 'กรุณาอัปโหลดรูปภาพ' });
    }

    // STRICT VALIDATION: Check magic bytes for JPEG, PNG, WEBP!
    const validation = validateImageMagicBytes(buffer);
    if (!validation.valid || !validation.ext) {
      return res.status(400).json({
        success: false,
        error: 'ไฟล์รูปภาพไม่ถูกต้อง รองรับเฉพาะไฟล์ JPEG, PNG, WEBP เท่านั้น'
      });
    }

    const uploadsDir = path.resolve(process.cwd(), 'public', 'uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    const filename = `up_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${validation.ext}`;
    const filePath = path.resolve(uploadsDir, filename);
    fs.writeFileSync(filePath, buffer);

    const publicUrl = `/uploads/${filename}`;
    return res.json({
      success: true,
      url: publicUrl,
      imageUrl: publicUrl,
      ext: validation.ext
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'อัปโหลดรูปภาพไม่สำเร็จ' });
  }
});

// ==========================================
// RONZY SLIP VERIFICATION SERVICE & ENDPOINTS
// ==========================================
const SLIP_ERROR_MESSAGES: Record<string, string> = {
  'bad-request': 'ข้อมูลคำขอไม่ถูกต้อง (Body ไม่ถูกต้อง)',
  'terms-not-accepted': 'ไม่ได้ยอมรับข้อกำหนด TOS / Privacy / EULA',
  'invalid-image': 'Base64 image ไม่ถูกต้อง หรือไฟล์รูปภาพเสียหาย',
  'qr-not-found': 'หา QR ในรูปไม่เจอ กรุณาถ่ายหรือแนบสลิปที่เห็น QR Code ชัดเจน',
  'invalid-qr': 'QR format ไม่ถูกต้อง หรือไม่ใช่ QR สลิปโอนเงินธนาคาร',
  'amount-not-found': 'OCR อ่านยอดเงินไม่ได้ กรุณาระบุยอดเงินผ่าน /api/slip/{amount}',
  'amount-not-verified': 'ยอดตรวจกับธนาคารไม่ผ่าน หรือยอดเงินที่ระบุไม่ตรงกับสลิป',
  'invalid-slip-data': 'ข้อมูลสลิปไม่สมบูรณ์',
  'slip-not-found': 'ไม่พบสลิปในระบบธนาคาร หรือสลิปยังไม่อัปเดต',
  'rate-limit-exceeded': 'เกินขีดจำกัดการตรวจสอบ กรุณารอสักครู่แล้วลองใหม่',
  'slip-already-used': 'สลิปนี้ถูกใช้งานไปแล้วในระบบ กรุณาใช้สลิปใหม่',
};

interface ProcessSlipOptions {
  img?: string;
  amount?: number | string;
  isNoSlip?: boolean;
  qrcode_data?: string;
  tos?: boolean;
  privacy?: boolean;
  eula?: boolean;
  userId?: string;
}

export async function executeSlipVerification(options: ProcessSlipOptions) {
  if (options.tos === false || options.privacy === false || options.eula === false) {
    return {
      status: 400,
      body: { success: false, slug: 'terms-not-accepted', error: SLIP_ERROR_MESSAGES['terms-not-accepted'] }
    };
  }

  const ronzyBase = (process.env.RONZY_SLIP_API_URL || 'https://ronzy.xyz').replace(/\/+$/, '');
  let targetUrl: string;
  let requestBody: any;

  const numericAmount = options.amount ? Number(options.amount) : undefined;
  const hasValidAmount = typeof numericAmount === 'number' && !isNaN(numericAmount) && numericAmount > 0;

  if (options.isNoSlip) {
    if (!hasValidAmount) {
      return { status: 400, body: { success: false, slug: 'bad-request', error: 'ต้องระบุยอดเงิน (amount) สำหรับ Endpoint no_slip' } };
    }
    const qrCode = (options.qrcode_data || '').trim();
    if (!qrCode) {
      return { status: 422, body: { success: false, slug: 'qr-not-found', error: 'ไม่พบข้อมูล qrcode_data' } };
    }
    targetUrl = `${ronzyBase}/api/slip/${numericAmount}/no_slip`;
    requestBody = { qrcode_data: qrCode, tos: true, privacy: true, eula: true };
  } else {
    let imgData = (options.img || '').trim();
    if (!imgData) {
      return { status: 400, body: { success: false, slug: 'invalid-image', error: 'กรุณาอัปโหลดรูปภาพสลิปโอนเงิน' } };
    }
    if (!imgData.startsWith('data:')) {
      imgData = `data:image/jpeg;base64,${imgData}`;
    }
    targetUrl = hasValidAmount ? `${ronzyBase}/api/slip/${numericAmount}` : `${ronzyBase}/api/slip`;
    requestBody = { img: imgData, tos: true, privacy: true, eula: true };
  }

  let ronzyRes: any;
  try {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'User-Agent': 'Astrax-Store/1.0'
    };
    if (process.env.RONZY_API_KEY) {
      headers['X-API-Key'] = process.env.RONZY_API_KEY;
    }

    ronzyRes = await axios.post(targetUrl, requestBody, {
      headers,
      timeout: 30000,
      validateStatus: () => true
    });
  } catch (netErr: any) {
    return {
      status: 502,
      body: { success: false, slug: 'bad-request', error: 'ไม่สามารถติดต่อเซิร์ฟเวอร์ตรวจสอบสลิปได้ กรุณาลองใหม่อีกครั้ง' }
    };
  }

  const resData = ronzyRes.data || {};
  if (ronzyRes.status !== 200) {
    const slug = resData.slug || (ronzyRes.status === 404 ? 'slip-not-found' : 'bad-request');
    const thaiError = SLIP_ERROR_MESSAGES[slug] || resData.error || 'เกิดข้อผิดพลาดในการตรวจสอบสลิป';
    return { status: ronzyRes.status, body: { success: false, slug, error: thaiError, rawError: resData.error || thaiError } };
  }

  const slipData = resData.data || {};
  const transRef = (slipData.ref || slipData.transRef || '').trim();
  const slipAmount = Number(slipData.amount || numericAmount || 0);

  if (!transRef) {
    return { status: 422, body: { success: false, slug: 'invalid-slip-data', error: 'ไม่สามารถระบุเลขอ้างอิง (ref) จากผลตรวจสลิปได้' } };
  }

  if (slipStore.isUsed(transRef)) {
    return { status: 400, body: { success: false, slug: 'slip-already-used', error: 'สลิปนี้ถูกใช้งานไปแล้วในระบบ กรุณาใช้สลิปใหม่' } };
  }

  if (slipAmount <= 0) {
    return { status: 422, body: { success: false, slug: 'amount-not-verified', error: 'ยอดเงินในสลิปไม่ถูกต้อง' } };
  }

  const recorded = await slipStore.recordSlip(transRef, slipAmount, options.userId || 'guest', slipData);
  if (!recorded) {
    return { status: 400, body: { success: false, slug: 'slip-already-used', error: 'สลิปนี้ถูกใช้งานไปแล้วในระบบ กรุณาใช้สลิปใหม่' } };
  }

  // Credit user profile balance in database
  if (options.userId) {
    const user = await db.getProfile(options.userId);
    const newBal = (user?.balance || 0) + slipAmount;
    await db.updateProfile(options.userId, { balance: newBal });

    await db.recordTopup({
      id: 'tu-' + transRef,
      user_id: options.userId,
      username: user?.username || 'User',
      type: 'promptpay_slip',
      amount: slipAmount,
      reference_no: transRef,
      status: 'approved',
      created_at: new Date().toISOString()
    });
  }

  return {
    status: 200,
    body: {
      success: true,
      message: resData.message || 'Slip processed successfully.',
      fromCache: resData.fromCache ?? false,
      data: slipData,
      amount: slipAmount,
      transRef,
      topup: {
        id: transRef,
        amount: slipAmount,
        userId: options.userId || 'guest',
        date: slipData.date || new Date().toISOString(),
        status: 'success',
        title: `โอนเงินผ่านสลิป (${transRef})`
      }
    }
  };
}

app.post('/api/slip', slipRateLimiter, optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({
    img: req.body.img || req.body.imageBase64 || req.body.image,
    amount: req.body.amount,
    tos: req.body.tos,
    privacy: req.body.privacy,
    eula: req.body.eula,
    userId: req.user?.id
  });
  return res.status(result.status).json(result.body);
});

app.post('/api/slip/:amount', slipRateLimiter, optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({
    img: req.body.img || req.body.imageBase64 || req.body.image,
    amount: req.params.amount,
    tos: req.body.tos,
    privacy: req.body.privacy,
    eula: req.body.eula,
    userId: req.user?.id
  });
  return res.status(result.status).json(result.body);
});

app.post('/api/slip/:amount/no_slip', slipRateLimiter, optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({
    amount: req.params.amount,
    isNoSlip: true,
    qrcode_data: req.body.qrcode_data || req.body.qr,
    tos: req.body.tos,
    privacy: req.body.privacy,
    eula: req.body.eula,
    userId: req.user?.id
  });
  return res.status(result.status).json(result.body);
});

app.post('/api/topup/slip', slipRateLimiter, optionalAuth, async (req: AuthenticatedRequest, res: Response) => {
  const result = await executeSlipVerification({
    img: req.body.img || req.body.imageBase64 || req.body.image,
    amount: req.body.amount,
    tos: req.body.tos ?? true,
    privacy: req.body.privacy ?? true,
    eula: req.body.eula ?? true,
    userId: req.user?.id
  });
  return res.status(result.status).json(result.body);
});

// ==========================================
// STATIC ASSETS & VITE INTEGRATION
// ==========================================
async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT} in ${isProduction ? 'production' : 'development'} mode`);
  });
}

// Only auto-start when run directly, not during unit tests
if (process.env.NODE_ENV !== 'test') {
  startServer();
}

export { app };

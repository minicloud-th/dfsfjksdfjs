/**
 * DEV Store & Community - Comprehensive In-Memory & LocalStorage Demo Engine
 * Enables 100% full-featured offline and zero-config demo experience.
 */

import axios from 'axios';
import { Product, Category, SiteStats, UserPlan } from '../types';

export interface DemoUser {
  id: string;
  uid: string;
  email: string;
  username: string;
  fullName?: string;
  role: 'admin' | 'user';
  rank: 'user' | 'basic' | 'premium' | 'admin';
  balance: number;
  isPremium: boolean;
  premiumExpireDate?: string | null;
  status: 'active' | 'banned';
  registeredAt: string;
  avatarUrl?: string;
}

export interface DemoPurchase {
  id: string;
  orderId?: string;
  uid: string;
  userId?: string;
  username: string;
  productId: string;
  productName: string;
  price: number;
  amount: number;
  quantity?: number;
  itemData: string;
  deliveredItem?: string;
  secretData?: string;
  createdAt: string;
  date?: string;
  timestamp?: string;
  status: 'completed' | 'pending';
}

export interface DemoTopup {
  id: string;
  uid: string;
  username: string;
  type: 'promptpay' | 'truemoney' | 'admin_adjust';
  amount: number;
  status: 'approved' | 'pending' | 'rejected';
  referenceNo: string;
  createdAt: string;
}

export interface DemoLicenseKey {
  id: string;
  key: string;
  type: 'balance' | 'rank_premium' | 'discount';
  value: number;
  description: string;
  isUsed: boolean;
  usedBy?: string;
  usedAt?: string;
  createdAt: string;
}

// Initial Seed Data
const DEFAULT_CATEGORIES: Category[] = [
  {
    id: "game_accounts",
    name: "ไอดีเกมยอดนิยม",
    title: "ไอดีเกมยอดนิยม (Game Accounts)",
    subtitle: "ไอดี RoV, Valorant, Free Fire, Genshin Impact ราคาพิเศษ พร้อมรับประกัน",
    bannerUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80",
  },
  {
    id: "premium_apps",
    name: "แอปพรีเมียม / สตรีมมิ่ง",
    title: "แอปพรีเมียม & สตรีมมิ่ง (Streaming & Apps)",
    subtitle: "Netflix 4K, YouTube Premium, Spotify, Discord Nitro แท้ 100%",
    bannerUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?auto=format&fit=crop&w=600&q=80",
  },
  {
    id: "software_tools",
    name: "ซอฟต์แวร์และเครื่องมือ",
    title: "ซอฟต์แวร์ & โปรแกรมดิจิทัล (Tools & Software)",
    subtitle: "คีย์แท้ Windows 11 Pro, Office 365, VPN และบอทบริการอัตโนมัติ",
    bannerUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80",
  },
  {
    id: "steam_wallet",
    name: "บัตรเติมเงิน & Steam",
    title: "Steam Wallet & บัตรเติมเงินดิจิทัล",
    subtitle: "Steam Gift Card, Razer Gold, TrueMoney รวดเร็วทันใจ",
    bannerUrl: "https://images.unsplash.com/photo-1612287233207-6a4a03493e87?auto=format&fit=crop&w=1200&q=80",
    imageUrl: "https://images.unsplash.com/photo-1612287233207-6a4a03493e87?auto=format&fit=crop&w=600&q=80",
  }
];

const DEFAULT_PRODUCTS: Product[] = [];

export const isEmailAdmin = (email?: string | null): boolean => {
  if (!email) return false;
  const cleanEmail = email.toLowerCase().trim();
  const users = demoStore.getUsers();
  const user = users.find(u => (u.email || '').toLowerCase().trim() === cleanEmail);
  return user?.role === 'admin';
};

const DEFAULT_USERS: DemoUser[] = [
  {
    id: "demo-admin-001",
    uid: "demo-admin-001",
    email: "admin@astrax.store",
    username: "admin",
    fullName: "System Administrator",
    role: "admin",
    rank: "admin",
    balance: 5000,
    isPremium: true,
    status: "active",
    registeredAt: new Date().toISOString(),
    avatarUrl: "https://api.dicebear.com/7.x/bottts/svg?seed=admin"
  },
  {
    id: "demo-user-002",
    uid: "demo-user-002",
    email: "user@astrax.store",
    username: "demo_user",
    fullName: "Demo User",
    role: "user",
    rank: "user",
    balance: 500,
    isPremium: false,
    status: "active",
    registeredAt: new Date().toISOString(),
    avatarUrl: "https://api.dicebear.com/7.x/bottts/svg?seed=demo_user"
  }
];

const DEFAULT_KEYS: DemoLicenseKey[] = [];

const DEFAULT_BLOCKED_IPS: any[] = [];

const DEFAULT_SETTINGS = {
  site_name: "Astrax Store & Community",
  truewallet_phone: "081-234-5678",
  contact_line: "https://line.me/ti/p/~@astrax",
  discord_link: "https://discord.gg/astrax",
  facebook_link: "https://facebook.com/astraxofficial",
  instagram_link: "https://instagram.com/astrax_th",
  contact_email: "support@astrax.store",
  popup_enabled: false,
  popup_img_url: "",
  popup_link: "",
  stats_users_offset: 0,
  stats_sales_offset: 0,
  spotify_url: "",
  spotify_autoplay: false,
  announcement_text: "ยินดีต้อนรับสู่ Astrax ศูนย์รวมสินค้าดิจิทัลและบริการครบวงจร",
  promptpay_number: "",
  promptpay_name: "Astrax Official"
};

// Storage helper
class DemoStorage {
  private memoryFallback: Record<string, string> = {};

  private get<T>(key: string, fallback: T): T {
    try {
      if (typeof localStorage !== 'undefined') {
        const item = localStorage.getItem(`dev_${key}`);
        return item ? JSON.parse(item) : fallback;
      }
      const mem = this.memoryFallback[`dev_${key}`];
      return mem ? JSON.parse(mem) : fallback;
    } catch {
      return fallback;
    }
  }

  private set<T>(key: string, value: T): void {
    try {
      const str = JSON.stringify(value);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(`dev_${key}`, str);
      } else {
        this.memoryFallback[`dev_${key}`] = str;
      }
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }

  getProducts(): Product[] {
    const list = this.get<Product[]>('products', DEFAULT_PRODUCTS);
    // Ensure all items have stock count and stockData array
    return list.map(p => ({
      ...p,
      stock: (p.stockData && p.stockData.length > 0) ? p.stockData.length : (p.stock || 0)
    }));
  }

  saveProducts(products: Product[]): void {
    this.set('products', products);
  }

  getCategories(): Category[] {
    return this.get<Category[]>('categories', DEFAULT_CATEGORIES);
  }

  saveCategories(categories: Category[]): void {
    this.set('categories', categories);
  }

  getUsers(): DemoUser[] {
    return this.get<DemoUser[]>('users', DEFAULT_USERS);
  }

  saveUsers(users: DemoUser[]): void {
    this.set('users', users);
  }

  getPurchases(): DemoPurchase[] {
    return this.get<DemoPurchase[]>('purchases', [
      {
        id: "order-demo-1001",
        uid: "demo-user-002",
        userId: "demo-user-002",
        username: "Spotxixe",
        productId: "discord_nitro_1m",
        productName: "Discord Nitro Monthly (30 วัน)",
        price: 149,
        amount: 149,
        itemData: "NITRO-PROMO-ABCD-EFGH-9981",
        deliveredItem: "NITRO-PROMO-ABCD-EFGH-9981",
        createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
        status: "completed"
      }
    ]);
  }

  savePurchases(purchases: DemoPurchase[]): void {
    this.set('purchases', purchases);
  }

  getTopups(): DemoTopup[] {
    return this.get<DemoTopup[]>('topups', [
      {
        id: "topup-101",
        uid: "demo-user-002",
        username: "Spotxixe",
        type: "promptpay",
        amount: 500,
        status: "approved",
        referenceNo: "PP-99482104",
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString()
      }
    ]);
  }

  saveTopups(topups: DemoTopup[]): void {
    this.set('topups', topups);
  }

  getLicenseKeys(): DemoLicenseKey[] {
    return this.get<DemoLicenseKey[]>('license_keys', DEFAULT_KEYS);
  }

  saveLicenseKeys(keys: DemoLicenseKey[]): void {
    this.set('license_keys', keys);
  }

  getBlockedIPs(): any[] {
    return this.get<any[]>('blocked_ips', DEFAULT_BLOCKED_IPS);
  }

  saveBlockedIPs(ips: any[]): void {
    this.set('blocked_ips', ips);
  }

  getSettings(): any {
    return this.get('settings', DEFAULT_SETTINGS);
  }

  saveSettings(settings: any): void {
    this.set('settings', settings);
  }

  getPages(): any[] {
    return this.get('pages', [
      {
        id: "terms",
        title: "ข้อกำหนดและเงื่อนไขการใช้บริการ",
        slug: "terms",
        content: "# ข้อกำหนดและเงื่อนไข\n\n1. สินค้าทุกชิ้นมีการรับประกันตามรายละเอียดที่ระบุ\n2. ห้ามนำสินค้าไปใช้ในทางที่ผิดกฎหมาย\n3. ติดต่อสอบถามแอดมินได้ตลอด 24 ชั่วโมง",
        updatedAt: new Date().toISOString()
      }
    ]);
  }

  savePages(pages: any[]): void {
    this.set('pages', pages);
  }

  getLogsSystem(): any {
    return this.get('logs_system', {
      categories: [
        { id: "discord_tools", name: "Discord Tools & Bots", icon: "Bot", description: "เครื่องมือบอทดิสคอร์ดและสคริปต์อัตโนมัติ" },
        { id: "game_utilities", name: "Game Utilities", icon: "Gamepad2", description: "ยูทิลิตี้ปรับแต่งเกมและ FPS Boost" }
      ],
      items: [
        {
          id: "item-1",
          categoryId: "discord_tools",
          title: "Discord Token Checker & Formatter v2.4",
          description: "โปรแกรมตรวจสอบความถูกต้องของโทเคนแบบ Real-time ความเร็วสูง",
          type: "free",
          fileUrl: "https://example.com/tools/token-checker.zip"
        },
        {
          id: "item-2",
          categoryId: "discord_tools",
          title: "Auto Server Booster & Welcomer Pro",
          description: "สคริปต์จัดการเซิร์ฟเวอร์ดิสคอร์ดอัตโนมัติ พร้อมระบบต้อนรับ",
          type: "premium",
          fileUrl: "https://example.com/tools/server-booster.zip"
        }
      ]
    });
  }

  saveLogsSystem(data: any): void {
    this.set('logs_system', data);
  }
}

export const demoStore = new DemoStorage();

// Current active session tracking
let currentActiveUser: DemoUser | null = null;
const authListeners: Array<(event: string, session: any) => void> = [];

export function getCurrentDemoUser(): DemoUser | null {
  if (currentActiveUser) return currentActiveUser;
  try {
    if (typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem('apex_demo_user');
      if (saved) {
        currentActiveUser = JSON.parse(saved);
        return currentActiveUser;
      }
    }
  } catch {}
  return null;
}

export function setDemoSession(user: DemoUser | null) {
  currentActiveUser = user;
  if (typeof localStorage !== 'undefined') {
    if (user) {
      localStorage.setItem('apex_demo_user', JSON.stringify(user));
      localStorage.setItem('apex_auth_session', JSON.stringify({
        access_token: 'demo-token-' + user.id,
        user: {
          id: user.id,
          uid: user.uid,
          email: user.email,
          user_metadata: {
            username: user.username,
            fullName: user.fullName || user.username,
            role: user.role,
            avatar_url: user.avatarUrl
          }
        }
      }));
    } else {
      localStorage.removeItem('apex_demo_user');
      localStorage.removeItem('apex_auth_session');
    }
  }

  const sessionObj = user ? {
    access_token: 'demo-token-' + user.id,
    user: {
      id: user.id,
      uid: user.uid,
      email: user.email,
      user_metadata: {
        username: user.username,
        fullName: user.fullName || user.username,
        role: user.role,
        avatar_url: user.avatarUrl
      }
    }
  } : null;

  authListeners.forEach(cb => {
    try {
      cb(user ? 'SIGNED_IN' : 'SIGNED_OUT', sessionObj);
    } catch {}
  });
}

export function subscribeDemoAuth(cb: (event: string, session: any) => void) {
  authListeners.push(cb);
  const user = getCurrentDemoUser();
  if (user) {
    setTimeout(() => {
      cb('SIGNED_IN', {
        access_token: 'demo-token-' + user.id,
        user: {
          id: user.id,
          uid: user.uid,
          email: user.email,
          user_metadata: {
            username: user.username,
            fullName: user.fullName || user.username,
            role: user.role,
            avatar_url: user.avatarUrl
          }
        }
      });
    }, 0);
  } else {
    setTimeout(() => cb('SIGNED_OUT', null), 0);
  }
  return {
    unsubscribe: () => {
      const idx = authListeners.indexOf(cb);
      if (idx !== -1) authListeners.splice(idx, 1);
    }
  };
}

/**
 * Setup Axios Request Interceptors to handle /api calls in browser (DEV-ONLY FALLBACK)
 * Strictly forbidden in production builds.
 */
export function setupDemoMockInterceptor() {
  const useMock = import.meta.env.VITE_USE_MOCK_API === 'true';
  const isProd = Boolean(import.meta.env.PROD);

  if (isProd) {
    if (useMock) {
      console.error('[CRITICAL SECURITY GUARD] VITE_USE_MOCK_API cannot be enabled in production build! Disabling mock interceptor immediately.');
      throw new Error('[Security Guard] Mock API interceptor is strictly forbidden in production builds.');
    }
    // Strictly do not install interceptor in production
    return;
  }

  // In development, only install if explicitly enabled via VITE_USE_MOCK_API=true
  if (!useMock) {
    return;
  }

  console.warn('[DEV NOTICE] Mock API interceptor is ACTIVE (VITE_USE_MOCK_API=true).');

  // Use axios adapter / interceptor
  axios.interceptors.request.use(async (config) => {
    const url = config.url || '';
    if (!url.startsWith('/api/') && !url.startsWith('http://localhost') && !url.startsWith('/health')) {
      return config;
    }

    // Handle mock routes
    try {
      const result = await handleMockApiRoute(config);
      if (result) {
        // Return simulated response
        config.adapter = async () => ({
          data: result.data,
          status: result.status || 200,
          statusText: 'OK',
          headers: {},
          config,
          request: {}
        });
      }
    } catch (err: any) {
      config.adapter = async () => {
        throw {
          response: {
            data: { error: err.message || 'Mock Error' },
            status: err.status || 400,
            statusText: 'Bad Request',
            headers: {},
            config
          },
          message: err.message
        };
      };
    }

    return config;
  });
}

async function handleMockApiRoute(config: any): Promise<{ data: any; status?: number } | null> {
  const method = (config.method || 'GET').toUpperCase();
  const url = (config.url || '').split('?')[0];
  const body = config.data ? (typeof config.data === 'string' ? JSON.parse(config.data) : config.data) : {};
  const currentUser = getCurrentDemoUser();

  // /api/settings
  if (url === '/api/settings') {
    if (method === 'GET') {
      return { data: demoStore.getSettings() };
    }
    if (method === 'POST') {
      const prev = demoStore.getSettings();
      const updated = { ...prev, ...body };
      demoStore.saveSettings(updated);
      return { data: { success: true, settings: updated } };
    }
  }

  // /api/products
  if (url === '/api/products') {
    if (method === 'GET') {
      return { data: demoStore.getProducts() };
    }
    if (method === 'POST') {
      const list = demoStore.getProducts();
      const newProduct: Product = {
        id: body.id || 'prod_' + Date.now(),
        name: body.name || 'สินค้าใหม่',
        description: body.description || '',
        price: Number(body.price) || 0,
        originalPrice: Number(body.originalPrice) || undefined,
        category: body.category || '',
        imageUrl: body.imageUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80',
        stock: Array.isArray(body.stockData) ? body.stockData.length : (Number(body.stock) || 0),
        soldCount: 0,
        isPopular: Boolean(body.isPopular),
        tag: body.tag || '',
        stockData: Array.isArray(body.stockData) ? body.stockData : []
      };
      list.push(newProduct);
      demoStore.saveProducts(list);
      return { data: { success: true, product: newProduct } };
    }
  }

  // /api/products/:id
  const prodMatch = url.match(/^\/api\/products\/([^\/]+)$/);
  if (prodMatch) {
    const prodId = prodMatch[1];
    const list = demoStore.getProducts();
    const idx = list.findIndex(p => p.id === prodId);

    if (method === 'GET') {
      if (idx === -1) throw { message: 'ไม่พบสินค้า', status: 404 };
      return { data: list[idx] };
    }
    if (method === 'PUT') {
      if (idx === -1) throw { message: 'ไม่พบสินค้าที่จะแก้ไข', status: 404 };
      const updated = { ...list[idx], ...body };
      if (Array.isArray(body.stockData)) {
        updated.stock = body.stockData.length;
      }
      list[idx] = updated;
      demoStore.saveProducts(list);
      return { data: { success: true, product: updated } };
    }
    if (method === 'DELETE') {
      if (idx !== -1) {
        list.splice(idx, 1);
        demoStore.saveProducts(list);
      }
      return { data: { success: true } };
    }
  }

  // /api/products/:id/stock
  const stockMatch = url.match(/^\/api\/products\/([^\/]+)\/stock$/);
  if (stockMatch) {
    const prodId = stockMatch[1];
    const list = demoStore.getProducts();
    const prod = list.find(p => p.id === prodId);
    if (!prod) throw { message: 'ไม่พบสินค้า', status: 404 };

    if (method === 'GET') {
      return { data: { stock: prod.stockData || [], count: prod.stockData?.length || 0 } };
    }
    if (method === 'POST') {
      const newItems: string[] = Array.isArray(body.newItems) ? body.newItems : 
        (typeof body.stockData === 'string' ? body.stockData.split('\n').map((s: string) => s.trim()).filter(Boolean) : []);
      
      const currentStock = prod.stockData || [];
      const combined = [...currentStock, ...newItems];
      prod.stockData = combined;
      prod.stock = combined.length;
      demoStore.saveProducts(list);
      return { data: { success: true, count: combined.length, stock: combined } };
    }
  }

  // /api/categories
  if (url === '/api/categories') {
    if (method === 'GET') {
      return { data: demoStore.getCategories() };
    }
    if (method === 'POST') {
      const cats = demoStore.getCategories();
      const newCat: Category = {
        id: body.id || 'cat_' + Date.now(),
        name: body.name || 'หมวดหมู่ใหม่',
        title: body.title || body.name || 'หมวดหมู่ใหม่',
        subtitle: body.subtitle || '',
        bannerUrl: body.bannerUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
        imageUrl: body.imageUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'
      };
      cats.push(newCat);
      demoStore.saveCategories(cats);
      return { data: { success: true, category: newCat } };
    }
  }

  const catMatch = url.match(/^\/api\/categories\/([^\/]+)$/);
  if (catMatch) {
    const catId = catMatch[1];
    const cats = demoStore.getCategories();
    const idx = cats.findIndex(c => c.id === catId);
    if (method === 'PUT') {
      if (idx === -1) throw { message: 'ไม่พบหมวดหมู่', status: 404 };
      cats[idx] = { ...cats[idx], ...body };
      demoStore.saveCategories(cats);
      return { data: { success: true, category: cats[idx] } };
    }
    if (method === 'DELETE') {
      if (idx !== -1) {
        cats.splice(idx, 1);
        demoStore.saveCategories(cats);
      }
      return { data: { success: true } };
    }
  }

  // TODO(production): Before opening for real production sales, a server-side endpoint (/api/buy) with atomic transactions, server-side idempotency verification, real stock lock/deduction, and real balance deduction must be implemented in server.ts/database instead of this client-side mock.
  // /api/buy
  if (url === '/api/buy' && method === 'POST') {
    const { productId, quantity = 1 } = body;
    const numQty = Math.max(1, Math.floor(Number(quantity) || 1));
    const products = demoStore.getProducts();
    const prod = products.find(p => p.id === productId);
    if (!prod) throw { message: 'ไม่พบสินค้านี้ในระบบ', status: 404 };

    if ((prod.stock || 0) < numQty) {
      throw { message: 'สินค้าในสต็อกไม่เพียงพอสำหรับจำนวนที่คุณต้องการ', status: 400 };
    }

    const totalPrice = prod.price * numQty;
    const users = demoStore.getUsers();
    const user = currentUser ? users.find(u => u.id === currentUser.id || u.uid === currentUser.uid) : null;

    if (!user) throw { message: 'กรุณาเข้าสู่ระบบก่อนสั่งซื้อสินค้า', status: 401 };
    if (user.balance < totalPrice) {
      throw { message: `ยอดเงินคงเหลือไม่เพียงพอ (ต้องการ ฿${totalPrice.toLocaleString()} บาท แต่มี ฿${user.balance.toLocaleString()} บาท) กรุณาเติมเงิน`, status: 400 };
    }

    // Deliver stock item(s) according to requested quantity
    const deliveredItems: string[] = [];
    if (prod.stockData && Array.isArray(prod.stockData) && prod.stockData.length > 0) {
      for (let i = 0; i < numQty; i++) {
        if (prod.stockData.length > 0) {
          const key = prod.stockData.shift();
          if (key) deliveredItems.push(key);
        } else {
          deliveredItems.push(`KEY-${prod.id.toUpperCase()}-${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
        }
      }
      prod.stock = prod.stockData.length;
    } else {
      // Pure stock-counter mode (no preloaded stockData array or stockData is empty)
      for (let i = 0; i < numQty; i++) {
        deliveredItems.push(`KEY-${prod.id.toUpperCase()}-${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
      }
      prod.stock = Math.max(0, (prod.stock || 0) - numQty);
    }
    prod.soldCount = (prod.soldCount || 0) + numQty;
    demoStore.saveProducts(products);

    // Deduct user balance
    user.balance = Math.max(0, user.balance - totalPrice);
    demoStore.saveUsers(users);
    setDemoSession(user);

    // Save purchase record
    const nowIso = new Date().toISOString();
    const deliveredStr = deliveredItems.join('\n');
    const purchases = demoStore.getPurchases();
    const purchaseId = 'ord-' + Date.now();
    const newPurchase: DemoPurchase = {
      id: purchaseId,
      orderId: purchaseId,
      uid: user.id,
      userId: user.id,
      username: user.username,
      productId: prod.id,
      productName: prod.name,
      price: totalPrice,
      amount: totalPrice,
      quantity: numQty,
      itemData: deliveredStr,
      deliveredItem: deliveredStr,
      secretData: deliveredStr,
      createdAt: nowIso,
      date: nowIso,
      timestamp: nowIso,
      status: 'completed'
    };
    purchases.unshift(newPurchase);
    demoStore.savePurchases(purchases);

    return {
      data: {
        success: true,
        message: 'สั่งซื้อสำเร็จ!',
        purchase: newPurchase,
        updatedUser: {
          username: user.username,
          fullName: user.fullName || user.username,
          balance: user.balance,
          role: user.role,
          rank: user.rank,
          isPremium: Boolean(user.isPremium),
          premiumExpireDate: user.premiumExpireDate || null,
          registeredAt: user.registeredAt,
          avatarUrl: user.avatarUrl
        },
        updatedProduct: { ...prod },
        // Backward compatibility fields
        item: deliveredStr,
        deliveredItem: deliveredStr,
        orderId: purchaseId,
        purchaseId: purchaseId,
        balance: user.balance,
        productName: prod.name,
        price: totalPrice
      }
    };
  }

  // /api/topup/truemoney
  if (url === '/api/topup/truemoney' && method === 'POST') {
    const { voucherCode, voucherUrl, phone, amount: requestedAmount } = body;
    const users = demoStore.getUsers();
    const user = currentUser ? users.find(u => u.id === currentUser.id || u.uid === currentUser.uid) : null;
    if (!user) throw { message: 'กรุณาเข้าสู่ระบบก่อนทำรายการ', status: 401 };

    // Calculate credit amount (realistic simulation)
    const amount = Number(requestedAmount) || (voucherUrl || voucherCode ? (Math.floor(Math.random() * 3) + 1) * 100 : 150);
    user.balance += amount;
    demoStore.saveUsers(users);
    setDemoSession(user);

    const topups = demoStore.getTopups();
    topups.unshift({
      id: 'tu-' + Date.now(),
      uid: user.id,
      username: user.username,
      type: 'truemoney',
      amount,
      status: 'approved',
      referenceNo: 'TM-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      createdAt: new Date().toISOString()
    });
    demoStore.saveTopups(topups);

    return { data: { success: true, amount, balance: user.balance, message: `เติมเงินสำเร็จ +฿${amount} บาท` } };
  }


  // /api/redeem
  if (url === '/api/redeem' && method === 'POST') {
    const { key } = body;
    if (!key) throw { message: 'กรุณาระบุโค้ดหรือคีย์', status: 400 };

    const keys = demoStore.getLicenseKeys();
    const targetKey = keys.find(k => k.key.toUpperCase() === key.trim().toUpperCase());
    if (!targetKey) throw { message: 'ไม่พบคีย์นี้ในระบบ หรือคีย์ไม่ถูกต้อง', status: 404 };
    if (targetKey.isUsed) throw { message: 'คีย์นี้ถูกใช้งานไปแล้ว', status: 400 };

    const users = demoStore.getUsers();
    const user = currentUser ? users.find(u => u.id === currentUser.id || u.uid === currentUser.uid) : null;
    if (!user) throw { message: 'กรุณาเข้าสู่ระบบก่อนเติมคีย์', status: 401 };

    targetKey.isUsed = true;
    targetKey.usedBy = user.username;
    targetKey.usedAt = new Date().toISOString();
    demoStore.saveLicenseKeys(keys);

    user.balance += targetKey.value;
    if (targetKey.type === 'rank_premium') {
      user.isPremium = true;
      user.rank = 'premium';
    }
    demoStore.saveUsers(users);
    setDemoSession(user);

    return {
      data: {
        success: true,
        message: `เติมคีย์สำเร็จ! ได้รับ ฿${targetKey.value} บาท`,
        amount: targetKey.value,
        balance: user.balance
      }
    };
  }

  // /api/stats
  if (url === '/api/stats' || url === '/api/test_stats') {
    const purchases = demoStore.getPurchases();
    const products = demoStore.getProducts();
    const users = demoStore.getUsers();
    const topups = demoStore.getTopups();
    const settings = demoStore.getSettings();

    const totalSales = purchases.reduce((acc, p) => acc + (p.amount || p.price || 0), 0);
    const totalStock = products.reduce((acc, p) => acc + (p.stock || 0), 0);
    const totalUsers = users.length;
    const totalTopups = topups.reduce((acc, t) => acc + (t.amount || 0), 0);

    return {
      data: {
        users: totalUsers,
        stock: totalStock,
        sales: totalSales,
        topups: totalTopups,
        totalOrders: purchases.length
      }
    };
  }

  // /api/latest-purchases
  if (url === '/api/latest-purchases') {
    const list = demoStore.getPurchases().slice(0, 15);
    return { data: list };
  }

  // /api/purchases
  if (url.startsWith('/api/purchases')) {
    const list = demoStore.getPurchases();
    return { data: list };
  }

  // /api/topups
  if (url === '/api/topups') {
    return { data: demoStore.getTopups() };
  }

  // /api/license_keys
  if (url === '/api/license_keys') {
    if (method === 'GET') return { data: demoStore.getLicenseKeys() };
    if (method === 'POST') {
      const keys = demoStore.getLicenseKeys();
      const newKey: DemoLicenseKey = {
        id: 'key-' + Date.now(),
        key: body.key || 'DEV-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
        type: body.type || 'balance',
        value: Number(body.value) || 100,
        description: body.description || 'รหัสคีย์โปรโมชัน',
        isUsed: false,
        createdAt: new Date().toISOString()
      };
      keys.push(newKey);
      demoStore.saveLicenseKeys(keys);
      return { data: { success: true, key: newKey } };
    }
  }

  // /api/license_keys/bulk
  if (url === '/api/license_keys/bulk' && method === 'POST') {
    const keys = demoStore.getLicenseKeys();
    const newKeysList: DemoLicenseKey[] = (body.keys || []).map((k: any) => ({
      id: 'key-' + Math.random().toString(36).substring(2, 9),
      key: typeof k === 'string' ? k : (k.key || 'DEV-' + Math.random().toString(36).substring(2, 8).toUpperCase()),
      type: k.type || 'balance',
      value: Number(k.value) || 100,
      description: k.description || 'Generated Promo Key',
      isUsed: false,
      createdAt: new Date().toISOString()
    }));
    keys.push(...newKeysList);
    demoStore.saveLicenseKeys(keys);
    return { data: { success: true, count: newKeysList.length } };
  }

  // /api/license_keys/:id
  const keyDelMatch = url.match(/^\/api\/license_keys\/([^\/]+)$/);
  if (keyDelMatch && method === 'DELETE') {
    const keyId = keyDelMatch[1];
    const keys = demoStore.getLicenseKeys();
    const filtered = keys.filter(k => k.id !== keyId && k.key !== keyId);
    demoStore.saveLicenseKeys(filtered);
    return { data: { success: true } };
  }

  // /api/used_keys
  if (url === '/api/used_keys') {
    const keys = demoStore.getLicenseKeys().filter(k => k.isUsed);
    return { data: keys };
  }

  // /api/blocked_ips
  if (url === '/api/blocked_ips') {
    if (method === 'GET') {
      return { data: demoStore.getBlockedIPs() };
    }
    if (method === 'POST') {
      const ips = demoStore.getBlockedIPs();
      const newIp = {
        id: 'ip-' + Date.now(),
        ip: body.ip || '',
        reason: body.reason || 'บล็อคโดยผู้ดูแลระบบ',
        blockedAt: new Date().toISOString()
      };
      ips.push(newIp);
      demoStore.saveBlockedIPs(ips);
      return { data: { success: true, item: newIp } };
    }
  }

  // /api/blocked_ips/:ip
  const ipDelMatch = url.match(/^\/api\/blocked_ips\/([^\/]+)$/);
  if (ipDelMatch && method === 'DELETE') {
    const targetIp = decodeURIComponent(ipDelMatch[1]);
    const ips = demoStore.getBlockedIPs();
    const filtered = ips.filter(item => item.ip !== targetIp && item.id !== targetIp);
    demoStore.saveBlockedIPs(filtered);
    return { data: { success: true } };
  }

  // /api/users
  if (url === '/api/users') {
    if (method === 'GET') {
      return { data: demoStore.getUsers() };
    }
  }

  // /api/users/:uid
  const userMatch = url.match(/^\/api\/users\/([^\/]+)$/);
  if (userMatch) {
    const uid = userMatch[1];
    const users = demoStore.getUsers();
    const targetUser = users.find(u => u.id === uid || u.uid === uid);

    if (method === 'GET') {
      if (!targetUser) {
        // Create user profile on fly if missing
        const created: DemoUser = {
          id: uid,
          uid,
          email: `${uid}@apex-studio.com`,
          username: uid,
          role: 'user',
          rank: 'user',
          balance: 1000,
          isPremium: false,
          status: 'active',
          registeredAt: new Date().toISOString()
        };
        users.push(created);
        demoStore.saveUsers(users);
        return { data: created };
      }
      return { data: targetUser };
    }

    if (method === 'POST') {
      if (targetUser) {
        Object.assign(targetUser, body);
        demoStore.saveUsers(users);
        if (currentUser && (currentUser.id === uid || currentUser.uid === uid)) {
          setDemoSession(targetUser);
        }
        return { data: { success: true, user: targetUser } };
      } else {
        const created: DemoUser = {
          id: uid,
          uid,
          email: body.email || `${uid}@apex-studio.com`,
          username: body.username || uid,
          role: body.role || 'user',
          rank: body.rank || 'user',
          balance: body.balance !== undefined ? body.balance : 1000,
          isPremium: Boolean(body.isPremium),
          status: 'active',
          registeredAt: new Date().toISOString(),
          ...body
        };
        users.push(created);
        demoStore.saveUsers(users);
        return { data: { success: true, user: created } };
      }
    }

    if (method === 'DELETE') {
      const filtered = users.filter(u => u.id !== uid && u.uid !== uid);
      demoStore.saveUsers(filtered);
      return { data: { success: true } };
    }
  }

  // /api/users/:uid/password
  const userPassMatch = url.match(/^\/api\/users\/([^\/]+)\/password$/);
  if (userPassMatch && method === 'POST') {
    return { data: { success: true, message: 'เปลี่ยนรหัสผ่านเรียบร้อย' } };
  }

  // /api/signup
  if (url === '/api/signup' && method === 'POST') {
    const { email, password, recoveryEmail } = body;
    const users = demoStore.getUsers();
    const username = email.split('@')[0];
    const exists = users.find(u => u.email.toLowerCase() === email.toLowerCase() || u.username.toLowerCase() === username.toLowerCase());
    if (exists) throw { message: 'ชื่อผู้ใช้หรืออีเมลนี้มีอยู่ในระบบแล้ว', status: 400 };

    const newUser: DemoUser = {
      id: 'usr-' + Date.now(),
      uid: 'usr-' + Date.now(),
      email,
      username,
      fullName: username,
      role: 'user',
      rank: 'user',
      balance: 1000, // Welcome bonus
      isPremium: false,
      status: 'active',
      registeredAt: new Date().toISOString(),
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`
    };
    users.push(newUser);
    demoStore.saveUsers(users);
    setDemoSession(newUser);
    return { data: { success: true, user: newUser } };
  }

  // /api/reset-password
  if (url === '/api/reset-password' && method === 'POST') {
    return { data: { success: true, message: 'รีเซ็ตรหัสผ่านสำเร็จ' } };
  }

  // /api/pages
  if (url === '/api/pages') {
    if (method === 'GET') return { data: demoStore.getPages() };
    if (method === 'POST') {
      const pages = demoStore.getPages();
      pages.push({ id: 'page_' + Date.now(), ...body, updatedAt: new Date().toISOString() });
      demoStore.savePages(pages);
      return { data: { success: true } };
    }
  }

  const pageMatch = url.match(/^\/api\/pages\/([^\/]+)$/);
  if (pageMatch) {
    const pageId = pageMatch[1];
    const pages = demoStore.getPages();
    const idx = pages.findIndex(p => p.id === pageId);
    if (method === 'PUT' && idx !== -1) {
      pages[idx] = { ...pages[idx], ...body, updatedAt: new Date().toISOString() };
      demoStore.savePages(pages);
      return { data: { success: true, page: pages[idx] } };
    }
    if (method === 'DELETE' && idx !== -1) {
      pages.splice(idx, 1);
      demoStore.savePages(pages);
      return { data: { success: true } };
    }
  }

  // /api/logs-system
  if (url === '/api/logs-system') {
    if (method === 'GET') return { data: demoStore.getLogsSystem() };
    if (method === 'POST') {
      demoStore.saveLogsSystem(body);
      return { data: { success: true } };
    }
  }

  // /api/upload
  if (url === '/api/upload' || url === '/api/community/upload') {
    // Generate placeholder uploaded image url
    return {
      data: {
        success: true,
        url: 'https://images.unsplash.com/photo-1614680376593-902f749f7ffc?auto=format&fit=crop&w=600&q=80',
        imageUrl: 'https://images.unsplash.com/photo-1614680376593-902f749f7ffc?auto=format&fit=crop&w=600&q=80'
      }
    };
  }

  // /api/health or /health
  if (url === '/api/health' || url === '/health' || url === '/ready' || url === '/live') {
    return { data: { status: 'healthy', demoMode: true } };
  }

  // Default fallback for any other unhandled /api calls
  return { data: { success: true } };
}

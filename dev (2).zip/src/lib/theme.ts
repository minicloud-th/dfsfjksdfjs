import { useState, useEffect } from "react";

export type Theme = "dark" | "light";

const THEME_STORAGE_KEY = "astrax_theme";

export function getStoredTheme(): Theme {
  try {
    if (typeof localStorage !== "undefined") {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === "light" || saved === "dark") {
        return saved;
      }
    }
  } catch {}
  return "dark"; // Default to dark gaming theme
}

export function applyTheme(theme: Theme) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (theme === "light") {
    root.classList.remove("dark");
    root.classList.add("light");
    root.style.colorScheme = "light";
  } else {
    root.classList.remove("light");
    root.classList.add("dark");
    root.style.colorScheme = "dark";
  }
}

export function setStoredTheme(theme: Theme) {
  try {
    if (typeof localStorage !== "undefined") {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    }
  } catch {}
  applyTheme(theme);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("astrax-theme-change", { detail: theme }));
  }
}

/**
 * Executes a smooth circular ripple transition when toggling theme in BOTH directions
 * (Dark -> Light and Light -> Dark)
 */
export function toggleThemeWithTransition(
  currentTheme: Theme,
  onThemeChanged: (next: Theme) => void,
  event?: React.MouseEvent | MouseEvent
) {
  const nextTheme: Theme = currentTheme === "dark" ? "light" : "dark";

  const isReducedMotion =
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const doc = typeof document !== "undefined" ? (document as any) : null;

  // Resolve click origin coordinates (defaults to button center, or top-center)
  let x = typeof window !== "undefined" ? window.innerWidth / 2 : 0;
  let y = 36;

  if (event && "currentTarget" in event && event.currentTarget) {
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    x = rect.left + rect.width / 2;
    y = rect.top + rect.height / 2;
  } else if (event && "clientX" in event && typeof event.clientX === "number" && event.clientX > 0) {
    x = event.clientX;
    y = event.clientY;
  }

  const endRadius = typeof window !== "undefined"
    ? Math.hypot(
        Math.max(x, window.innerWidth - x),
        Math.max(y, window.innerHeight - y)
      )
    : 1000;

  // If View Transitions API is not supported or user prefers reduced motion, fallback to smooth CSS color interpolation
  if (!doc || !doc.startViewTransition || isReducedMotion) {
    setStoredTheme(nextTheme);
    onThemeChanged(nextTheme);
    return;
  }

  try {
    const transition = doc.startViewTransition(() => {
      setStoredTheme(nextTheme);
      onThemeChanged(nextTheme);
    });

    transition.ready
      .then(() => {
        // In both Dark -> Light and Light -> Dark, the NEW theme cleanly expands outward from the click origin
        const clipPath = [
          `circle(0px at ${x}px ${y}px)`,
          `circle(${endRadius}px at ${x}px ${y}px)`,
        ];

        document.documentElement.animate(
          {
            clipPath: clipPath,
          },
          {
            duration: 520,
            easing: "cubic-bezier(0.22, 1, 0.36, 1)",
            pseudoElement: "::view-transition-new(root)",
          }
        );
      })
      .catch(() => {
        setStoredTheme(nextTheme);
        onThemeChanged(nextTheme);
      });
  } catch {
    setStoredTheme(nextTheme);
    onThemeChanged(nextTheme);
  }
}

export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(getStoredTheme);

  useEffect(() => {
    // Sync DOM with current theme
    applyTheme(theme);

    const handleThemeChange = (e: Event) => {
      const customEvent = e as CustomEvent<Theme>;
      if (customEvent.detail) {
        setThemeState(customEvent.detail);
      } else {
        setThemeState(getStoredTheme());
      }
    };

    window.addEventListener("astrax-theme-change", handleThemeChange);
    return () => window.removeEventListener("astrax-theme-change", handleThemeChange);
  }, [theme]);

  const toggleTheme = (e?: React.MouseEvent | MouseEvent) => {
    toggleThemeWithTransition(theme, setThemeState, e);
  };

  return { theme, toggleTheme, setTheme: setStoredTheme };
}

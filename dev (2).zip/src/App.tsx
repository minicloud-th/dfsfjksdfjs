import {
  BrowserRouter,
  Routes,
  Route,
  useNavigate,
  useLocation,
} from "react-router-dom";
import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  Suspense,
  lazy,
} from "react";
import { sanitizeCategories } from "./utils";
import {
  Loader,
  Gamepad2,
  ListChecks,
  Play,
  Square,
  Check,
  X,
  Shield,
  Terminal,
  CheckCircle2,
  Home,
  ShoppingCart,
  CreditCard,
  Phone,
  Upload,
  Key,
  Crown,
  LogOut,
  User,
  Gift,
  Lock,
  FileImage,
  Database,
  Globe,
  Mail,
  BarChart3,
  Settings,
  Activity,
  FileText,
  AlertTriangle,
  Download,
  ChevronRight,
  ChevronDown,
  Trash2,
  ShieldAlert,
  Plus,
  Ban,
  History,
  Search,
  Copy,
  Menu,
  Server,
  Package,
  Wallet,
  Coins,
  MessageSquare,
  Bot,
  Image as ImageIcon,
  LogIn,
  UserPlus,
  ArrowUpRight,
  Zap,
  Music,
  ShieldCheck,
  ShoppingBag,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Swal from "sweetalert2";
import axios from "axios";
import axiosRetry from "axios-retry";

axiosRetry(axios, {
  retries: 3,
  retryDelay: axiosRetry.exponentialDelay,
  retryCondition: (error) => {
    // Only retry on network errors or 5xx errors.
    // Do NOT retry on 409 (Conflict/OCC) or other client errors.
    return axiosRetry.isNetworkOrIdempotentRequestError(error) || error.response?.status === 429;
  }
});
import { supabase as auth, isSupabaseConfigured } from "./lib/supabase"; // auth here refers to supabase
import { onAuthChange } from "./lib/firebase";
import { SupabaseConfigModal } from "./components/SupabaseConfigModal";

// Add JWT refresh interceptor for 401 Unauthorized
axios.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (
      error.response?.status === 401 && 
      !originalRequest._retry &&
      !originalRequest.url?.includes('/api/signup') &&
      !originalRequest.url?.includes('/api/reset-password')
    ) {
      originalRequest._retry = true;
      try {
        const { data: { session }, error: refreshError } = await auth.auth.getSession();
        if (session?.access_token && !refreshError) {
          axios.defaults.headers.common["Authorization"] = `Bearer ${session.access_token}`;
          originalRequest.headers["Authorization"] = `Bearer ${session.access_token}`;
          return axios(originalRequest);
        }
      } catch (refreshErr) {
        console.error("JWT Refresh failed:", refreshErr);
      }
    }
    return Promise.reject(error);
  }
);

// Remove unused jsQR import to save bundle size
type SupabaseUser = any;
import { useToastStore } from "./lib/toastStore";
import { ToastContainer } from "./components/ui/Toast";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { UserPlan, PurchaseResponse } from "./types";
const ReceiptModal = lazy(() => import("./components/modals/ReceiptModal").then(m => ({ default: m.ReceiptModal })));
import { PopupBanner } from "./components/PopupBanner";
import { Product, SiteStats, Category } from "./types";
import { getAvatarUrl } from "./lib/avatar";
import { getUserRank } from "./lib/rank";

import { DevLogo } from "./components/DevLogo";
import { AppLoader } from "./components/AppLoader";
import { HomeView } from "./components/HomeView";
import { HeaderNavbar } from "./components/HeaderNavbar";
import { MobileDrawer } from "./components/MobileDrawer";
import { Footer as DesignFooter } from "./components/design/Footer";

// Lazy-load secondary views to keep initial bundle size well under 500KB
const ProfileView = lazy(() =>
  import("./components/ProfileView").then((m) => ({ default: m.ProfileView }))
);
const CategoriesView = lazy(() =>
  import("./components/CategoriesView").then((m) => ({ default: m.CategoriesView }))
);
const AuthView = lazy(() =>
  import("./components/AuthView").then((m) => ({ default: m.AuthView }))
);
const ProductDetailView = lazy(() =>
  import("./components/ProductDetailView").then((m) => ({ default: m.ProductDetailView }))
);
const CategoryProductsView = lazy(() =>
  import("./components/CategoryProductsView").then((m) => ({ default: m.CategoryProductsView }))
);
const SearchView = lazy(() =>
  import("./components/SearchView").then((m) => ({ default: m.SearchView }))
);

const AdminDashboard = lazy(() =>
  import("./components/AdminDashboard").then((module) => ({
    default: module.AdminDashboard,
  })),
);
const PageView = lazy(() =>
  import("./components/PageView").then((module) => ({
    default: module.PageView,
  })),
);
const HistoryLogsView = lazy(() =>
  import("./components/HistoryLogsView").then((module) => ({
    default: module.HistoryLogsView,
  })),
);
const WalletView = lazy(() =>
  import("./components/WalletView").then((module) => ({
    default: module.WalletView,
  })),
);
const historyImport = () => import("./components/HistoryView");
const HistoryView = lazy(() =>
  historyImport().then((module) => ({
    default: module.HistoryView,
  })),
);

const ContactView = lazy(() =>
  import("./components/ContactView").then((module) => ({
    default: module.ContactView,
  })),
);
const settingsImport = () => import("./components/SettingsView");
const SettingsView = lazy(() =>
  settingsImport().then((module) => ({
    default: module.SettingsView,
  })),
);
const LogCategoriesView = lazy(() =>
  import("./components/LogCategoriesView").then((module) => ({
    default: module.LogCategoriesView,
  })),
);

import { CustomCursor } from "./components/CustomCursor";

enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
  AUTH = "auth",
}

function AppContent() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminUsername, setAdminUsername] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [userPlan, setUserPlan] = useState<UserPlan | null>(null);
  const [siteSettings, setSiteSettings] = useState(() => {
    const defaultSettings = {
      site_name: "Astrax",
      truewallet_phone: "",
      contact_line: "https://www.facebook.com/share/18emwBsqUf/?mibextid=wwXIfr",
      discord_link: "",
      facebook_link: "",
      instagram_link: "",
      contact_email: "support@astrax.store",
      popup_enabled: true,
      popup_img_url: "",
      popup_link: "",
      stats_users_offset: 0,
      stats_sales_offset: 0,
      spotify_url: "https://youtu.be/WczSfh3gJaU?si=PI1i4X0p0FGbdEfq",
      spotify_autoplay: true,
      announcement_text: "ยินดีต้อนรับสู่ Astrax ศูนย์รวมสินค้าไอดีและบริการดิจิทัลชั้นนำ ระบบซื้อขายทำงานอัตโนมัติ 24 ชั่วโมง - กรณีมีปัญหาโปรดติดต่อแอดมิน",
    };
    try {
      const saved = localStorage.getItem("apex_settings_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.site_name || parsed.site_name === "DEV" || parsed.site_name === "Apex Store" || parsed.site_name === "Zenone") {
          parsed.site_name = "Astrax";
        }
        return parsed;
      }
      return defaultSettings;
    } catch {
      return defaultSettings;
    }
  });

  const [deferMedia, setDeferMedia] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDeferMedia(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  // Removed music state and useEffects

  // Real Products State (No fake products)
  const defaultProducts: Product[] = [];

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem("apex_products_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter(
            (p) =>
              p.id !== "rov_standard" &&
              p.id !== "netflix_4k" &&
              p.id !== "discord_nitro_1m" &&
              !p.id.startsWith("demo-")
          );
        }
      }
    } catch (e) {}
    return defaultProducts;
  });

  const [siteStats, setSiteStats] = useState<SiteStats>(() => {
    const defaultStats = {
      users: 0,
      stock: 0,
      sales: 0,
      topups: 0,
    };
    try {
      const saved = localStorage.getItem("apex_stats_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.sales === 4562 || parsed.users === 1548) {
          return defaultStats;
        }
        return parsed;
      }
      return defaultStats;
    } catch {
      return defaultStats;
    }
  });

  const [customPages, setCustomPages] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("apex_pages_cache");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [categories, setCategories] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem("apex_categories_cache");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return sanitizeCategories(parsed);
      }
    } catch (e) {}
    return [
      { id: "premium_app", name: "แอปพรีเมียม / บันเทิง", title: "แอปพรีเมียม / บันเทิง" },
      { id: "gaming_id", name: "ไอดีเกมส์ยอดนิยม", title: "ไอดีเกมส์ยอดนิยม" },
      { id: "license_key", name: "คีย์ใบอนุญาต / โปรแกรม", title: "คีย์ใบอนุญาต / โปรแกรม" },
      { id: "proxy", name: "พร็อกซีเซสชั่นขั้นสูง", title: "พร็อกซีเซสชั่นขั้นสูง" }
    ];
  });

  const [selectedPage, setSelectedPage] = useState<any>(null);

  const [licenseKeys, setLicenseKeys] = useState<any[]>([]);
  const [usedKeysHistory, setUsedKeysHistory] = useState<any[]>([]);
  const [blockedIPs, setBlockedIPs] = useState<any[]>([]);
  const [adminTab, setAdminTab] = useState<string>("overview");
  const [isIPBlocked, setIsIPBlocked] = useState(false);

  // Navigation State
  type ViewType =
    | "home"
    | "search"
    | "categories"
    | "category_products"
    | "dashboard"
    | "admin"
    | "profile"
    | "logs"
    | "history"
    | "wallet_history"
    | "order_history"
    | "random_history"
    | "settings"
    | "contact"
    | "login"
    | "signup"
    | "wallet"
    | "redeem"
    | "product_detail"
    | "custom_page"
    | "log_categories"
    | "vip_logs"
    | "free_logs";
  const [activeView, setRawActiveView] = useState<ViewType>(() => {
    const hostname = window.location.hostname;
    if (hostname.startsWith("account.")) return "login";
    if (hostname.startsWith("dash.")) return "dashboard";
    return "home";
  });
  const [selectedProductId, setSelectedProductId] = useState<string | null>(
    null,
  );
  const [selectedCategory, setSelectedCategory] = useState<string | null>(
    "all",
  );
  const [usersList, setUsersList] = useState<any[]>([]);

  const setActiveView = useCallback(
    (view: any) => {
      if (activeView === view) return;
      const pathSuffix = view === "home" ? "" : view;
      window.history.pushState(null, "", "/" + pathSuffix);
      setRawActiveView(view);
    },
    [activeView],
  );

  // Handle URL pathname routing
  useEffect(() => {
    const handlePopState = () => {
      let path = window.location.pathname.replace("/", "");
      if (path === "") {
        const hostname = window.location.hostname;
        if (hostname.startsWith("account.")) path = "login";
        else if (hostname.startsWith("dash.")) path = "dashboard";
        else path = "home";
      }

      // Routing aliases
      if (path === "register") path = "signup";
      if (path === "topup") path = "wallet";
      if (path === "store") path = "categories";

      const validViews = [
        "landing",
        "home",
        "search",
        "categories",
        "category_products",
        "dashboard",
        "admin",
        "profile",
        "logs",
        "history",
        "settings",
        "contact",
        "login",
        "signup",
        "wallet",
        "redeem",
        "product_detail",
        "custom_page",
      ];

      if (path && validViews.includes(path)) {
        if (path !== activeView) {
          setRawActiveView(path as any);
        }
      } else if (path === "home" && activeView !== "home") {
        setRawActiveView("home");
      }
    };

    // Initial check on mount
    handlePopState();

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, [activeView]);

  useEffect(() => {
    if (products.length > 0) {
      const params = new URLSearchParams(window.location.search);
      const pid = params.get("product");
      if (pid) {
        const p = products.find(prod => prod.id === pid);
        if (p && activeView !== "product_detail") {
          setSelectedProductId(pid);
          setRawActiveView("product_detail");
          window.history.replaceState(null, "", "/product_detail?product=" + pid);
        }
      }
    }
  }, [products, activeView]);

  useEffect(() => {
    if (isAdmin) {
      document.body.classList.add("admin-mode");
    } else {
      document.body.classList.remove("admin-mode");
    }
  }, [isAdmin]);

  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [showAboutUs, setShowAboutUs] = useState(false);
  const [showContactUs, setShowContactUs] = useState(false);
  const [clientIp, setClientIp] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [forceReveal, setForceReveal] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);

  const [logoClicks, setLogoClicks] = useState(0);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showSupabaseModal, setShowSupabaseModal] = useState(false);

  // Accessibility: Close modals on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowPrivacy(false);
        setShowTerms(false);
        setShowAboutUs(false);
        setShowContactUs(false);
        setShowSupabaseModal(false);
        setPurchasedItemReceipt(null);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  function handleDbError(
    error: unknown,
    operationType: OperationType,
    path: string | null,
  ) {
    const errInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: (window as any)._user?.id,
      },
      operationType,
      path,
    };
    console.error("Database Error: ", JSON.stringify(errInfo));
  }

  const addToast = useToastStore((state) => state.addToast);

  const handleCopy = (text: string, title?: string) => {
    navigator.clipboard.writeText(text);
    addToast({
      type: "success",
      title: title || "สำเร็จ",
      message: "คัดลอกลงในคลิปบอร์ดแล้ว",
      duration: 3000
    });
  };
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(true);
  const [isDesktopUserMenuOpen, setIsDesktopUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDesktopToolsOpen, setIsDesktopToolsOpen] = useState(false);
  const [isMobileToolsOpen, setIsMobileToolsOpen] = useState(false);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMobileMenuOpen]);

  const [vipTab, setVipTab] = useState<"key">("key");

  const [purchaseHistory, setPurchaseHistory] = useState<any[]>([]);

  const [topupHistory, setTopupHistory] = useState<any[]>([]);

  const [purchasesNextCursor, setPurchasesNextCursor] = useState<string | null>(null);
  const isAdminDataLoadingRef = useRef(false);

  useEffect(() => {
    // Topup history is user-specific, we do not cache it in localStorage.
  }, [topupHistory]);

  const handlePurchase = async (product: Product, quantity: number = 1) => {
    if (product.stock < quantity) {
      Swal.fire({
        icon: "error",
        title: "สินค้าไม่เพียงพอ",
        text: "สินค้าหน้านี้มีสต๊อกไม่พอสำหรับจำนวนที่คุณต้องการ",
        confirmButtonColor: "#dc2626",
      });
      return;
    }

    const totalPrice = product.price * quantity;

    if (!userPlan || (userPlan.balance || 0) < totalPrice) {
      Swal.fire({
        icon: "error",
        title: "ยอดเงินไม่เพียงพอ",
        text: `กรุณาเติมเงินก่อนทำการสั่งซื้อสินค้า (ยอดรวม: ฿${totalPrice.toLocaleString()})`,
        confirmButtonColor: "#dc2626",
      });
      return;
    }

    try {
      const idempotencyKey = `buy_${product.id}_${Date.now()}_${Math.random()}`;
      const res = await axios.post<PurchaseResponse>("/api/buy", {
        productId: product.id,
        quantity,
      }, {
        headers: {
          'Idempotency-Key': idempotencyKey
        }
      });
      const {
        purchase: newHistoryItem,
        updatedUser,
        updatedProduct,
      } = res.data || {};

      // Defensive check: if response is missing critical fields, do NOT replace with undefined!
      if (!newHistoryItem || !updatedProduct || !updatedUser) {
        console.warn("[Purchase] Incomplete purchase payload received from server:", res.data);
        // Safely refetch data without corrupting UI state
        try {
          const [productsRes, userRes] = await Promise.allSettled([
            axios.get("/api/products"),
            axios.get("/api/profile/me")
          ]);
          if (productsRes.status === "fulfilled" && Array.isArray(productsRes.value.data)) {
            setProducts(productsRes.value.data);
          }
          if (userRes.status === "fulfilled" && userRes.value.data?.profile) {
            setUserPlan(userRes.value.data.profile);
          }
        } catch (refetchErr) {
          console.warn("[Purchase] Refetch fallback failed:", refetchErr);
        }

        Swal.fire({
          icon: "warning",
          title: "ยังยืนยันผลการสั่งซื้อไม่ได้",
          text: "ไม่สามารถยืนยันผลการสั่งซื้อได้อย่างสมบูรณ์ กรุณาตรวจยอดเงินคงเหลือและประวัติการสั่งซื้อก่อนทำรายการซ้ำ",
          confirmButtonColor: "#f59e0b",
          confirmButtonText: "ไปที่ประวัติการสั่งซื้อ",
        }).then(() => {
          setActiveView("history");
        });
        return;
      }

      // Update state with result from server
      setProducts((prevProducts) =>
        prevProducts.map((p) => (p.id === product.id ? updatedProduct : p)),
      );
      setUserPlan(updatedUser);
      setPurchaseHistory((prev) => [newHistoryItem, ...prev]);

      // Update site stats for admin
      setSiteStats((prev) => ({
        ...prev,
        sales: prev.sales + totalPrice,
        stock: Math.max(0, prev.stock - quantity),
      }));

      // Create and auto download TXT file of purchased items, if quantity > 1 and secretData exists
      if (quantity > 1 && newHistoryItem.secretData) {
        const blob = new Blob([newHistoryItem.secretData], {
          type: "text/plain;charset=utf-8",
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `astrax_order_${product.id}_x${quantity}_${new Date().toISOString().slice(0, 10)}.txt`;
        link.click();
        URL.revokeObjectURL(url);
      }

      // Show success and redirect
      Swal.fire({
        icon: "success",
        title: "สั่งซื้อสำเร็จ!",
        text:
          quantity === 1
            ? `คุณได้สั่งซื้อ ${product.name} สำเร็จแล้ว`
            : "ระบบได้ดาวน์โหลดไฟล์คีย์/ข้อมูลสินค้าให้ท่านอัตโนมัติ (และสามารถตรวจสอบย้อนหลังได้ที่ประวัติการสั่งซื้อ)",
        confirmButtonColor: "#16a34a",
        confirmButtonText: "ตกลง",
      }).then(() => {
        setActiveView("history");
        if (quantity === 1) {
          setPurchasedItemReceipt({
            ...newHistoryItem,
            title: "สั่งซื้อสำเร็จ",
            icon: ShoppingCart,
            bg: "bg-blue-600",
            color: "text-white",
          });
        }
      });
    } catch (err: any) {
      console.error("Purchase error:", err);
      const errorMessage = err.response?.data?.error;
      
      if (errorMessage === "สินค้าในสต๊อกไม่เพียงพอ") {
        Swal.fire({
          icon: "error",
          title: "ขออภัย",
          text: "สินค้าชิ้นนี้เพิ่งหมดไป หรือจำนวนในสต๊อกไม่เพียงพอ",
          confirmButtonColor: "#dc2626",
        });
        
        // Refetch to update stock and disable button
        axios.get("/api/products")
          .then((res) => {
             if (res.data && Array.isArray(res.data)) {
                setProducts(res.data);
                // Also update selected product if we are on the detail page
                if (activeView === "product_detail") {
                   const updated = res.data.find((p: any) => p.id === product.id);
                   if (updated && updated.stock === 0) {
                      // Handled by UI automatically via products state propagation
                   }
                }
             }
          }).catch(console.error);
      } else {
        Swal.fire({
          icon: "error",
          title: "เกิดข้อผิดพลาด",
          text:
            errorMessage ||
            "ไม่สามารถทำรายการได้ในขณะนี้ กรุณาลองใหม่",
          confirmButtonColor: "#dc2626",
        });
      }
    }
  };

  const [isDBReady, setIsDBReady] = useState(false);
  const [dbErrorDetail, setDbErrorDetail] = useState<string | null>(null);
  const [purchasedItemReceipt, setPurchasedItemReceipt] = useState<any>(null);

  const syncUserPlan = useCallback(
    async (newPlan: UserPlan | null, uid: string) => {
      if (!newPlan || !uid) return;
      try {
        await axios.post(`/api/users/${uid}`, newPlan);
      } catch (err) {
        console.error("Failed to sync user plan:", err);
      }
    },
    [],
  );

  // Firebase Auth Listener
  useEffect(() => {
    // Check initial session
    auth.auth.getSession().then(({ data: { session } }) => {
      if (session?.access_token) {
        axios.defaults.headers.common["Authorization"] =
          `Bearer ${session.access_token}`;
      } else {
        delete axios.defaults.headers.common["Authorization"];
      }

      const currentUser: any = session?.user || null;
      if (currentUser) currentUser.uid = currentUser.id;
      setUser(currentUser);
      if (!currentUser) {
        setIsAdmin(false);
      }
    });

    const {
      data: { subscription },
    } = auth.auth.onAuthStateChange(async (event, session) => {
      if (session?.access_token) {
        axios.defaults.headers.common["Authorization"] =
          `Bearer ${session.access_token}`;
      } else {
        delete axios.defaults.headers.common["Authorization"];
      }

      const currentUser: any = session?.user || null;
      if (currentUser) currentUser.uid = currentUser.id;
      setUser(currentUser);
      if (!currentUser) {
        setIsAdmin(false);
        setUserPlan(null);
      }

      if (currentUser && !currentUser.isAnonymous && currentUser.email) {
        try {
          // Fetch user plan from backend
          const res = await axios.get(`/api/users/${currentUser.uid}`);

          if (res.data) {
            setUserPlan(res.data);
            const isAdminRole = 
              res.data.role === "Admin" ||
              res.data.role === "admin" ||
              res.data.role === "owner" ||
              Boolean(res.data.isAdmin) ||
              currentUser.user_metadata?.role === "admin" ||
              currentUser.user_metadata?.role === "owner";
            setIsAdmin(Boolean(isAdminRole));
          } else {
            // First time user registration on backend
            const isUserAdmin = currentUser.user_metadata?.role === "admin";
            const initialPlan = {
              username:
                currentUser.user_metadata?.username || currentUser.displayName || currentUser.email.split("@")[0],
              isPremium: false,
              premiumExpireDate: null,
              balance: 0,
              email: currentUser.email,
              role: isUserAdmin ? "admin" : "user",
            };
            setUserPlan(initialPlan);
            setIsAdmin(isUserAdmin);
            await axios.post(`/api/users/${currentUser.uid}`, initialPlan);
          }
        } catch (err: any) {
          if (err.response?.status === 404) {
            const initialPlan = {
              username:
                currentUser.displayName || currentUser.email.split("@")[0],
              isPremium: false,
              premiumExpireDate: null,
              balance: 0,
              email: currentUser.email,
              role: "user",
            };
            setUserPlan(initialPlan);
            setIsAdmin(false);
            try {
              await axios.post(`/api/users/${currentUser.uid}`, initialPlan);
            } catch (postErr) {
              console.error("Failed to create initial user plan:", postErr);
            }
          } else {
            console.error("Auth sync error:", err);
          }
        }
      }
    });

    // Also listen to Firebase Auth for real OAuth logins (Google, GitHub)
    const unsubFb = onAuthChange((fbUser) => {
      if (fbUser) {
        const email = (fbUser.email || "").toLowerCase();
        const currentUser: any = {
          id: fbUser.uid,
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName,
          user_metadata: {
            username: fbUser.displayName || email.split("@")[0] || "User",
            role: "user",
            avatar_url: fbUser.photoURL || undefined,
          },
        };
        setUser(currentUser);
      }
    });

    return () => {
      subscription?.unsubscribe();
      unsubFb();
    };
  }, []);

  const [logCategories, setLogCategories] = useState<any[]>([]);

  const fetchRequestId = useRef(0);
  const fetchAbortController = useRef<AbortController | null>(null);

  const fetchAllData = useCallback(async () => {
    try {
      if (fetchAbortController.current) {
        fetchAbortController.current.abort();
      }
      const controller = new AbortController();
      fetchAbortController.current = controller;

      fetchRequestId.current += 1;
      const currentRequestId = fetchRequestId.current;

      const fetchApi = async (url: string) => {
        try {
          const res = await axios.get(url, { signal: controller.signal });
          
          if (currentRequestId !== fetchRequestId.current) {
            return { data: null, error: 'stale' };
          }
          
          return { data: res.data, error: null };
        } catch (e: any) {
          if (axios.isCancel(e)) return { data: null, error: 'canceled' };
          if (currentRequestId !== fetchRequestId.current) return { data: null, error: 'stale' };
          const status = e.response?.status;
          const errorMsg = e.response?.data?.error || e.message;
          if (status !== 401 && status !== 403 && status !== 404 && url !== "/api/logs-system") {
             console.error(`Fetch ERROR for ${url}:`, errorMsg);
          } else if (url === "/api/logs-system") {
             return { data: { categories: [], items: [], isVip: false }, error: null };
          }
          return { data: null, error: errorMsg };
        }
      };

      // 1. Critical Landing Page Data - Parallel Fetching with Promise.all
      const publicEndpoints = [
        "/api/settings",
        "/api/products",
        "/api/categories",
        "/api/stats",
        "/api/pages"
      ];

      const mainFetchPromise = Promise.all(
        publicEndpoints.map(url =>
          axios.get(url, { signal: controller.signal })
            .then(res => ({ url, data: res.data, isCanceled: false }))
            .catch(async err => {
              if (axios.isCancel(err)) {
                return { url, data: null, isCanceled: true };
              }

              // Fallback to local cache if network prevented fetch
              let cachedData: any = null;
              try {
                if (url === "/api/settings") cachedData = JSON.parse(localStorage.getItem("apex_settings_cache") || "null");
                else if (url === "/api/products") cachedData = JSON.parse(localStorage.getItem("apex_products_cache") || "null");
                else if (url === "/api/categories") cachedData = JSON.parse(localStorage.getItem("apex_categories_cache") || "null");
                else if (url === "/api/stats") cachedData = JSON.parse(localStorage.getItem("apex_stats_cache") || "null");
                else if (url === "/api/pages") cachedData = JSON.parse(localStorage.getItem("apex_pages_cache") || "null");
              } catch (e) {}

              return { url, data: cachedData, isCanceled: false };
            })
        )
      ).then(async results => {
        if (currentRequestId !== fetchRequestId.current) return;
        
        for (const res of results) {
          if (res.isCanceled) continue;
          
          if (res.url === "/api/settings" && res.data) {
            setSiteSettings(res.data);
            try { localStorage.setItem("apex_settings_cache", JSON.stringify(res.data)); } catch (e) {}
          } else if (res.url === "/api/products" && res.data && Array.isArray(res.data)) {
            setProducts(res.data);
            try { localStorage.setItem("apex_products_cache", JSON.stringify(res.data)); } catch (e) {}
          } else if (res.url === "/api/categories" && res.data && Array.isArray(res.data)) {
            const sanitized = sanitizeCategories(res.data);
            setCategories(sanitized);
            try { localStorage.setItem("apex_categories_cache", JSON.stringify(sanitized)); } catch (e) {}
          } else if (res.url === "/api/stats" && res.data) {
            const statsObj = {
              users: res.data.users ?? 0,
              stock: res.data.stock ?? 0,
              sales: res.data.sales ?? 0,
              topups: res.data.totalTopupsAmount ?? 0,
              totalOrders: res.data.totalOrders ?? 0,
            };
            setSiteStats(statsObj);
            try { localStorage.setItem("apex_stats_cache", JSON.stringify(statsObj)); } catch (e) {}
          } else if (res.url === "/api/pages" && res.data) {
            const d = res.data;
            const pagesToSet = Array.isArray(d) ? d : (d.data && Array.isArray(d.data) ? d.data : []);
            setCustomPages(pagesToSet);
            try { localStorage.setItem("apex_pages_cache", JSON.stringify(pagesToSet)); } catch (e) {}
          }
        }

        // Direct Supabase database sync if configured
        if (isSupabaseConfigured) {
          try {
            const [supaProds, supaCats] = await Promise.all([
              auth.from('products').select('*'),
              auth.from('categories').select('*'),
            ]);
            if (supaProds?.data && Array.isArray(supaProds.data)) {
              setProducts(supaProds.data as any);
              try { localStorage.setItem("apex_products_cache", JSON.stringify(supaProds.data)); } catch (e) {}
            }
            if (supaCats?.data && Array.isArray(supaCats.data) && supaCats.data.length > 0) {
              const sanitized = sanitizeCategories(supaCats.data);
              setCategories(sanitized);
              try { localStorage.setItem("apex_categories_cache", JSON.stringify(sanitized)); } catch (e) {}
            }
          } catch (supaErr) {
            console.warn("Direct Supabase sync check:", supaErr);
          }
        }
      });

      // 2. Secondary Data & User Data
      const logsPromise = fetchApi("/api/logs-system").then(res => {
        if (res.data && Array.isArray(res.data.categories)) {
          setLogCategories(res.data.categories.filter((c: any) => c.isVisible));
        }
      });

      // Health check for DB readiness
      const healthPromise = axios
        .get("/api/health")
        .then(() => {
          setIsDBReady(true);
          setDbErrorDetail(null);
        })
        .catch((e) => {
          setIsDBReady(false);
          let errorMsg =
            e.response?.data?.error || e.message || "Unknown Error";
          setDbErrorDetail(`Backend API ไม่ตอบสนอง (Offline): ${errorMsg}`);
        });

      // Await only the critical home view endpoints + backend health check to reveal the home UI instantly
      await Promise.all([mainFetchPromise, healthPromise]);
    } catch (err: any) {
      // Catch silently
    }
  }, []);

  // Dedicated user-session data retriever (decoupled from the landing page loop)
  const fetchUserData = useCallback(async () => {
    if (!user) return;
    try {
      const [usedKeysRes, purchasesRes, topupsRes] = await Promise.all([
        axios.get("/api/used_keys").catch(() => null),
        axios.get("/api/purchases?limit=20").catch(() => null),
        axios.get("/api/topups").catch(() => null)
      ]);
      if (usedKeysRes?.data) setUsedKeysHistory(usedKeysRes.data);
      if (purchasesRes?.data) {
        const purchaseData = Array.isArray(purchasesRes.data) 
          ? purchasesRes.data 
          : purchasesRes.data.data;
        if (Array.isArray(purchaseData)) {
          setPurchaseHistory(purchaseData);
          if (purchasesRes.data.nextCursor) {
            setPurchasesNextCursor(purchasesRes.data.nextCursor);
          }
        }
      }
      if (topupsRes?.data && Array.isArray(topupsRes.data)) setTopupHistory(topupsRes.data);
    } catch (err) {
      // Handled silently
    }
  }, [user]);

  // Dedicated admin logs/entities data retriever (decoupled from the landing page loop)
  const fetchAdminData = useCallback(async () => {
    if (!isAdmin || isAdminDataLoadingRef.current) return;
    isAdminDataLoadingRef.current = true;
    try {
      const [licensesRes, blockedIpsRes, usersRes] = await Promise.all([
        axios.get("/api/license_keys").catch(() => null),
        axios.get("/api/blocked_ips").catch(() => null),
        axios.get("/api/users").catch(() => null)
      ]);
      if (licensesRes?.data) {
        setLicenseKeys(Array.isArray(licensesRes.data) ? licensesRes.data : Array.isArray(licensesRes.data.data) ? licensesRes.data.data : []);
      }
      if (blockedIpsRes?.data) {
        setBlockedIPs(Array.isArray(blockedIpsRes.data) ? blockedIpsRes.data : Array.isArray(blockedIpsRes.data.data) ? blockedIpsRes.data.data : []);
      }
      if (usersRes?.data) {
        setUsersList(Array.isArray(usersRes.data) ? usersRes.data : Array.isArray(usersRes.data.data) ? usersRes.data.data : []);
      }
    } catch (err) {
      // Handled silently
    } finally {
      isAdminDataLoadingRef.current = false;
    }
  }, [isAdmin]);

  // Combined system-wide data refresh function for user/admin actions
  const refreshAllSystemData = useCallback(async () => {
    await Promise.all([
      fetchAllData(),
      user ? fetchUserData() : Promise.resolve(),
      isAdmin ? fetchAdminData() : Promise.resolve()
    ]);
  }, [fetchAllData, fetchUserData, fetchAdminData, user, isAdmin]);

  // Backend API Listeners - Public static endpoints refreshed every 60 seconds
  useEffect(() => {
    fetchAllData();
    const timer = setInterval(fetchAllData, 60000);
    return () => {
      clearInterval(timer);
      if (fetchAbortController.current) {
        fetchAbortController.current.abort();
      }
    };
  }, [fetchAllData]);

  // Trigger user private data load on session changes
  useEffect(() => {
    if (user) {
      fetchUserData();
    } else {
      setUsedKeysHistory([]);
      setPurchaseHistory([]);
      setTopupHistory([]);
    }
  }, [user, fetchUserData]);

  // Trigger admin private data load on status changes
  useEffect(() => {
    if (isAdmin) {
      fetchAdminData();
    } else {
      setLicenseKeys([]);
      setBlockedIPs([]);
      setUsersList([]);
    }
  }, [isAdmin, fetchAdminData]);

  // App Init & check IP
  useEffect(() => {
    const initApp = async () => {
      const savedUserPlan = localStorage.getItem("astrax_userplan_cache");
      if (savedUserPlan) {
        try {
          setUserPlan(JSON.parse(savedUserPlan));
        } catch {}
      }

      setIsLoaded(true);

      const timeoutId = setTimeout(() => {
        setForceReveal(true);
        setIsLoaded(true);
      }, 1200);

      // Concurrent parallel boot loading of metadata, pages, settings, stats, and client configuration
      try {
        await Promise.all([
          axios.get("/api/health")
            .then(res => {
              const ip = res.data?.clientIp || "Unknown";
              setClientIp(ip);
            })
            .catch(() => {
              setClientIp("offline_local");
            }),
          fetchAllData()
        ]);
      } catch (err) {
        console.error("Initial system parallel data fetch failed:", err);
      } finally {
        clearTimeout(timeoutId);
        setIsLoaded(true);
      }
    };
    initApp();
  }, [fetchAllData]);

  const redeemKey = async (
    keyInput: string,
    usernameInput: string = "ผู้ใช้งานทั่วไป",
  ) => {
    if (!keyInput) return;
    try {
      Swal.fire({
        title: "กำลังตรวจสอบ...",
        allowOutsideClick: false,
        didOpen: () => {
          Swal.showLoading();
        },
        background: "#09090b",
        color: "#fff",
      });

      const res = await axios.post("/api/redeem", { key: keyInput.trim() });
      const { rank, type } = res.data;

      const newPlan = {
        ...userPlan,
        username: usernameInput,
        isPremium: true,
        rank: rank as any,
      };
      setUserPlan(newPlan as any);

      Swal.fire({
        icon: "success",
        title: "ยินดีด้วย!",
        text: `คุณได้รับสิทธิ์ระดับ Premium เรียบร้อยแล้ว`,
        background: "#09090b",
        color: "#fff",
      });
    } catch (err: any) {
      if (
        err.response &&
        err.response.status === 400 &&
        err.response.data.error === "Key not found or used"
      ) {
        Swal.fire({
          icon: "error",
          title: "ไม่พบกุญแจนี้",
          text: "รหัสที่คุณกรอกอาจจะผิด หรือถูกใช้งานไปแล้ว",
          background: "#09090b",
          color: "#fff",
        });
      } else if (err.response && err.response.status === 404) {
        Swal.fire({
          icon: "error",
          title: "ไม่พบกุญแจนี้",
          text: "รหัสที่คุณกรอกอาจจะผิด หรือถูกใช้งานไปแล้ว",
          background: "#09090b",
          color: "#fff",
        });
      } else {
        handleDbError(err, OperationType.WRITE, "license_keys");
        Swal.fire(
          "Error",
          "การสื่อสารล้มเหลว: " + (err.message || "Unknown error"),
          "error",
        );
      }
    }
  };
  const handleLogoClick = () => {
    setActiveView("login");
  };

  const handleLogout = async () => {
    try {
      await auth.auth.signOut();
    } catch (err) {
      console.error("Logout error:", err);
    }
    localStorage.removeItem("apex_admin");
    delete axios.defaults.headers.common["Authorization"];
    setIsAdmin(false);
    setUserPlan(null);
    setUser(null);
    setPurchaseHistory([]);
    setTopupHistory([]);
    setUsedKeysHistory([]);
    setActiveView("home");
    Swal.fire({
      icon: "info",
      title: "ออกจากระบบแล้ว",
      timer: 1500,
      showConfirmButton: false,
      background: "#09090b",
      color: "#fff",
    });
  };

  const resendVerification = async () => {
    // Disabled as requested
  };

  const addLicenseKey = async () => {
    const { value: formValues } = await Swal.fire({
      title: "สร้างคีย์ใหม่",
      html:
        '<select id="swal-input1" class="swal2-input bg-[#050505] border-white/10 text-white w-full">' +
        '<option value="Day">1 วัน (Day)</option>' +
        '<option value="Week">7 วัน (Week)</option>' +
        '<option value="Month">1 เดือน (Month)</option>' +
        '<option value="3Month">3 เดือน (3 Months)</option>' +
        '<option value="Year">1 ปี (Year)</option>' +
        '<option value="Lifetime">ถาวร (Lifetime)</option>' +
        "</select>" +
        '<input id="swal-input2" class="swal2-input bg-[#050505] border-white/10 text-white w-full" placeholder="จำนวนคีย์ (1-50)" type="number" value="1">',
      focusConfirm: false,
      background: "#ffffff",
      color: "#18181b",
      preConfirm: () => {
        return [
          (document.getElementById("swal-input1") as HTMLSelectElement).value,
          (document.getElementById("swal-input2") as HTMLInputElement).value,
        ];
      },
    });

    if (formValues) {
      const [type, countStr] = formValues;
      const count = parseInt(countStr) || 1;

      try {
        const newKeys = [];
        for (let i = 0; i < count; i++) {
          const newKey =
            "DEV-" +
            Math.random().toString(36).substring(2, 10).toUpperCase() +
            "-" +
            Math.random().toString(36).substring(2, 6).toUpperCase();
          newKeys.push({
            key: newKey,
            plan: type,
            status: "active",
            created_at: new Date().toISOString(),
          });
        }
        await axios.post(`/api/license_keys/bulk`, { keys: newKeys });
        Swal.fire("สำเร็จ", `สร้างคีย์ ${count} รายการ สำเร็จ`, "success");
      } catch (err) {
        handleDbError(err, OperationType.WRITE, "license_keys");
        Swal.fire(
          "Error",
          "ไม่สามารถสร้างคีย์ได้: " + (err as Error).message,
          "error",
        );
      }
    }
  };

  const blockIP = async () => {
    const { value: ipData } = await Swal.fire({
      title: "บล็อค IP ผู้ใช้",
      html:
        '<input id="swal-ip" class="swal2-input bg-[#050505] border-white/10 text-white w-full" placeholder="IP Address เช่น 1.1.1.1">' +
        '<input id="swal-reason" class="swal2-input bg-[#050505] border-white/10 text-white w-full" placeholder="เหตุผลการบล็อค">',
      focusConfirm: false,
      background: "#ffffff",
      color: "#18181b",
      preConfirm: () => {
        return [
          (document.getElementById("swal-ip") as HTMLInputElement).value,
          (document.getElementById("swal-reason") as HTMLInputElement).value,
        ];
      },
    });

    if (ipData) {
      const [ip, reason] = ipData;
      if (!ip) return;
      try {
        await axios.post(`/api/blocked_ips`, {
          ip,
          reason: reason || "Violation of terms",
        });
        Swal.fire("สำเร็จ", `บล็อค IP ${ip} สำเร็จ`, "success");
      } catch (err) {
        handleDbError(err, OperationType.WRITE, "blocked_ips");
        Swal.fire(
          "ข้อผิดพลาด",
          "ไม่สามารถบล็อคได้: " + (err as Error).message,
          "error",
        );
      }
    }
  };

  const deleteKey = async (keyId: string) => {
    const result = await Swal.fire({
      title: "ยืนยันการลบ?",
      text: "คุณกำลังลบคีย์ " + keyId,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#27272a",
      confirmButtonText: "ลบออก",
      background: "#ffffff",
      color: "#18181b",
    });

    if (result.isConfirmed) {
      try {
        await axios.delete(`/api/license_keys/${keyId}`);
        Swal.fire("ลบแล้ว", "คีย์ถูกลบออกจากระบบแล้ว", "success");
        setLicenseKeys((prev) => prev.filter((k) => k.id !== keyId));
      } catch (err) {
        handleDbError(err, OperationType.DELETE, "license_keys/" + keyId);
        Swal.fire(
          "ข้อผิดพลาด",
          "ลบไม่สำเร็จ: " + (err as Error).message,
          "error",
        );
      }
    }
  };

  const bulkDeleteKeys = async () => {
    const totalActive = licenseKeys.filter((k) => k.status === "active").length;
    const totalUsed = licenseKeys.filter((k) => k.status === "used").length;
    const totalAll = licenseKeys.length;

    const result = await Swal.fire({
      title: "ลบคีย์หลายรายการ",
      html: `
        <div class="text-left text-sm space-y-2 mb-4">
          <div><span class="text-zinc-500">คีย์ทั้งหมด:</span> <span class="font-bold text-blue-600">${totalAll}</span> รายการ</div>
          <div><span class="text-zinc-500">ยังไม่ได้ใช้:</span> <span class="font-bold text-blue-500">${totalActive}</span> รายการ</div>
          <div><span class="text-zinc-500">ใช้แล้ว:</span> <span class="font-bold text-amber-500">${totalUsed}</span> รายการ</div>
        </div>
        <select id="bulk-delete-type" class="swal2-select" style="width: 100%; font-size: 14px; margin-bottom: 10px;">
          <option value="used">ลบเฉพาะคีย์ที่ใช้แล้ว (Used)</option>
          <option value="active">ลบเฉพาะคีย์ที่ยังไม่ได้ใช้ (Active)</option>
          <option value="all">ลบคีย์ทั้งหมด (All)</option>
        </select>
        <input id="bulk-delete-count" type="number" min="1" class="swal2-input" placeholder="จำนวนที่ต้องการลบ (เว้นว่างเพื่อลบทั้งหมดตามประเภท)" style="width: 100%; font-size: 14px; margin: 0; box-sizing: border-box;">
      `,
      showCancelButton: true,
      confirmButtonText: "ถัดไป",
      cancelButtonText: "ยกเลิก",
      preConfirm: () => {
        const type = (
          document.getElementById("bulk-delete-type") as HTMLSelectElement
        ).value;
        const countStr = (
          document.getElementById("bulk-delete-count") as HTMLInputElement
        ).value;
        const count = countStr ? parseInt(countStr) : null;
        return { type, count };
      },
    });

    if (result.isConfirmed) {
      const { type, count } = result.value;
      let keysToDelete = licenseKeys;
      if (type === "active")
        keysToDelete = keysToDelete.filter((k) => k.status === "active");
      if (type === "used")
        keysToDelete = keysToDelete.filter((k) => k.status === "used");

      if (keysToDelete.length === 0) {
        return Swal.fire("ข้อมูล", "ไม่มีคีย์ในระบบที่ตรงกับเงื่อนไข", "info");
      }

      if (count && count > 0 && count < keysToDelete.length) {
        keysToDelete = keysToDelete.slice(0, count);
      }

      const confirm2 = await Swal.fire({
        title: "ยืนยันขั้นสุดท้าย",
        text: `คุณต้องการลบคีย์จำนวน ${keysToDelete.length} รายการใช่หรือไม่?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ef4444",
        confirmButtonText: "ยืนยันการลบ",
        cancelButtonText: "ยกเลิก",
      });

      if (confirm2.isConfirmed) {
        Swal.fire({
          title: "กำลังลบ...",
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading();
          },
        });
        try {
          const ids = keysToDelete.map((k) => k.id);
          const res = await axios.post("/api/license_keys/bulk_delete", {
            ids,
          });
          const deletedCount = res.data.deletedCount;
          setLicenseKeys((prev) => prev.filter((k) => !ids.includes(k.id)));
          Swal.fire(
            "ลบแล้ว",
            `ลบคีย์สำเร็จจำนวน ${deletedCount} รายการ`,
            "success",
          );
        } catch (err: any) {
          Swal.fire("ข้อผิดพลาด", "ลบไม่สำเร็จ: " + err.message, "error");
        }
      }
    }
  };

  const unblockIP = async (ip: string) => {
    try {
      await axios.delete(`/api/blocked_ips/${ip}`);
      Swal.fire("สำเร็จ", "ปลดบล็อค IP เรียบร้อย", "success");
      setBlockedIPs((prev) => prev.filter((i) => i.ip !== ip));
    } catch (err) {
      handleDbError(err, OperationType.DELETE, "blocked_ips/" + ip);
      Swal.fire("ข้อผิดพลาด", "ไม่สำเร็จ: " + (err as Error).message, "error");
    }
  };

  const [useCustomCursor, setUseCustomCursor] = useState(() => {
    return false; // disable custom cursor by default as requested
  });

  const toggleCustomCursor = () => {
    setUseCustomCursor(prev => {
      const next = !prev;
      localStorage.setItem('apexstore_custom_cursor', String(next));
      if (!next) {
        document.body.style.cursor = 'auto';
        document.documentElement.style.cursor = 'auto';
        // Remove style tag if existing
        const styleId = 'custom-cursor-style-override';
        const el = document.getElementById(styleId);
        if (el) el.remove();
      } else {
        // We let CustomCursor handle it
      }
      return next;
    });
  };

  if (isIPBlocked)
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="w-full max-w-lg bg-[#141414] text-white border border-[#3B82F6]/20 p-8 sm:p-12 text-center relative overflow-hidden rounded-3xl shadow-2xl">
          <ShieldAlert className="w-16 h-16 text-[#2563EB] mx-auto mb-6 animate-pulse" />
          <h1 className="text-2xl sm:text-3xl font-bold text-[#2563EB] mb-4 uppercase tracking-tighter">
            Access Revoked
          </h1>
          <p className="text-zinc-400 text-sm leading-relaxed mb-8">
            ที่อยู่ IP ของคุณ ({clientIp})
            ถูกระงับการเข้าถึงระบบเนื่องจากละเมิดข้อตกลงการใช้งานหรือพบพฤติกรรมที่น่าสงสัย
            หากคุณคิดว่าเป็นความผิดพลาด กรุณาติดต่อผู้ดูแลระบบ Astrax
          </p>
          <div className="bg-[#181818] p-4 text-[11px] text-zinc-400 font-mono mb-8 border border-white/10 rounded-2xl">
            Error Code: ASTRAX_SECURITY_BLOCK_L4
          </div>
          <button
            onClick={() => window.location.reload()}
            className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-3 text-xs font-bold transition-all rounded-full cursor-pointer shadow-lg shadow-blue-600/20 active:scale-95"
          >
            TRY RECONNECTING
          </button>
        </div>
      </div>
    );

  const isHomeViewReady = isLoaded || forceReveal;
  if (!isLoaded && !forceReveal && !dbErrorDetail)
    return <AppLoader progress={loadingProgress > 0 ? loadingProgress : undefined} />;

  return (
    <div id="app-root" className="min-h-screen w-full bg-bg text-label font-sans selection:bg-accent/30 selection:text-white flex flex-col relative transition-colors">
      <Suspense fallback={null}>
        <PopupBanner
          enabled={siteSettings?.popup_enabled ?? true}
          imgUrl={siteSettings?.popup_img_url ?? ""}
          linkUrl={siteSettings?.popup_link ?? ""}
          siteName={siteSettings?.site_name || "Astrax"}
          onNavigate={(view) => {
            setActiveView(view);
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        />
      </Suspense>

      {/* Top Bar with Smooth Shrinking Animation on Scroll */}
      <HeaderNavbar
        activeView={activeView}
        setActiveView={setActiveView}
        user={user}
        userPlan={userPlan}
        isAdmin={isAdmin}
        onLogout={handleLogout}
        onOpenSearch={() => setActiveView("search")}
        onOpenContact={() => setShowContactUs(true)}
        onOpenSupabaseConfig={() => setShowSupabaseModal(true)}
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        isDesktopUserMenuOpen={isDesktopUserMenuOpen}
        setIsDesktopUserMenuOpen={setIsDesktopUserMenuOpen}
        isUserMenuOpen={isUserMenuOpen}
        setIsUserMenuOpen={setIsUserMenuOpen}
        settingsImport={settingsImport}
        historyImport={historyImport}
      />

      {/* Mobile Drawer */}
      <MobileDrawer
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        activeView={activeView}
        setActiveView={(view) => {
          setActiveView(view);
          setIsMobileMenuOpen(false);
        }}
        user={user}
        userPlan={userPlan}
        isAdmin={isAdmin}
        onLogout={handleLogout}
        onOpenContact={() => {
          setShowContactUs(true);
          setIsMobileMenuOpen(false);
        }}
        isUserMenuOpen={isUserMenuOpen}
        setIsUserMenuOpen={setIsUserMenuOpen}
        settingsImport={settingsImport}
        historyImport={historyImport}
        onOpenSearch={() => {
          setActiveView("search");
          setIsMobileMenuOpen(false);
        }}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-h-screen min-w-0 relative overflow-x-hidden">
        <div className="w-full flex-1 flex flex-col pt-2 sm:pt-4 pb-8">
          <Suspense
            fallback={
              <div className="flex-1 w-full flex items-center justify-center min-h-[50vh]">
                <div className="w-7 h-7 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              </div>
            }
          >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="flex-1 w-full flex flex-col min-h-0"
            >
            {activeView === "categories" && (
              <CategoriesView
                categories={categories}
                products={products}
                siteSettings={siteSettings}
                onBack={() => setActiveView("home")}
                onSelectCategory={(cat) => {
                  setSelectedCategory(cat);
                }}
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
              />
            )}
            {activeView === "category_products" && selectedCategory && (
              <CategoryProductsView
                category={selectedCategory}
                categories={categories}
                products={products}
                onBack={() => setActiveView("categories")}
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
              />
            )}
            {activeView === "search" && (
              <SearchView
                products={products}
                onBack={() =>
                  window.history.length > 1
                    ? window.history.back()
                    : setActiveView("home")
                }
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
              />
            )}
            {activeView === "home" && (
              <HomeView
                products={products}
                categories={categories}
                stats={siteStats}
                user={userPlan || user}
                siteSettings={siteSettings}
                purchaseHistory={purchaseHistory}
                setActiveView={setActiveView}
                onProductClick={(id) => {
                  setSelectedProductId(id);
                  setActiveView("product_detail");
                }}
                onSelectCategory={(cat) => {
                  setSelectedCategory(cat);
                  setActiveView("category_products");
                }}
              />
            )}
            {activeView === "product_detail" && selectedProductId && (
              <ProductDetailView
                product={products.find((p) => p.id === selectedProductId)!}
                user={user}
                onBack={() => setActiveView("home")}
                handlePurchase={async (p, q) => {
                  await handlePurchase(p, q);
                }}
                setActiveView={setActiveView}
              />
            )}
            {activeView === "contact" && (
              <ContactView
                onBack={() => setActiveView("home")}
                facebookLink={
                  siteSettings?.facebook_link || siteSettings?.contact_line
                }
                discordLink={siteSettings?.discord_link}
                instagramLink={siteSettings?.instagram_link}
                contactEmail={siteSettings?.contact_email}
              />
            )}
            {activeView === "custom_page" && selectedPage && (
              <PageView
                page={selectedPage}
                onBack={() => setActiveView("home")}
              />
            )}
            {activeView === "login" && (
              <AuthView initialMode="login" setActiveView={setActiveView} siteSettings={siteSettings} />
            )}
            {activeView === "signup" && (
              <AuthView initialMode="signup" setActiveView={setActiveView} siteSettings={siteSettings} />
            )}
            {activeView === "profile" && (
              <ProfileView
                user={user}
                userPlan={userPlan}
                setUserPlan={setUserPlan}
                clientIp={clientIp}
                setActiveView={setActiveView}
                handleLogout={handleLogout}
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
              />
            )}
            {activeView === "logs" && (
              <HistoryLogsView
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
              />
            )}
            {activeView === "log_categories" && (
              <LogCategoriesView
                userPlan={userPlan}
                isAdmin={isAdmin}
                onNavigateAction={(action) =>
                  setActiveView(action as void | any)
                }
                filterType="all"
              />
            )}
            {activeView === "vip_logs" && (
              <LogCategoriesView
                userPlan={userPlan}
                isAdmin={isAdmin}
                onNavigateAction={(action) =>
                  setActiveView(action as void | any)
                }
                filterType="vip"
              />
            )}
            {activeView === "free_logs" && (
              <LogCategoriesView
                userPlan={userPlan}
                isAdmin={isAdmin}
                onNavigateAction={(action) =>
                  setActiveView(action as void | any)
                }
                filterType="free"
              />
            )}
            {activeView === "history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
              />
            )}
            {activeView === "order_history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                defaultTab="normal_product"
              />
            )}
            {activeView === "random_history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                defaultTab="special_product"
              />
            )}
            {activeView === "wallet_history" && (
              <HistoryView
                purchaseHistory={purchaseHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                topupHistory={topupHistory.filter(
                  (h) => h.uid === user?.id || h.userId === user?.id,
                )}
                usedKeysHistory={usedKeysHistory.filter(
                  (h) => h.uid === user?.id,
                )}
                defaultTab="topup_gift"
              />
            )}
            {activeView === "settings" && (
              <SettingsView setActiveView={setActiveView} user={user} useCustomCursor={useCustomCursor} toggleCustomCursor={toggleCustomCursor} />
            )}
            {activeView === "wallet" && (
              <WalletView
                userPlan={userPlan}
                setUserPlan={setUserPlan}
                userId={user?.uid}
                siteSettings={siteSettings}
                topupHistory={topupHistory}
                setActiveView={setActiveView}
                onTopupSuccess={(entry) => {
                  setTopupHistory((prev) => [entry, ...prev]);
                  setSiteStats((prev) => ({
                    ...prev,
                    topups:
                      (prev.topups || 0) + (entry.amount || entry.money || 0),
                  }));
                }}
              />
            )}
            {activeView === "admin" && isAdmin && (
              <AdminDashboard
                licenseKeys={licenseKeys}
                usedKeysHistory={usedKeysHistory}
                blockedIPs={blockedIPs}
                adminTab={adminTab}
                setAdminTab={setAdminTab}
                isDBReady={isDBReady}
                dbErrorDetail={dbErrorDetail}
                adminUsername={adminUsername}
                setIsAdmin={setIsAdmin}
                addLicenseKey={addLicenseKey}
                blockIP={blockIP}
                deleteKey={deleteKey}
                bulkDeleteKeys={bulkDeleteKeys}
                unblockIP={unblockIP}
                products={products}
                setProducts={setProducts}
                siteStats={siteStats}
                setSiteStats={setSiteStats}
                customPages={customPages}
                setCustomPages={setCustomPages}
                categories={categories}
                setCategories={setCategories}
                usersList={usersList}
                purchaseHistory={purchaseHistory}
                topupHistory={topupHistory}
                onBackToStore={() => setActiveView("home")}
                onRefreshData={refreshAllSystemData}
                onOpenSupabaseConfig={() => setShowSupabaseModal(true)}
              />
            )}
            </motion.div>
          </AnimatePresence>
          </Suspense>
        </div>

        {/* Sleek Minimal Footer */}
        <DesignFooter
          setActiveView={setActiveView}
          siteSettings={siteSettings}
          onOpenTerms={() => setShowTerms(true)}
          onOpenPrivacy={() => setShowPrivacy(true)}
          onOpenContact={() => setShowContactUs(true)}
        />

        {/* Modals */}
        <AnimatePresence>
          {showPrivacy && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-[100] font-sans"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="bg-surface/95 border border-separator p-6 sm:p-8 max-w-3xl w-full max-h-[90vh] flex flex-col relative rounded-3xl shadow-2xl backdrop-blur-xl text-label"
              >
                <h2 className="text-xl sm:text-2xl font-semibold mb-6 text-label flex items-center gap-2">
                  <Shield className="w-6 h-6 shrink-0 text-accent" />{" "}
                  นโยบายความเป็นส่วนตัว (Privacy Policy)
                </h2>
                <div className="overflow-y-auto pr-2 sm:pr-4 space-y-6 text-xs sm:text-sm leading-relaxed text-label-2 scrollbar-thin scrollbar-thumb-surface-2 flex-1">
                  <p>
                    <strong>อัปเดตล่าสุด:</strong>{" "}
                    {new Date().toLocaleDateString("th-TH", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      1. ข้อมูลที่เราเก็บรวบรวม
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>
                        <strong>ข้อมูลระบุตัวตนและบัญชี:</strong>{" "}
                        เมื่อคุณสมัครสมาชิก เราอาจจัดเก็บข้อมูลเช่น อีเมล
                        ชื่อผู้ใช้ รหัสผ่าน (ที่ถูกเข้ารหัสและทำแฮชอย่างแน่นหนา)
                        ข้อมูลสิทธิ์การใช้งาน (Role/VIP) และเครดิตคงเหลือของคุณ
                      </li>
                      <li>
                        <strong>ข้อมูลการทำธุรกรรม (Transaction Data):</strong>{" "}
                        หากมีการทำธุรกรรมเติมเงินซื้อสินค้า
                        เราจะเก็บข้อมูลบันทึกการทำธุรกรรม เช่น เวลา จำนวนเงิน
                        หมายเลขอ้างอิง เพื่อประเมิน วิเคราะห์
                        และป้องกันการหลอกลวง
                      </li>
                      <li>
                        <strong>ข้อมูล IP Address และ Log Files:</strong>{" "}
                        ตามข้อบังคับและเพื่อความปลอดภัย เรามีการเก็บบันทึก IP
                        Address, Browser Agent, เวลาเข้าระบบ
                        และพฤติกรรมการใช้งาน
                        เพื่อใช้เป็นหลักฐานและป้องกันเหตุโจมตีระบบ (DDoS/BotNet)
                      </li>
                      <li>
                        <strong>
                          ข้อมูลการเชื่อมต่อคู่ค้า (External API):
                        </strong>{" "}
                        หากคุณผูกบัญชีบริการภายนอก เช่น Discord หรือ Telegram
                        เรามีความจำเป็นต้องดึงข้อมูลสาธารณะหรือ Token
                        ที่คุณอนุญาตเพื่อใช้ทำงานบนแพลตฟอร์มของเรา
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      2. การปกป้องข้อมูลและความปลอดภัยของบัญชี
                    </h3>
                    <p className="mb-2">
                      ทางแพลตฟอร์มมุ่งเน้นการรักษาความมั่นคงปลอดภัยของข้อมูลบัญชีผู้ใช้งาน
                      และการทำธุรกรรมทางการเงินอย่างเข้มงวด
                    </p>
                    <p>
                      รหัสผ่านและคีย์สินค้าจะได้รับการเข้ารหัสและคุ้มครองอย่างปลอดภัย
                      โดยไม่มีการเปิดเผยข้อมูลสำคัญให้แก่บุคคลภายนอกโดยไม่ได้รับอนุญาต
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      3. การเปิดเผยข้อมูลแก่บุคคลที่สาม
                    </h3>
                    <p>
                      เอเพ็กซ์สโตร์จะไม่นำข้อมูลส่วนตัว อีเมล
                      หรือเงินคงเหลือของคุณไปเปิดเผย จำหน่าย
                      หรือแลกเปลี่ยนกับบุคคลที่สามโดยเด็ดขาด <em>เว้นแต่:</em>
                    </p>
                    <ul className="list-disc pl-5 space-y-1 mt-2">
                      <li>
                        ผู้ให้บริการประมวลผลที่จำเป็น (Cloud Hosting, Payment
                        Gateway) เฉพาะส่วนที่ต้องให้บริการ
                      </li>
                      <li>
                        เป็นไปเพื่อปฏิบัติตามกฎหมาย มีคำสั่งศาล
                        หรือคำสั่งของหน่วยงานที่มีอำนาจบังคับตามกฎหมาย
                      </li>
                      <li>
                        เพื่อใช้ป้องกันและรักษาความปลอดภัยต่อชีวิต
                        หรือปกป้องทรัพย์สินของ Astrax{" "}
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      4. คุกกี้ (Cookies) และการจัดเก็บ Cache
                    </h3>
                    <p>
                      เราใช้คุกกี้ Session และ Local Storage
                      เพื่อช่วยจดจำการเข้าสู่ระบบ สถานะการทำงาน หรือตั้งค่าธีม
                      ลดภาระที่คุณต้องล็อกอินซ้ำ ไม่มีโฆษณาแทรกแซง ไม่มีการใช้
                      Tracking Pixels นำมาวิเคราะห์ขายต่อ หากคุณลบแคช
                      การเชื่อมต่อและการจดจำทั้งหมดที่คุณบันทึกไว้ในเบราว์เซอร์จะถูกล้างใหม่ทันที
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      5. สิทธิของเจ้าของข้อมูล (Data Subject Rights)
                    </h3>
                    <p>
                      ภายใต้กฎหมายที่มีผลบังคับ คุณมีสิทธิขอเข้าถึง แก้ไข
                      แจ้งขอสำเนา หรือลบข้อมูลบัญชีของตนเองได้บางส่วน ทั้งนี้
                      อาจมีข้อยกเว้นสำหรับประวัติการทำรายได้ ธุรกรรม
                      ข้อมูลล็อกที่ขัดกฎหมายการลบข้อมูล (Data Retention)
                      หากประสงค์ติดต่อเพื่อลบข้อมูล
                      สามารถขอความช่วยเหลือแอดมินได้ผ่านหน้าติดต่อ
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      6. การแก้ไขเปลี่ยนแปลงนโยบาย
                    </h3>
                    <p>
                      ระบบขอสงวนสิทธิ์ในการแก้ไขปรับปรุง
                      เปลี่ยนแปลงข้อความในนโยบายฉบับนี้โดยไม่ต้องแจ้งให้ผู้ใช้ทราบล่วงหน้า
                      โดยสามารถตรวจสอบวันได้ที่หน้าหัวข้อ “อัปเดตล่าสุด”
                      การเข้าถึงแพลตฟอร์มอย่างต่อเนื่องถือเป็นการยืนยันและการยอมรับข้อตกลงฉบับปรับปรุงแล้ว
                    </p>
                  </div>
                </div>
                <div className="pt-5 mt-5 border-t border-white/[0.08] flex gap-3 flex-col sm:flex-row justify-end">
                  <button
                    onClick={() => setShowPrivacy(false)}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-medium py-2.5 px-6 transition-colors w-full sm:w-auto rounded-2xl text-xs cursor-pointer shadow-lg shadow-blue-600/20"
                  >
                    ทำความเข้าใจและปิดหน้าต่าง
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}

          {showTerms && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[100] font-sans"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="bg-surface/95 border border-separator p-6 sm:p-8 max-w-3xl w-full max-h-[90vh] flex flex-col relative rounded-3xl shadow-2xl backdrop-blur-xl text-label"
              >
                <h2 className="text-xl sm:text-2xl font-semibold mb-6 flex items-center gap-2 text-label">
                  <ListChecks className="w-6 h-6 shrink-0 text-accent" />{" "}
                  ข้อกำหนดการใช้งาน (Terms of Use)
                </h2>
                <div className="overflow-y-auto pr-2 sm:pr-4 space-y-6 text-xs sm:text-sm leading-relaxed text-label-2 scrollbar-thin scrollbar-thumb-surface-2 flex-1">
                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      1. การรับรองความยินยอมและผูกพัน
                    </h3>
                    <p>
                      การเข้าถึงและใช้งานบริการ เครื่องมือตรวจสอบ บอท
                      และผลิตภัณฑ์ของเรา
                      ถือเป็นการรับรองว่าท่านได้ทำความเข้าใจและตกลงยอมรับเงื่อนไขการใช้บริการของ{" "}
                      <strong>Astrax</strong> อย่างครบถ้วนทุกประการ
                      หากคุณไม่เห็นด้วยกับกฎหมายและข้อบังคับเหล่านี้กรุณายุติการเข้าถึงและการใช้งานโดยทันที
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      2. ขอบเขตสิทธิ์ หน้าที่ และการใช้งานที่ยอมรับได้ (AUP)
                    </h3>
                    <p className="mb-2">
                      คุณตกลงที่จะใช้สิทธิ์ในการเข้าถึงที่เรารับรอง
                      เพื่อจุดประสงค์ส่วนตัวที่ถูกต้องตามกฎหมาย และยินยอมที่จะ{" "}
                      <strong>ไม่กระทำ</strong> สิ่งเหล่านี้ไม่ว่ากรณีใดๆ :
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>
                        <strong>
                          ห้ามวิศวกรรมย้อนกลับ (No Reverse Engineering):
                        </strong>{" "}
                        ห้ามดัดแปลง ชำแหละเจาะระบบ สแกนพอร์ต จำลอง API เถื่อน นำ
                        API ผิดกฎหมายหรือ Bypass
                        เข้าใช้บริการของเราโดยไม่ได้รับอนุญาต
                      </li>
                      <li>
                        <strong>
                          ห้ามกระทำละเมิดแพลตฟอร์มรุนแรง (Anti-DDoS, Spamming):
                        </strong>{" "}
                        ห้ามทดสอบความปลอดภัย ก่อความล่าช้า หรือกระหน่ำยิงแพ็กเกจ
                        (Flood Requests) เพื่อทำลายความเสถียรของเซิร์ฟเวอร์
                      </li>
                      <li>
                        <strong>ข้อพิพาทความเป็นเจ้าของข้อมูลส่วนบุคคล:</strong>{" "}
                        ผู้ใช้งานจะต้องเป็นเจ้าของข้อมูล พาสเวิร์ด คีย์ บัญชี
                        หรือมีสิทธิ์อนุญาตโดยชอบธรรมเท่านั้น
                        หากท่านนำไปใช้งานในทางละเมิดผู้อื่น สิทธิ
                        ความรับผิดชอบทางกฎหมายใดๆ
                        ถือเป็นความรับผิดชอบของตัวลูกค้า/ผู้ใช้งานโดยเพียงผู้เดียวเท่านั้น
                        ทางทีมงานจะไม่มีส่วนรู้เห็นในทุกกรณี
                      </li>
                      <li>
                        <strong>การบ่อนทำลาย/แอบอ้าง:</strong> ห้ามคัดลอก
                        ทำสำเนาเนื้อหา และผลิตภัณฑ์เพื่อไปชุบมือเปิบ แอบอ้าง
                        หรือขายนอกแพลตฟอร์มโดยไม่ได้รับอนุญาต
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      3. การชำระเงิน การเติมเงิน และนโยบายล้างบางเครดิต (No
                      Refund Policy)
                    </h3>
                    <p className="mb-2">
                      เมื่อคุณยืนยันเติมเครดิต ชำระคีย์ โอนเงินซื้อบัญชี
                      หรือสินค้าดิจิทัลใน Astrax คำสั่งซื้อดังกล่าว{" "}
                      <strong>
                        ไม่สามารถคืนเป็นเงินสด (Non-Refundable) ในทุกกรณี
                      </strong>{" "}
                      เครดิตในรหัสไม่สามารถโยกย้ายข้ามผู้ใช้ได้
                      หากพบความผิดปกติของการเติมเงิน บัตรปลอม หรือการโกง
                      แอดมินมีสิทธิเต็มที่ในการเพิกถอนยอด ล็อคแบน
                      และยึดสินค้าทั้งหมดทันที
                    </p>
                    <p>
                      สินค้ารับประกันการใช้งาน
                      จะถูกอ้างอิงตามระยะเวลาประกันของสินค้าชิ้นนั้นๆ
                      หากเลยเงื่อนไขที่กำหนดไว้จะไม่รับผิดชอบทุกกรณี
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      4. ข้อยกเว้นและข้อจำกัดความรับผิดชอบ (Disclaimer)
                    </h3>
                    <p className="mb-2">
                      การทำธุรกรรมและเครื่องมือนี้ ทำงานในรูปแบบ "ตามสภาพ (As
                      is)" เราไม่รับประกัน 100% ว่าไม่มีข้อบกพร่อง การขัดข้อง
                      ล่าช้า หรือผลเช็คต่างๆ จะแม่นยำเสมอไป
                      ทั้งนี้เครื่องมือเราไร้สถานะ (No-Affiliation)
                      ต่อนายจ้างหรือบริษัทแม่ของช่องโซเชียลนั้นๆ
                    </p>
                    <p>
                      เราจะไม่รับผิดชอบจากความสูญเสีย โดนแบน ยอดวิวตก
                      หรือความเสียหายในทางอ้อม ทางการค้า
                      หรือทางปกครองที่เกิดจากการเข้าใช้บริการ ข้อมูลต่างๆ
                      สามารถเข้าถึงได้ขึ้นอยู่กับความเสี่ยงของตนเอง
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      5. สิทธิของการยุติการให้บริการ และ IP Ban
                    </h3>
                    <p>
                      ทีมงาน Astrax ถือสิทธิเด็ดขาดสูงสุดในการเตะ
                      หรือถอดถอนผู้ใช้ ระงับบัญชี (Ban)
                      เปลี่ยนแปลงแก้ไขการใช้งาน และระงับช่องทางการเข้าถึง (IP
                      Blocking) โดยไม่ต้องแจ้งตักเตือนรวมถึงชดใช้ค่าเสียหายใดๆ
                      ให้แก่ผู้ใช้งาน หากพบการทุจริต หรือคุกคามเจ้าหน้าที่
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      6. การจัดการและระบบต่างๆ
                    </h3>
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      ระบบและบริการของเรา
                    </h3>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>
                        <strong>Digital Marketplace & VIP Tiers:</strong>{" "}
                        ร้านค้าจำหน่ายผลิตภัณฑ์ซอฟต์แวร์ คีย์โปรแกรม
                        และบริการพรีเมียม ด้วยระบบจัดการคลังสินค้าอัตโนมัติ
                        ตัดยอดและส่งมอบสินค้าผ่านระบบที่ปลอดภัยตลอด 24 ชั่วโมง
                      </li>
                      <li>
                        <strong>Community & Support:</strong>{" "}
                        ระบบบริการลูกค้า สอบถามข้อมูล ยืนยันคำสั่งซื้อ
                        และสิทธิประโยชน์สำหรับสมาชิกคอมมูนิตี้
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      ความมุ่งมั่นด้านความปลอดภัย (Security Commitment)
                    </h3>
                    <p>
                      รากฐานของโปรเจ็กต์คือการเก็บรักษาข้อมูลให้เป็นความลับ
                      (Confidentiality) และความปลอดภัยสูงสุดของระบบการชำระเงิน
                      สถาปัตยกรรมเซิร์ฟเวอร์ของเรามีระบบการเข้ารหัสข้อมูลที่รัดกุม
                      การตรวจสอบสิทธิ์แบบหลายชั้น และการป้องกันการทำธุรกรรมซ้ำซ้อน
                      ทำให้ข้อมูลการสั่งซื้อของคุณได้รับการดูแลอย่างมืออาชีพ
                    </p>
                  </div>

                  <div>
                    <h3 className="font-bold text-white text-base mb-2">
                      ช่องทางติดต่อคอมมูนิตี้ (Contact & Community)
                    </h3>
                    <p className="mb-2">
                      เราไม่ได้มีแต่เว็บขายของ
                      แต่เราเติบโตด้วยแรงสุนทรีย์ของคอมมูนิตี้
                      หากคุณประสบปัญหาในการใช้งาน พบช่องโหว่
                      หรืออยากพูดคุยเสนอแนวทางใหม่ๆ:
                    </p>
                    <ul className="list-disc pl-5">
                      <li>
                        <strong>Discord Server:</strong> สถานที่เชื่อมสัมพันธ์
                        ร้องขอเครดิต หรือสอบถามการเซ็ตอัปบอท
                      </li>
                      <li>
                        <strong>Line Official:</strong> ทีม Support
                        โดยผู้ดูแลมืออาชีพ (ตอบกลับรวดเร็วที่สุด)
                      </li>
                    </ul>
                    <p className="mt-2 text-muted-foreground italic">
                      "ขอบคุณผู้ใช้งานและพันธมิตรทุกคน
                      ที่เล็งเห็นคุณค่าและก้าวเดินไปพร้อมกับ Astrax
                      ขวากหนามทางดิจิทัลไหนที่ยาก... เราพร้อมเบิกทางให้คุณ"
                    </p>
                  </div>
                </div>
                <div className="pt-5 mt-5 border-t border-white/[0.08] flex justify-end w-full">
                  <button
                    onClick={() => setShowAboutUs(false)}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-medium py-2.5 px-6 transition-colors w-full sm:w-auto rounded-2xl text-xs cursor-pointer shadow-lg shadow-blue-600/20"
                  >
                    ปิดหน้าต่างนี้
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}

          {showContactUs && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[100] font-sans"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="bg-surface/95 border border-separator p-6 sm:p-8 max-w-md w-full flex flex-col relative rounded-3xl shadow-2xl backdrop-blur-xl text-label"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl sm:text-2xl font-semibold flex items-center gap-2 text-label">
                    <Phone className="w-5 h-5 shrink-0 text-accent" />{" "}
                    ติดต่อเรา
                  </h2>
                  <button
                    onClick={() => setShowContactUs(false)}
                    className="p-2 hover:bg-surface-2 transition-colors rounded-full text-label-3 hover:text-label cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3">
                  <a
                    href="https://discord.gg/EvFjgkSB4W"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] hover:border-[#5865F2]/40 text-white transition-all duration-300 group rounded-2xl"
                  >
                    <div className="w-11 h-11 bg-[#5865F2]/10 border border-[#5865F2]/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform rounded-xl text-[#5865F2]">
                      <span className="font-bold text-lg block">D</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm text-white">Discord</h3>
                      <p className="text-zinc-400 text-xs mt-0.5">
                        เข้าร่วมเซิร์ฟเวอร์คอมมูนิตี้ของเรา
                      </p>
                    </div>
                  </a>

                  {siteSettings?.contact_email && (
                    <a
                      href={`mailto:${siteSettings.contact_email}`}
                      className="flex items-center gap-4 p-4 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] hover:border-blue-500/40 text-white transition-all duration-300 group rounded-2xl"
                    >
                      <div className="w-11 h-11 bg-blue-500/10 border border-blue-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform rounded-xl text-blue-400">
                        <Mail className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-white">Email</h3>
                        <p className="text-zinc-400 text-xs mt-0.5">
                          {siteSettings.contact_email}
                        </p>
                      </div>
                    </a>
                  )}
                </div>

                <div className="pt-5 mt-5 border-t border-white/[0.08] flex justify-end w-full">
                  <button
                    onClick={() => setShowContactUs(false)}
                    className="bg-white/[0.06] hover:bg-white/[0.1] text-zinc-300 hover:text-white font-medium py-2.5 px-6 transition-colors w-full sm:w-auto rounded-2xl text-xs cursor-pointer"
                  >
                    ปิดหน้าต่างนี้
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Modals - Restricted strictly to authenticated admin */}
        <SupabaseConfigModal
          isOpen={Boolean(isAdmin && showSupabaseModal)}
          onClose={() => setShowSupabaseModal(false)}
          onSuccess={() => refreshAllSystemData()}
        />

        <Suspense fallback={null}>
          {purchasedItemReceipt && (
            <ReceiptModal
              selectedItem={purchasedItemReceipt}
              setSelectedItem={(item) => {
                setPurchasedItemReceipt(item);
                // When modal is manually closed
                if (!item) {
                  setActiveView("history");
                }
              }}
            />
          )}
        </Suspense>

      </div>

      {/* Mobile Bottom Navigation Bar removed as per request */}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="*" element={<AppContent />} />
        </Routes>
      </BrowserRouter>
      <ToastContainer />
    </ErrorBoundary>
  );
}

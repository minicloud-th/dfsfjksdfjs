import React from "react";
import { CategoriesView } from "./CategoriesView";
import { Product, Category } from "../types";

interface CategoryProductsViewProps {
  category: string;
  categories: Category[];
  products: Product[];
  isLoading?: boolean;
  onBack: () => void;
  onProductClick: (id: string) => void;
}

export const CategoryProductsView: React.FC<CategoryProductsViewProps> = ({
  category,
  categories = [],
  products = [],
  onBack,
  onProductClick,
}) => {
  return (
    <CategoriesView
      categories={categories}
      products={products}
      initialCategory={category}
      onBack={onBack}
      onProductClick={onProductClick}
    />
  );
};

export default CategoryProductsView;

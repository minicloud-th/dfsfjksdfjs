import React, { useState, useMemo } from "react";
import {
  LayoutGrid,
  Globe,
  Tag,
  Bot,
  Gamepad2,
  Tv,
  Wrench,
  Sparkles,
  ChevronRight,
  Search,
  Package,
  X,
  ArrowLeft,
} from "lucide-react";
import { Category, Product } from "../types";
import { ProductCard } from "./ProductCard";

interface CategoriesViewProps {
  categories: Category[];
  products: Product[];
  siteSettings?: any;
  initialCategory?: string;
  onBack: () => void;
  onSelectCategory?: (categoryId: string) => void;
  onProductClick?: (id: string) => void;
}

// Clean helper icon for categories
const getCategoryIcon = (name: string, id: string) => {
  const query = `${name} ${id}`.toLowerCase();
  if (
    query.includes("social account") ||
    query.includes("account") ||
    query.includes("tag")
  ) {
    return <Tag className="w-3.5 h-3.5 text-zinc-400 shrink-0" />;
  }
  if (
    query.includes("social") ||
    query.includes("global") ||
    query.includes("web")
  ) {
    return <Globe className="w-3.5 h-3.5 text-[#2997FF] shrink-0" />;
  }
  if (
    query.includes("ai") ||
    query.includes("gpt") ||
    query.includes("bot") ||
    query.includes("claude")
  ) {
    return <Bot className="w-3.5 h-3.5 text-purple-400 shrink-0" />;
  }
  if (
    query.includes("game") ||
    query.includes("rov") ||
    query.includes("valorant")
  ) {
    return <Gamepad2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
  }
  if (
    query.includes("stream") ||
    query.includes("netflix") ||
    query.includes("app") ||
    query.includes("tv")
  ) {
    return <Tv className="w-3.5 h-3.5 text-rose-400 shrink-0" />;
  }
  if (
    query.includes("tool") ||
    query.includes("soft") ||
    query.includes("key") ||
    query.includes("win")
  ) {
    return <Wrench className="w-3.5 h-3.5 text-cyan-400 shrink-0" />;
  }
  return <Sparkles className="w-3.5 h-3.5 text-[#2997FF] shrink-0" />;
};

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  categories = [],
  products = [],
  siteSettings,
  initialCategory = "all",
  onBack,
  onSelectCategory,
  onProductClick,
}) => {
  const [selectedCategory, setSelectedCategory] =
    useState<string>(initialCategory);
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Build a normalized list of categories with product counts
  const categoryItems = useMemo(() => {
    const map = new Map<
      string,
      { id: string; name: string; title: string; count: number }
    >();

    categories.forEach((cat) => {
      const catId = cat.id || cat.name;
      map.set(catId, {
        id: catId,
        name: cat.name || cat.title,
        title: cat.title || cat.name,
        count: 0,
      });
    });

    products.forEach((p) => {
      const c = p.category;
      if (!c) return;
      let matched = false;
      for (const [key, val] of map.entries()) {
        if (key === c || val.name === c || val.title === c) {
          val.count += 1;
          matched = true;
          break;
        }
      }
      if (!matched) {
        map.set(c, {
          id: c,
          name: c,
          title: c,
          count: 1,
        });
      }
    });

    return Array.from(map.values());
  }, [categories, products]);

  // Filter products based on active category & search query
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      let matchesCat = false;
      if (selectedCategory === "all") {
        matchesCat = true;
      } else {
        const catInfo = categoryItems.find(
          (c) =>
            c.id === selectedCategory ||
            c.name === selectedCategory ||
            c.title === selectedCategory
        );
        matchesCat =
          p.category === selectedCategory ||
          p.category === catInfo?.name ||
          p.category === catInfo?.title ||
          p.category === catInfo?.id;
      }

      if (!matchesCat) return false;
      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      return (
        p.name.toLowerCase().includes(q) ||
        (p.description && p.description.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q))
      );
    });
  }, [products, selectedCategory, searchQuery, categoryItems]);

  const handleCategoryClick = (catId: string) => {
    setSelectedCategory(catId);
    if (onSelectCategory) {
      onSelectCategory(catId);
    }
  };

  const handleProductItemClick = (id: string) => {
    if (onProductClick) {
      onProductClick(id);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 font-sans text-label min-h-[85vh]">
      {/* ── 1. Top Breadcrumb & Clean Apple Search ── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-5 border-b border-separator">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-surface-2 hover:bg-surface flex items-center justify-center text-label-2 hover:text-label transition-all cursor-pointer mr-1"
            title="กลับหน้าหลัก"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-xl sm:text-2xl font-semibold tracking-tight text-label">
              ร้านค้าและสินค้า
            </h1>
            <p className="text-xs text-label-2 mt-0.5">
              ค้นหาและเลือกซื้อสินค้าดิจิทัลทั้งหมด ({products.length} รายการ)
            </p>
          </div>
        </div>

        {/* Minimalist Apple Search Pill */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-label-3 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ค้นหาชื่อสินค้า หรือ ไอดี..."
            className="w-full pl-9 pr-8 py-2 rounded-full bg-surface border border-separator focus:border-accent text-xs text-label placeholder:text-label-3 focus:outline-none transition-all shadow-sm"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-label-3 hover:text-label"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* ── 2. Mobile / Tablet Category Horizontal Rail ── */}
      <div className="lg:hidden mb-6 overflow-x-auto scrollbar-none pb-1 flex items-center gap-2">
        <button
          onClick={() => handleCategoryClick("all")}
          className={`px-4 py-2 rounded-full text-xs font-medium transition-all shrink-0 cursor-pointer ${
            selectedCategory === "all"
              ? "bg-label text-bg shadow-sm"
              : "bg-surface-2 text-label-2 hover:bg-surface hover:text-label"
          }`}
        >
          ทั้งหมด ({products.length})
        </button>

        {categoryItems.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.id)}
              className={`px-4 py-2 rounded-full text-xs font-medium transition-all shrink-0 cursor-pointer ${
                isSelected
                  ? "bg-label text-bg shadow-sm"
                  : "bg-surface-2 text-label-2 hover:bg-surface hover:text-label"
              }`}
            >
              {cat.title || cat.name} ({cat.count})
            </button>
          );
        })}
      </div>

      {/* ── 3. Desktop Layout: Sidebar + Product Grid ── */}
      <div className="flex flex-col lg:flex-row items-start gap-8">
        {/* Left Sidebar */}
        <aside className="hidden lg:block w-64 shrink-0 sticky top-20">
          <div className="bg-surface border border-separator rounded-3xl p-4 shadow-xl">
            <h2 className="text-xs font-medium text-label-3 px-3 py-2 mb-1">
              หมวดหมู่ทั้งหมด
            </h2>

            <div className="space-y-1">
              <button
                onClick={() => handleCategoryClick("all")}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-medium transition-all cursor-pointer ${
                  selectedCategory === "all"
                    ? "bg-surface-2 text-label font-semibold"
                    : "text-label-2 hover:text-label hover:bg-surface-2/60"
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <LayoutGrid className="w-3.5 h-3.5 shrink-0 text-link" />
                  <span className="truncate">สินค้าทั้งหมด</span>
                </div>
                <span className="text-xs font-sans tabular-nums text-label-3">
                  {products.length}
                </span>
              </button>

              {categoryItems.map((cat) => {
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryClick(cat.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-medium transition-all cursor-pointer ${
                      isSelected
                        ? "bg-surface-2 text-label font-semibold"
                        : "text-label-2 hover:text-label hover:bg-surface-2/60"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {getCategoryIcon(cat.name, cat.id)}
                      <span className="truncate">{cat.title || cat.name}</span>
                    </div>
                    <span className="text-xs font-sans tabular-nums text-label-3">
                      {cat.count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Right Area: Clean Product Grid */}
        <main className="flex-1 w-full min-w-0">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3.5 sm:gap-5">
              {filteredProducts.map((product) => {
                const catInfo = categoryItems.find(
                  (c) =>
                    c.id === product.category ||
                    c.name === product.category ||
                    c.title === product.category
                );
                return (
                  <ProductCard
                    key={product.id}
                    product={product}
                    categoryName={
                      catInfo?.title ||
                      catInfo?.name ||
                      (typeof product.category === "string"
                        ? product.category
                        : undefined)
                    }
                    onClick={handleProductItemClick}
                  />
                );
              })}
            </div>
          ) : (
            <div className="bg-surface border border-separator rounded-3xl p-12 text-center my-4">
              <div className="w-12 h-12 rounded-full bg-surface-2 flex items-center justify-center mx-auto mb-3 text-label-3">
                <Package className="w-6 h-6" />
              </div>
              <h3 className="text-sm sm:text-base font-semibold text-label">
                ไม่พบสินค้าในรายการ
              </h3>
              <p className="text-xs text-label-2 mt-1 max-w-sm mx-auto">
                {searchQuery
                  ? `ไม่พบสินค้าที่ตรงกับคำค้นหา "${searchQuery}"`
                  : "ไม่มีสินค้าในหมวดหมู่นี้ในขณะนี้"}
              </p>
              <button
                onClick={() => {
                  setSelectedCategory("all");
                  setSearchQuery("");
                }}
                className="mt-4 px-5 py-2 rounded-full bg-accent hover:bg-accent-hover text-white text-xs font-medium transition-all shadow-sm cursor-pointer"
              >
                ดูสินค้าทั้งหมด
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CategoriesView;

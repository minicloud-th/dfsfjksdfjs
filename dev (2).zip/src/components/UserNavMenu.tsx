import React from "react";
import {
  User,
  ShoppingBag,
  CreditCard,
  Ticket,
  LogOut,
  ChevronRight,
  ShieldCheck,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { UserPlan } from "../types";
import { getAvatarUrl } from "../lib/avatar";

interface UserNavMenuProps {
  user: any;
  userPlan: UserPlan | null;
  isAdmin: boolean;
  activeView: string;
  isOpen: boolean;
  onToggle: () => void;
  onNavigate: (view: string) => void;
  onLogout: () => void;
  onPreload?: (view: string) => void;
  variant?: "drawer" | "floating";
  className?: string;
}

export const UserNavMenu: React.FC<UserNavMenuProps> = ({
  user,
  userPlan,
  isAdmin,
  activeView,
  isOpen,
  onToggle,
  onNavigate,
  onLogout,
  variant = "drawer",
  className = "",
}) => {
  const username =
    userPlan?.username || user?.name || user?.email?.split("@")[0] || "ผู้ใช้งาน";
  const userEmail = user?.email || "เข้าสู่ระบบแล้ว";
  const avatarUrl =
    userPlan?.avatarUrl ||
    getAvatarUrl(
      userPlan?.username || user?.name || user?.email?.split("@")[0] || user?.id || "guest"
    );
  const initialChar = (username.charAt(0) || "U").toUpperCase();
  const balance = userPlan?.balance
    ? Math.floor(userPlan.balance)
    : user?.balance
    ? Math.floor(user.balance)
    : 0;

  const menuItems = [
    {
      id: "profile",
      label: "บัญชีของฉัน",
      icon: User,
    },
    {
      id: "history",
      label: "ประวัติการซื้อ",
      icon: ShoppingBag,
    },
    {
      id: "wallet_history",
      label: "ประวัติเติมเงิน",
      icon: CreditCard,
    },
  ];

  return (
    <div className={`w-full flex flex-col ${className}`}>
      {/* Top Header Card */}
      <div
        onClick={variant === "drawer" ? onToggle : undefined}
        className="flex flex-col gap-3 rounded-2xl select-none transition-colors p-3.5 border border-separator bg-surface shadow-sm"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full p-[2px] border border-separator bg-surface-2 flex items-center justify-center select-none shrink-0 overflow-hidden">
            {userPlan?.avatarUrl ? (
              <img
                src={userPlan.avatarUrl}
                alt={username}
                className="w-full h-full rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full rounded-full bg-surface-2 text-label font-semibold text-xs flex items-center justify-center select-none">
                {initialChar}
              </div>
            )}
          </div>
          <div className="flex flex-col flex-1 min-w-0">
            <span className="text-xs font-semibold text-label truncate">{username}</span>
            <span className="text-xs text-label-2 truncate">{userEmail}</span>
          </div>
        </div>

        {/* Minimal Balance */}
        <div className="flex items-center justify-between pt-2.5 border-t border-separator text-xs">
          <span className="text-label-2">ยอดเงินคงเหลือ</span>
          <span className="font-sans font-semibold text-success bg-success/15 border border-success/20 px-2.5 py-0.5 rounded-full">
            ฿{balance.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Menu List */}
      <div className="flex flex-col gap-1.5 mt-2">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex items-center justify-between w-full px-4 py-2.5 rounded-full text-xs sm:text-sm font-medium transition-all duration-150 cursor-pointer ${
                isActive
                  ? "bg-accent text-white shadow-sm"
                  : "text-label-2 hover:text-label hover:bg-surface-2"
              }`}
            >
              <div className="flex items-center gap-3">
                <IconComponent
                  className={`w-4 h-4 ${
                    isActive ? "text-white" : "text-label-2"
                  }`}
                />
                <span>{item.label}</span>
              </div>
              <ChevronRight
                className={`w-3.5 h-3.5 opacity-50 ${
                  isActive ? "text-white" : "text-label-3"
                }`}
              />
            </button>
          );
        })}

        {isAdmin && (
          <button
            onClick={() => onNavigate("admin")}
            className="flex items-center justify-between w-full px-4 py-2.5 rounded-full text-xs sm:text-sm font-medium transition-all duration-150 cursor-pointer mt-1 text-warning bg-warning/15 border border-warning/20 hover:bg-warning/25"
          >
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-4 h-4" />
              <span>จัดการระบบแอดมิน</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 opacity-60" />
          </button>
        )}

        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center gap-2 py-2.5 mt-2 rounded-full text-xs font-medium text-danger hover:text-danger bg-danger/15 hover:bg-danger/25 border border-danger/20 transition-all cursor-pointer shadow-sm"
        >
          <LogOut className="w-4 h-4" />
          <span>ออกจากระบบ</span>
        </button>
      </div>
    </div>
  );
};

export default UserNavMenu;

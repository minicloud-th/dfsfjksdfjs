import React, { useEffect, useRef } from "react";
import {
  X,
  Home,
  ShoppingCart,
  Wallet,
  History,
  Phone,
  ShieldCheck,
  User,
  LogOut,
  ChevronRight,
  ShoppingBag,
  Ticket,
  KeyRound,
  CreditCard,
  Sun,
  Moon,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { DevLogo } from "./DevLogo";
import { getAvatarUrl } from "../lib/avatar";
import { useTheme } from "../lib/theme";

export interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeView: string;
  setActiveView: (view: string) => void;
  user: any;
  userPlan: any;
  isAdmin: boolean;
  onLogout: () => void;
  onOpenContact: () => void;
  isUserMenuOpen?: boolean;
  setIsUserMenuOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  settingsImport?: () => void;
  historyImport?: () => void;
  onOpenSearch?: () => void;
}

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  isOpen,
  onClose,
  activeView,
  setActiveView,
  user,
  userPlan,
  isAdmin,
  onLogout,
  onOpenContact,
  historyImport,
}) => {
  const { theme, toggleTheme } = useTheme();
  const drawerRef = useRef<HTMLDivElement>(null);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  // Lock background scroll when open
  useEffect(() => {
    if (isOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [isOpen]);

  const username =
    userPlan?.username || user?.name || user?.email?.split("@")[0] || "ผู้ใช้งาน";
  const userEmail = user?.email || "เข้าสู่ระบบแล้ว";
  const avatarUrl =
    userPlan?.avatarUrl ||
    getAvatarUrl(
      userPlan?.username || user?.name || user?.email?.split("@")[0] || user?.id || "guest"
    );
  const initialChar = (username.charAt(0) || "U").toUpperCase();
  const balance = userPlan?.balance
    ? Math.floor(userPlan.balance)
    : user?.balance
    ? Math.floor(user.balance)
    : 0;

  const isShopActive =
    activeView === "categories" ||
    activeView === "category_products" ||
    activeView === "product_detail";

  const isHistoryActive =
    activeView === "log_categories" ||
    activeView === "vip_logs" ||
    activeView === "free_logs" ||
    activeView === "logs" ||
    activeView === "history" ||
    activeView === "order_history" ||
    activeView === "random_history";

  // Account specific menu items (matching the requested profile sub-menu design)
  const accountMenuItems = [
    {
      id: "profile",
      label: "บัญชีของฉัน",
      icon: User,
      isActive: activeView === "profile",
      onClick: () => {
        setActiveView("profile");
        window.scrollTo({ top: 0, behavior: "smooth" });
        onClose();
      },
    },
    {
      id: "history",
      label: "ประวัติการซื้อ",
      icon: ShoppingBag,
      isActive: isHistoryActive,
      onClick: () => {
        historyImport?.();
        setActiveView("history");
        window.scrollTo({ top: 0, behavior: "smooth" });
        onClose();
      },
    },
    {
      id: "wallet_history",
      label: "ประวัติเติมเงิน",
      icon: CreditCard,
      isActive: activeView === "wallet_history",
      onClick: () => {
        setActiveView("wallet_history");
        window.scrollTo({ top: 0, behavior: "smooth" });
        onClose();
      },
    },
  ];

  // General Store Navigation Links
  const storeNavItems = [
    {
      id: "home",
      label: "หน้าแรก",
      icon: Home,
      isActive: activeView === "home",
      onClick: () => {
        setActiveView("home");
        window.scrollTo({ top: 0, behavior: "smooth" });
        onClose();
      },
    },
    {
      id: "categories",
      label: "ร้านค้า",
      icon: ShoppingCart,
      isActive: isShopActive,
      onClick: () => {
        setActiveView("categories");
        window.scrollTo({ top: 0, behavior: "smooth" });
        onClose();
      },
    },
    {
      id: "wallet",
      label: "เติมเงิน",
      icon: Wallet,
      isActive: activeView === "wallet",
      onClick: () => {
        setActiveView(user ? "wallet" : "login");
        window.scrollTo({ top: 0, behavior: "smooth" });
        onClose();
      },
    },
    {
      id: "contact",
      label: "ติดต่อเรา",
      icon: Phone,
      isActive: false,
      onClick: () => {
        onOpenContact();
        onClose();
      },
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop Blur Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-md z-[68] cursor-pointer"
            aria-hidden="true"
          />

          {/* Full-Height Edge-to-Edge Side Drawer in Dark Theme */}
          <motion.div
            ref={drawerRef}
            initial={{ x: "100%", opacity: 0.5 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: "100%", opacity: 0 }}
            transition={{
              type: "spring",
              damping: 32,
              stiffness: 350,
              mass: 0.75,
            }}
            id="mobile-drawer"
            role="dialog"
            aria-modal="true"
            aria-label="เมนูหลัก"
            className="fixed inset-y-0 right-0 h-full w-[88vw] max-w-[340px] z-[70] bg-surface/95 backdrop-blur-2xl border-l border-separator shadow-2xl flex flex-col justify-between select-none overflow-hidden text-label"
          >
            {/* Top Bar inside Drawer: Logo & Close Button */}
            <div className="p-4 px-5 flex items-center justify-between shrink-0 border-b border-separator bg-transparent">
              <div
                onClick={() => {
                  setActiveView("home");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                  onClose();
                }}
                className="flex items-center cursor-pointer hover:opacity-90 transition-opacity"
              >
                <DevLogo className="h-10 sm:h-12 w-auto" />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => toggleTheme(e)}
                  className="min-w-[38px] min-h-[38px] w-9 h-9 rounded-full flex items-center justify-center text-label-2 hover:text-label bg-surface-2 border border-separator transition-colors cursor-pointer focus-visible:outline-none"
                  aria-label={theme === "dark" ? "เปลี่ยนเป็นโหมดสว่าง" : "เปลี่ยนเป็นโหมดมืด"}
                  title={theme === "dark" ? "เปลี่ยนเป็นโหมดสว่าง" : "เปลี่ยนเป็นโหมดมืด"}
                >
                  <AnimatePresence mode="wait" initial={false}>
                    <motion.div
                      key={theme}
                      initial={{ y: -10, opacity: 0, rotate: -60, scale: 0.5 }}
                      animate={{ y: 0, opacity: 1, rotate: 0, scale: 1 }}
                      exit={{ y: 10, opacity: 0, rotate: 60, scale: 0.5 }}
                      transition={{
                        type: "spring",
                        stiffness: 400,
                        damping: 24,
                      }}
                      className="flex items-center justify-center"
                    >
                      {theme === "dark" ? (
                        <Sun className="w-4 h-4 text-warning" />
                      ) : (
                        <Moon className="w-4 h-4 text-link" />
                      )}
                    </motion.div>
                  </AnimatePresence>
                </button>

                <button
                  onClick={onClose}
                  className="min-w-[38px] min-h-[38px] w-9 h-9 rounded-full flex items-center justify-center text-label-2 hover:text-label bg-surface-2 border border-separator transition-colors cursor-pointer focus-visible:outline-none"
                  aria-label="ปิดเมนู"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto overscroll-contain px-4 py-4 space-y-4 custom-scrollbar">
              {/* General Store Menu (เมนูหลัก) - Always on top */}
              <div className="space-y-1.5">
                <div className="px-2 pb-1 text-xs font-medium text-label-3">
                  เมนูหลัก
                </div>
                {storeNavItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={item.onClick}
                      className={`flex items-center justify-between w-full px-4 py-2.5 rounded-full text-sm font-medium transition-all duration-150 cursor-pointer ${
                        item.isActive
                          ? "bg-accent text-white shadow-sm"
                          : "text-label hover:text-label hover:bg-surface-2"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon
                          className={`w-4 h-4 ${
                            item.isActive ? "text-white" : "text-label-2"
                          }`}
                        />
                        <span>{item.label}</span>
                      </div>

                      <ChevronRight
                        className={`w-4 h-4 opacity-50 ${
                          item.isActive ? "text-white" : "text-label-3"
                        }`}
                      />
                    </button>
                  );
                })}

                {/* Admin Button */}
                {isAdmin && (
                  <button
                    onClick={() => {
                      setActiveView("admin");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                      onClose();
                    }}
                    className={`flex items-center justify-between w-full px-4 py-2.5 rounded-full text-sm font-medium transition-all duration-150 cursor-pointer mt-2 border ${
                      activeView === "admin"
                        ? "bg-warning text-black border-warning shadow-sm"
                        : "text-warning bg-warning/15 border-warning/30 hover:bg-warning/25"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <ShieldCheck className="w-4 h-4" />
                      <span>จัดการระบบแอดมิน</span>
                    </div>
                    <ChevronRight className="w-4 h-4 opacity-60" />
                  </button>
                )}
              </div>

              {/* User Section & Compact Profile Card (เมนูผู้ใช้) */}
              {user && (
                <div className="space-y-2.5 pt-3 border-t border-separator">
                  <div className="px-2 pb-0.5 text-xs font-medium text-label-3">
                    เมนูผู้ใช้
                  </div>

                  {/* Compact User Card */}
                  <div className="rounded-2xl bg-surface-2 border border-separator p-3.5 space-y-2.5 shadow-sm">
                    <div
                      onClick={() => {
                        setActiveView("profile");
                        window.scrollTo({ top: 0, behavior: "smooth" });
                        onClose();
                      }}
                      className="flex items-center gap-3 cursor-pointer group"
                    >
                      {/* Default Avatar Badge */}
                      <div className="relative shrink-0">
                        <div className="w-9 h-9 rounded-full border border-separator bg-surface flex items-center justify-center overflow-hidden">
                          {userPlan?.avatarUrl ? (
                            <img
                              src={userPlan.avatarUrl}
                              alt={username}
                              className="w-full h-full rounded-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-full h-full rounded-full bg-surface text-label font-medium text-xs flex items-center justify-center select-none">
                              {initialChar}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Name & Email */}
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="text-sm font-medium text-label truncate group-hover:text-link transition-colors">
                          {username}
                        </span>
                        <span className="text-xs text-label-2 truncate leading-tight">
                          {userEmail}
                        </span>
                      </div>

                      <ChevronRight className="w-4 h-4 text-label-3 group-hover:text-label transition-colors shrink-0" />
                    </div>

                    {/* Balance Bar inside Profile Card */}
                    <div className="flex items-center justify-between pt-2 border-t border-separator text-xs">
                      <span className="text-label-2 font-normal">ยอดเงินคงเหลือ</span>
                      <span className="font-sans tabular-nums font-semibold text-success bg-success/15 border border-success/25 px-2.5 py-0.5 rounded-full text-xs">
                        ฿{balance.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Profile Sub-Menu Items */}
                  <div className="space-y-1 pt-1">
                    {accountMenuItems.map((item) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.id}
                          onClick={item.onClick}
                          className={`flex items-center justify-between w-full px-4 py-2.5 rounded-full text-sm font-medium transition-all duration-150 cursor-pointer ${
                            item.isActive
                              ? "bg-accent text-white shadow-sm"
                              : "text-label hover:text-label hover:bg-surface-2"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Icon
                              className={`w-4 h-4 ${
                                item.isActive ? "text-white" : "text-label-2"
                              }`}
                            />
                            <span>{item.label}</span>
                          </div>
                          <ChevronRight
                            className={`w-4 h-4 opacity-50 ${
                              item.isActive ? "text-white" : "text-label-3"
                            }`}
                          />
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom: User Logout or Guest Login/Register */}
            <div className="p-4 shrink-0 border-t border-separator bg-surface">
              {user ? (
                <button
                  onClick={() => {
                    onLogout();
                    onClose();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-full text-xs font-medium text-danger hover:bg-danger/15 bg-danger/10 border border-danger/20 transition-all cursor-pointer shadow-sm"
                >
                  <LogOut className="w-4 h-4" />
                  <span>ออกจากระบบ</span>
                </button>
              ) : (
                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => {
                      setActiveView("login");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                      onClose();
                    }}
                    className="flex-1 py-2.5 rounded-full text-xs font-medium text-label hover:bg-surface-2 bg-surface-2 border border-separator transition-colors cursor-pointer text-center"
                  >
                    เข้าสู่ระบบ
                  </button>
                  <button
                    onClick={() => {
                      setActiveView("signup");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                      onClose();
                    }}
                    className="flex-1 py-2.5 rounded-full text-xs font-medium bg-accent text-white hover:bg-accent-hover transition-colors cursor-pointer text-center shadow-sm"
                  >
                    สมัครสมาชิก
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default MobileDrawer;

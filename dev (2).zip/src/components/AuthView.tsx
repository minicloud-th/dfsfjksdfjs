import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  Eye,
  EyeOff,
  ArrowLeft,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Lock,
  User,
  Mail,
  Zap,
  Headphones,
  Check,
  Crown,
  KeyRound,
  ArrowRight,
  Shield,
  Layers,
} from "lucide-react";
import axios from "axios";
import Swal from "sweetalert2";
import { toast } from "../lib/toastStore";
import {
  signInWithGoogle,
  signInWithGithub,
  signInEmail,
  signUpEmail,
  resetPassword,
} from "../lib/firebase";
import { demoStore, setDemoSession } from "../lib/mockApi";
import { DevLogo } from "./DevLogo";

interface AuthViewProps {
  initialMode: "login" | "signup";
  setActiveView: (view: any) => void;
  siteSettings?: any;
}

export const AuthView: React.FC<AuthViewProps> = React.memo(
  ({ initialMode, setActiveView, siteSettings }) => {
    const siteName = siteSettings?.site_name || "Astrax Store";
    const [authMode, setAuthMode] = useState<"login" | "signup" | "forgot">(
      initialMode
    );

    const [authEmail, setAuthEmail] = useState("");
    const [authUsername, setAuthUsername] = useState("");
    const [authPassword, setAuthPassword] = useState("");
    const [authConfirmPassword, setAuthConfirmPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [rememberMe, setRememberMe] = useState(true);
    const [agreeTerms, setAgreeTerms] = useState(true);
    const [authLoading, setAuthLoading] = useState(false);

    const usernameInputRef = useRef<HTMLInputElement>(null);
    const emailInputRef = useRef<HTMLInputElement>(null);
    const passwordInputRef = useRef<HTMLInputElement>(null);

    // Load remembered user if available
    useEffect(() => {
      try {
        const saved = localStorage.getItem("astrax_remember_user");
        if (saved) {
          setAuthEmail(saved);
        }
      } catch {}
    }, []);

    useEffect(() => {
      setAuthMode(initialMode);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, [initialMode]);

    useEffect(() => {
      const timer = setTimeout(() => {
        if (authMode === "signup") {
          usernameInputRef.current?.focus();
        } else if (authMode === "login") {
          emailInputRef.current?.focus();
        } else {
          emailInputRef.current?.focus();
        }
      }, 150);
      return () => clearTimeout(timer);
    }, [authMode]);

    // Real-time email validation
    const isEmailValid = useMemo(() => {
      if (!authEmail) return null;
      if (authMode === "login" && !authEmail.includes("@")) return null; // Username entered
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(authEmail.trim());
    }, [authEmail, authMode]);

    // Real-time password strength calculation
    const passwordStrength = useMemo(() => {
      if (!authPassword)
        return {
          score: 0,
          text: "ยังไม่ได้ระบุ",
          color: "bg-zinc-700",
          textColor: "text-zinc-500",
        };
      let score = 0;
      if (authPassword.length >= 6) score++;
      if (authPassword.length >= 8) score++;
      if (/[0-9]/.test(authPassword)) score++;
      if (/[a-zA-Z]/.test(authPassword) && /[^a-zA-Z0-9]/.test(authPassword))
        score++;

      if (score <= 1)
        return {
          score: 1,
          text: "อ่อน (ควรมี 8 ตัวขึ้นไป)",
          color: "bg-red-500",
          textColor: "text-red-400",
        };
      if (score === 2)
        return {
          score: 2,
          text: "ปานกลาง",
          color: "bg-amber-500",
          textColor: "text-amber-400",
        };
      if (score >= 3)
        return {
          score: 3,
          text: "ปลอดภัยมาก",
          color: "bg-emerald-500",
          textColor: "text-emerald-400",
        };
      return {
        score: 0,
        text: "อ่อน",
        color: "bg-red-500",
        textColor: "text-red-400",
      };
    }, [authPassword]);

    // Passwords match indicator for signup
    const passwordsMatch = useMemo(() => {
      if (!authConfirmPassword) return null;
      return authPassword === authConfirmPassword;
    }, [authPassword, authConfirmPassword]);

    // Helper: Sync Firebase authenticated user with server and database profile
    const syncUserProfile = async (firebaseUser: any) => {
      const email = (firebaseUser.email || "").toLowerCase().trim();
      const displayName =
        firebaseUser.displayName || email.split("@")[0] || "User";
      const uid = firebaseUser.uid;

      // 1. Call secure server endpoint with verified Firebase ID token
      try {
        const idToken = await firebaseUser.getIdToken();
        const response = await axios.post(
          "/api/profile/sync",
          {
            username: displayName,
            fullName: displayName,
            avatarUrl:
              firebaseUser.photoURL ||
              `https://api.dicebear.com/7.x/bottts/svg?seed=${displayName}`,
          },
          {
            headers: {
              Authorization: `Bearer ${idToken}`,
            },
          }
        );

        if (response.data?.profile) {
          const profile = response.data.profile;
          setDemoSession(profile);
          return profile;
        }
      } catch (err) {
        console.warn("[AuthView] Server profile sync fallback:", err);
      }

      // 2. Local memory fallback: role is ALWAYS "user" - Never assign admin based on email
      const users = demoStore.getUsers();
      let profile = users.find(
        (u) => u.uid === uid || u.email.toLowerCase() === email
      );

      if (!profile) {
        profile = {
          id: uid,
          uid: uid,
          email: email,
          username: displayName,
          fullName: displayName,
          role: "user",
          rank: "user",
          balance: 0,
          isPremium: false,
          status: "active",
          registeredAt: new Date().toISOString(),
          avatarUrl:
            firebaseUser.photoURL ||
            `https://api.dicebear.com/7.x/bottts/svg?seed=${displayName}`,
        };
        users.push(profile);
        demoStore.saveUsers(users);
      }

      setDemoSession(profile);
      return profile;
    };

    // Quick demo autofill handler for fast testing
    const handleQuickDemoFill = (type: "admin" | "user") => {
      setAuthMode("login");
      if (type === "admin") {
        setAuthEmail("admin");
        setAuthPassword("admin123");
        toast.info(
          "กรอกบัญชีผู้ดูแลระบบ (Admin) สำเร็จ กดเข้าสู่ระบบได้ทันที",
          "ทดสอบระบบด่วน"
        );
      } else {
        setAuthEmail("demo_user");
        setAuthPassword("user123");
        toast.info(
          "กรอกบัญชีสมาชิกทั่วไป (Demo User) สำเร็จ กดเข้าสู่ระบบได้ทันที",
          "ทดสอบระบบด่วน"
        );
      }
    };

    // ── OAuth Handlers (Real Firebase OAuth) ──
    const handleGoogleLogin = async () => {
      setAuthLoading(true);
      try {
        const fbUser = await signInWithGoogle();
        const profile = await syncUserProfile(fbUser);
        toast.success(
          `ยินดีต้อนรับ ${profile.username || fbUser.email}`,
          "เข้าสู่ระบบด้วย Google สำเร็จ"
        );
        setActiveView(profile.role === "admin" ? "admin" : "home");
      } catch (err: any) {
        console.error("Google Auth Error:", err);
        const msg = err.message || "ไม่สามารถเชื่อมต่อ Google ได้";
        if (err.code === "auth/popup-closed-by-user") {
          toast.info(
            "คุณได้ปิดหน้าต่างการเข้าสู่ระบบ Google",
            "ยกเลิกการเข้าสู่ระบบ"
          );
          return;
        } else if (err.code === "auth/unauthorized-domain") {
          const currentHost = window.location.hostname;
          Swal.fire({
            icon: "warning",
            title: "โดเมนยังไม่ได้รับอนุญาตใน Firebase",
            html: `
              <div class="text-left text-xs space-y-2.5 text-zinc-300">
                <p>Firebase ป้องกันการล็อกอินจากโดเมนภายนอกที่ยังไม่ได้ลงทะเบียนไว้</p>
                <div class="p-2.5 rounded bg-zinc-900 border border-zinc-700 font-mono text-emerald-400 break-all select-all flex items-center justify-between">
                  <span>${currentHost}</span>
                </div>
                <div class="space-y-1 text-zinc-400">
                  <p class="font-semibold text-white">วิธีแก้ไขใน 1 นาที:</p>
                  <p>1. ไปที่ <a href="https://console.firebase.google.com/project/zenone-eaf64/authentication/settings" target="_blank" rel="noopener noreferrer" class="text-blue-400 underline font-semibold">Firebase Console ➔ Authentication ➔ Settings</a></p>
                  <p>2. ไปที่หัวข้อ <b>Authorized domains</b> ➔ กด <b>Add domain</b></p>
                  <p>3. วางโดเมน <code class="text-emerald-400">${currentHost}</code> แล้วกดบันทึก</p>
                </div>
                <p class="text-zinc-500 pt-1 text-[11px]">* หรือสามารถเข้าสู่ระบบด้วย ชื่อผู้ใช้/รหัสผ่าน ด้านล่างได้ทันที</p>
              </div>
            `,
            background: "#141414",
            color: "#fff",
            confirmButtonColor: "#2563EB",
          });
          return;
        }
        toast.error(msg, "ไม่สามารถเชื่อมต่อ Google ได้");
      } finally {
        setAuthLoading(false);
      }
    };

    const handleGithubLogin = async () => {
      setAuthLoading(true);
      try {
        const fbUser = await signInWithGithub();
        const profile = await syncUserProfile(fbUser);
        toast.success(
          `ยินดีต้อนรับ ${profile.username || fbUser.email}`,
          "เข้าสู่ระบบด้วย GitHub สำเร็จ"
        );
        setActiveView(profile.role === "admin" ? "admin" : "home");
      } catch (err: any) {
        console.error("GitHub Auth Error:", err);
        const msg = err.message || "ไม่สามารถเชื่อมต่อ GitHub ได้";
        if (err.code === "auth/popup-closed-by-user") {
          toast.info(
            "คุณได้ปิดหน้าต่างการเข้าสู่ระบบ GitHub",
            "ยกเลิกการเข้าสู่ระบบ"
          );
          return;
        } else if (err.code === "auth/unauthorized-domain") {
          const currentHost = window.location.hostname;
          Swal.fire({
            icon: "warning",
            title: "โดเมนยังไม่ได้รับอนุญาตใน Firebase",
            html: `
              <div class="text-left text-xs space-y-2.5 text-zinc-300">
                <p>Firebase ป้องกันการล็อกอินจากโดเมนภายนอกที่ยังไม่ได้ลงทะเบียนไว้</p>
                <div class="p-2.5 rounded bg-zinc-900 border border-zinc-700 font-mono text-emerald-400 break-all select-all flex items-center justify-between">
                  <span>${currentHost}</span>
                </div>
                <div class="space-y-1 text-zinc-400">
                  <p class="font-semibold text-white">วิธีแก้ไขใน 1 นาที:</p>
                  <p>1. ไปที่ <a href="https://console.firebase.google.com/project/zenone-eaf64/authentication/settings" target="_blank" rel="noopener noreferrer" class="text-blue-400 underline font-semibold">Firebase Console ➔ Authentication ➔ Settings</a></p>
                  <p>2. ไปที่หัวข้อ <b>Authorized domains</b> ➔ กด <b>Add domain</b></p>
                  <p>3. วางโดเมน <code class="text-emerald-400">${currentHost}</code> แล้วกดบันทึก</p>
                </div>
                <p class="text-zinc-500 pt-1 text-[11px]">* หรือสามารถเข้าสู่ระบบด้วย ชื่อผู้ใช้/รหัสผ่าน ด้านล่างได้ทันที</p>
              </div>
            `,
            background: "#141414",
            color: "#fff",
            confirmButtonColor: "#2563EB",
          });
          return;
        }
        toast.error(msg, "ไม่สามารถเชื่อมต่อ GitHub ได้");
      } finally {
        setAuthLoading(false);
      }
    };

    // ── Email/Password/Username Authentication ──
    const handleAuth = async (e: React.FormEvent) => {
      e.preventDefault();

      if (authMode === "signup") {
        if (!authUsername.trim()) {
          toast.warning(
            "กรุณาระบุชื่อผู้ใช้สำหรับสมัครสมาชิก",
            "ข้อมูลไม่ครบถ้วน"
          );
          return;
        }
        if (!authEmail.trim()) {
          toast.warning("กรุณากรอกอีเมลสำหรับใช้งาน", "ข้อมูลไม่ครบถ้วน");
          return;
        }
        if (isEmailValid === false) {
          toast.warning(
            "รูปแบบอีเมลไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง",
            "รูปแบบอีเมลไม่ถูกต้อง"
          );
          return;
        }
        if (!authPassword) {
          toast.warning("กรุณากรอกรหัสผ่าน", "ข้อมูลไม่ครบถ้วน");
          return;
        }
        if (authPassword.length < 6) {
          toast.warning(
            "รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร",
            "รหัสผ่านสั้นเกินไป"
          );
          return;
        }
        if (authPassword !== authConfirmPassword) {
          toast.error(
            "รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน",
            "รหัสผ่านไม่ตรงกัน"
          );
          return;
        }
        if (!agreeTerms) {
          toast.warning(
            "กรุณายอมรับเงื่อนไขการให้บริการก่อนสมัครสมาชิก",
            "ข้อตกลงการใช้งาน"
          );
          return;
        }
      } else if (authMode === "login") {
        if (!authEmail.trim()) {
          toast.warning(
            "กรุณากรอกชื่อผู้ใช้ หรือ อีเมล",
            "ข้อมูลไม่ครบถ้วน"
          );
          return;
        }
        if (!authPassword) {
          toast.warning("กรุณากรอกรหัสผ่าน", "ข้อมูลไม่ครบถ้วน");
          return;
        }

        // Save or clear remember user
        try {
          if (rememberMe) {
            localStorage.setItem("astrax_remember_user", authEmail.trim());
          } else {
            localStorage.removeItem("astrax_remember_user");
          }
        } catch {}
      } else {
        // Forgot password
        if (!authEmail.trim()) {
          toast.warning(
            "กรุณากรอกอีเมลสำหรับรีเซ็ตรหัสผ่าน",
            "ข้อมูลไม่ครบถ้วน"
          );
          return;
        }
        if (isEmailValid === false) {
          toast.warning(
            "รูปแบบอีเมลไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง",
            "รูปแบบอีเมลไม่ถูกต้อง"
          );
          return;
        }
      }

      setAuthLoading(true);
      try {
        if (authMode === "signup") {
          const user = await signUpEmail(
            authEmail.trim(),
            authPassword,
            authUsername.trim() || undefined
          );
          await syncUserProfile(user);

          toast.success("บัญชีของคุณพร้อมใช้งานแล้ว", "สมัครสมาชิกสำเร็จ");
          setActiveView("home");
        } else if (authMode === "forgot") {
          await resetPassword(authEmail.trim());
          Swal.fire({
            icon: "success",
            title: "ส่งลิงก์รีเซ็ตรหัสผ่านแล้ว",
            text: `กรุณาตรวจสอบอีเมล ${authEmail} เพื่อดำเนินการตั้งรหัสผ่านใหม่`,
            background: "#141414",
            color: "#fff",
            confirmButtonColor: "#2563EB",
          });
          setAuthMode("login");
        } else {
          // Mode: Login (supports Username or Email)
          let loginEmail = authEmail.trim();
          if (!loginEmail.includes("@")) {
            // Resolve username -> email via server backend
            try {
              const res = await axios.get(
                `/api/auth/resolve-username/${encodeURIComponent(loginEmail)}`
              );
              if (res.data?.email) {
                loginEmail = res.data.email;
              }
            } catch {
              // Optional local store fallback in dev
              const allUsers = demoStore.getUsers();
              const matched = allUsers.find(
                (u) => u.username.toLowerCase() === loginEmail.toLowerCase()
              );
              if (matched && matched.email) {
                loginEmail = matched.email;
              }
            }
          }

          let user;
          try {
            user = await signInEmail(loginEmail, authPassword);
          } catch (firebaseErr: any) {
            // Check local / demo accounts as fallback (DEV only)
            if (import.meta.env.DEV) {
              const allUsers = demoStore.getUsers();
              const localUser = allUsers.find(
                (u) =>
                  u.username.toLowerCase() === authEmail.trim().toLowerCase() ||
                  u.email.toLowerCase() === authEmail.trim().toLowerCase()
              );
              if (localUser) {
                setDemoSession(localUser);
                toast.success("ยินดีต้อนรับกลับเข้าสู่ระบบ", "เข้าสู่ระบบสำเร็จ");
                setActiveView(localUser.role === "admin" ? "admin" : "home");
                return;
              }
            }
            throw firebaseErr;
          }

          const profile = await syncUserProfile(user);
          toast.success("ยินดีต้อนรับกลับเข้าสู่ระบบ", "เข้าสู่ระบบสำเร็จ");
          setActiveView(profile.role === "admin" ? "admin" : "home");
        }
      } catch (err: any) {
        console.error("Auth Error:", err);
        let msg = err?.message || "เกิดข้อผิดพลาดในการทำรายการ";
        if (err.code === "auth/email-already-in-use") {
          msg = "อีเมลนี้ถูกใช้งานในระบบแล้ว กรุณาเข้าสู่ระบบ";
        } else if (
          err.code === "auth/invalid-credential" ||
          err.code === "auth/wrong-password" ||
          err.code === "auth/user-not-found"
        ) {
          msg = "ชื่อผู้ใช้ อีเมล หรือรหัสผ่านไม่ถูกต้อง";
        } else if (err.code === "auth/weak-password") {
          msg = "รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร";
        } else if (err.code === "auth/invalid-email") {
          msg = "รูปแบบอีเมลไม่ถูกต้อง";
        }

        toast.error(msg, "ไม่สามารถดำเนินการได้");
      } finally {
        setAuthLoading(false);
      }
    };

    return (
      <div className="relative min-h-[calc(100vh-80px)] w-full flex items-center justify-center px-4 py-8 sm:py-12 lg:py-16 overflow-hidden bg-bg text-label">
        {/* Main Split-Screen Showcase Container */}
        <div className="relative z-10 w-full max-w-5xl mx-auto">
          {/* Top Mobile Bar - Back & Brand (visible on small screens) */}
          <div className="flex lg:hidden items-center justify-between mb-5 px-1">
            <button
              type="button"
              onClick={() => {
                setActiveView("home");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="inline-flex items-center gap-1.5 text-xs text-label-2 hover:text-label transition-colors cursor-pointer py-1.5 px-3 rounded-full bg-surface-2 border border-separator"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>กลับสู่ร้านค้า</span>
            </button>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs text-success bg-success/15 border border-success/25 px-2.5 py-0.5 rounded-full font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
                พร้อมให้บริการ 24 ชม.
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            {/* ──────────────────────────────────────────────────────────── */}
            {/* LEFT COLUMN: BRAND HERO & HIG SHOWCASE (Desktop)           */}
            {/* ──────────────────────────────────────────────────────────── */}
            <div className="hidden lg:flex lg:col-span-6 flex-col justify-between p-8 xl:p-10 rounded-3xl bg-surface border border-separator shadow-2xl relative overflow-hidden">
              {/* Showcase Header */}
              <div>
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <DevLogo className="h-9 w-auto" />
                  </div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-separator text-label-2 text-xs font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-success" />
                    <span>ระบบจัดส่งอัตโนมัติ</span>
                  </div>
                </div>

                {/* Hero Title & Pitch */}
                <div className="space-y-3 mb-8">
                  <h1 className="text-3xl xl:text-4xl font-semibold text-label tracking-tight leading-tight">
                    ยินดีต้อนรับสู่ {siteName}
                  </h1>
                  <p className="text-sm text-label-2 leading-relaxed max-w-lg font-normal">
                    ศูนย์รวมไอดีเกม บัญชีสตรีมมิ่ง และโค้ดเติมเงิน เข้าสู่ระบบเพื่อสั่งซื้อ ตรวจสอบประวัติการสั่งซื้อ และจัดการบัญชีของคุณ
                  </p>
                </div>

                {/* Feature Highlight Cards (Grid 2x2) */}
                <div className="grid grid-cols-2 gap-3.5 mb-8">
                  <div className="p-4 rounded-2xl bg-surface-2 border border-separator">
                    <h3 className="text-xs font-semibold text-label mb-1">
                      จัดส่งอัตโนมัติ
                    </h3>
                    <p className="text-xs text-label-2 leading-relaxed">
                      รับโค้ดและไอดีเข้าประวัติทันทีหลังชำระเงินสำเร็จ
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-surface-2 border border-separator">
                    <h3 className="text-xs font-semibold text-label mb-1">
                      รับประกันสินค้า
                    </h3>
                    <p className="text-xs text-label-2 leading-relaxed">
                      มีระบบตรวจสอบและรับประกันตลอดอายุการใช้งาน
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-surface-2 border border-separator">
                    <h3 className="text-xs font-semibold text-label mb-1">
                      ระดับสมาชิก VIP
                    </h3>
                    <p className="text-xs text-label-2 leading-relaxed">
                      สะสมยอดเพื่อรับส่วนลดและสิทธิพิเศษเพิ่มเติม
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-surface-2 border border-separator">
                    <h3 className="text-xs font-semibold text-label mb-1">
                      บริการช่วยเหลือ
                    </h3>
                    <p className="text-xs text-label-2 leading-relaxed">
                      ติดต่อสอบถามและรับการช่วยเหลือผ่านช่องทางบริการลูกค้า
                    </p>
                  </div>
                </div>
              </div>

              {/* Showcase Footer */}
              <div className="pt-6 border-t border-separator flex items-center justify-between">
                <span className="text-xs text-label-3">Astrax Store Account Service</span>
                <div className="text-xs font-sans tabular-nums text-label-2 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-success" />
                  <span>SSL 256-Bit</span>
                </div>
              </div>
            </div>

            {/* ──────────────────────────────────────────────────────────── */}
            {/* RIGHT COLUMN: AUTHENTICATION FORM CARD                      */}
            {/* ──────────────────────────────────────────────────────────── */}
            <div className="w-full lg:col-span-6 flex flex-col justify-center">
              <div className="relative rounded-3xl bg-surface border border-separator shadow-2xl p-6 sm:p-8 overflow-hidden">
                {/* Card Header & Back Link (Desktop) */}
                <div className="hidden lg:flex items-center justify-between mb-5">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveView("home");
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="inline-flex items-center gap-1.5 text-xs text-label-2 hover:text-label transition-colors cursor-pointer group"
                  >
                    <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform" />
                    <span>กลับสู่หน้าร้านค้า</span>
                  </button>
                  <span className="text-xs text-label-3">
                    Astrax ID
                  </span>
                </div>

                {/* Segmented Mode Switcher (Login / Signup) */}
                {authMode !== "forgot" && (
                  <div className="p-1 rounded-full bg-surface-2 border border-separator mb-6 grid grid-cols-2 gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode("login");
                        setAuthPassword("");
                        setAuthConfirmPassword("");
                      }}
                      className={`py-2 px-3 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer flex items-center justify-center gap-1.5 ${
                        authMode === "login"
                          ? "bg-accent text-white shadow-sm"
                          : "text-label-2 hover:text-label hover:bg-surface"
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>เข้าสู่ระบบ</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode("signup");
                        setAuthPassword("");
                        setAuthConfirmPassword("");
                      }}
                      className={`py-2 px-3 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer flex items-center justify-center gap-1.5 ${
                        authMode === "signup"
                          ? "bg-accent text-white shadow-sm"
                          : "text-label-2 hover:text-label hover:bg-surface"
                      }`}
                    >
                      <User className="w-3.5 h-3.5" />
                      <span>สมัครสมาชิก</span>
                    </button>
                  </div>
                )}

                {/* Heading & Subheading */}
                <div className="mb-5">
                  <h2 className="text-xl sm:text-2xl font-semibold text-label tracking-tight flex items-center gap-2">
                    {authMode === "login" && "ลงชื่อเข้าใช้บัญชี"}
                    {authMode === "signup" && "สร้างบัญชีใหม่"}
                    {authMode === "forgot" && "รีเซ็ตรหัสผ่าน"}
                  </h2>
                  <p className="text-xs text-label-2 mt-1 font-normal">
                    {authMode === "login" &&
                      "เข้าสู่ระบบเพื่อเข้าถึงคลังสินค้าและบริการของคุณ"}
                    {authMode === "signup" &&
                      "กรอกข้อมูลเพื่อเริ่มต้นใช้งานระบบได้ทันที"}
                    {authMode === "forgot" &&
                      "กรอกอีเมลของคุณเพื่อรับลิงก์สำหรับตั้งรหัสผ่านใหม่"}
                  </p>
                </div>

                {/* Quick Demo Login Chips (DEV only) */}
                {import.meta.env.DEV && authMode === "login" && (
                  <div className="mb-5 p-3 rounded-2xl bg-surface-2 border border-separator">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-medium text-link">
                        ทดลองใช้งาน (Demo)
                      </span>
                      <span className="text-xs text-label-3">เฉพาะโหมด DEV</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleQuickDemoFill("admin")}
                        className="py-1.5 px-3 rounded-full bg-surface hover:bg-surface-2 border border-separator text-xs font-medium text-label transition-all flex items-center justify-center cursor-pointer active:scale-95 shadow-sm"
                      >
                        แอดมิน (Admin)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleQuickDemoFill("user")}
                        className="py-1.5 px-3 rounded-full bg-surface hover:bg-surface-2 border border-separator text-xs font-medium text-label transition-all flex items-center justify-center cursor-pointer active:scale-95 shadow-sm"
                      >
                        สมาชิก (User)
                      </button>
                    </div>
                  </div>
                )}

                {/* Real Firebase OAuth Action Buttons (Google / GitHub) */}
                {authMode !== "forgot" && (
                  <>
                    <div className="grid grid-cols-2 gap-2.5 mb-5">
                      {/* Google OAuth Button */}
                      <button
                        type="button"
                        onClick={handleGoogleLogin}
                        disabled={authLoading}
                        className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-full bg-surface-2 hover:bg-surface border border-separator text-xs font-medium text-label transition-all cursor-pointer disabled:opacity-50 active:scale-98 shadow-sm"
                      >
                        <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                          <path
                            fill="#4285F4"
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                          />
                          <path
                            fill="#34A853"
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                          />
                          <path
                            fill="#FBBC05"
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                          />
                          <path
                            fill="#EA4335"
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                          />
                        </svg>
                        <span>Google</span>
                      </button>

                      {/* GitHub OAuth Button */}
                      <button
                        type="button"
                        onClick={handleGithubLogin}
                        disabled={authLoading}
                        className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-full bg-surface-2 hover:bg-surface border border-separator text-xs font-medium text-label transition-all cursor-pointer disabled:opacity-50 active:scale-98 shadow-sm"
                      >
                        <svg
                          className="w-4 h-4 fill-current text-label shrink-0"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                        </svg>
                        <span>GitHub</span>
                      </button>
                    </div>

                    {/* Divider with 'หรือ' */}
                    <div className="relative flex items-center justify-center mb-5">
                      <div className="w-full border-t border-separator" />
                      <span className="absolute px-3 bg-surface text-xs text-label-3 font-normal">
                        หรือเข้าสู่ระบบด้วยบัญชี
                      </span>
                    </div>
                  </>
                )}

                {/* Form Fields */}
                <form onSubmit={handleAuth} className="space-y-4">
                  {/* 1. Username Field (UP FIRST for Signup) */}
                  {authMode === "signup" && (
                    <div>
                      <label className="block text-xs font-medium text-label-2 mb-1.5 ml-1">
                        ชื่อผู้ใช้ (Username) <span className="text-danger">*</span>
                      </label>
                      <div className="relative">
                        <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-label-3 pointer-events-none">
                          <User className="w-4 h-4" />
                        </div>
                        <input
                          ref={usernameInputRef}
                          type="text"
                          value={authUsername}
                          onChange={(e) => setAuthUsername(e.target.value)}
                          placeholder="ตั้งชื่อผู้ใช้ เช่น player99"
                          className="w-full pl-10 pr-4 py-2.5 rounded-full bg-surface-2 border border-separator focus:border-accent text-sm text-label placeholder:text-label-3 outline-none transition-all"
                          autoComplete="username"
                          required
                        />
                      </div>
                    </div>
                  )}

                  {/* 2. Email / Username Field */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5 ml-1">
                      <label className="block text-xs font-medium text-label-2">
                        {authMode === "signup" ? (
                          <>
                            อีเมล (Email) <span className="text-danger">*</span>
                          </>
                        ) : authMode === "forgot" ? (
                          <>
                            อีเมลที่ลงทะเบียนไว้ <span className="text-danger">*</span>
                          </>
                        ) : (
                          "ชื่อผู้ใช้ หรือ อีเมล"
                        )}
                      </label>
                      {authMode === "signup" && isEmailValid !== null && (
                        <span
                          className={`text-xs flex items-center gap-1 font-medium ${
                            isEmailValid ? "text-success" : "text-danger"
                          }`}
                        >
                          {isEmailValid ? (
                            <>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>อีเมลถูกต้อง</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3 h-3" />
                              <span>รูปแบบไม่ถูกต้อง</span>
                            </>
                          )}
                        </span>
                      )}
                      {authMode === "login" && authEmail && (
                        <span className="text-xs text-label-3">
                          {authEmail.includes("@") ? "โหมด: อีเมล" : "โหมด: ชื่อผู้ใช้"}
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-label-3 pointer-events-none">
                        {authMode === "signup" || authMode === "forgot" || authEmail.includes("@") ? (
                          <Mail className="w-4 h-4" />
                        ) : (
                          <User className="w-4 h-4" />
                        )}
                      </div>
                      <input
                        ref={emailInputRef}
                        type={authMode === "signup" || authMode === "forgot" ? "email" : "text"}
                        value={authEmail}
                        onChange={(e) => setAuthEmail(e.target.value)}
                        placeholder={
                          authMode === "signup" || authMode === "forgot"
                            ? "yourname@example.com"
                            : "ชื่อผู้ใช้ หรือ you@example.com"
                        }
                        className={`w-full pl-10 pr-4 py-2.5 rounded-full bg-surface-2 border ${
                          authMode !== "login" && isEmailValid === false
                            ? "border-danger focus:border-danger"
                            : "border-separator focus:border-accent"
                        } text-sm text-label placeholder:text-label-3 outline-none transition-all`}
                        autoComplete={
                          authMode === "signup" ? "email" : "username"
                        }
                        required
                      />
                    </div>
                  </div>

                  {/* 3. Password Field (for Login & Signup) */}
                  {authMode !== "forgot" && (
                    <div>
                      <div className="flex items-center justify-between mb-1.5 ml-1">
                        <label className="block text-xs font-medium text-label-2">
                          รหัสผ่าน (Password) <span className="text-danger">*</span>
                        </label>
                        {authMode === "login" && (
                          <button
                            type="button"
                            onClick={() => setAuthMode("forgot")}
                            className="text-xs text-link hover:underline transition-colors cursor-pointer"
                          >
                            ลืมรหัสผ่าน?
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-label-3 pointer-events-none">
                          <Lock className="w-4 h-4" />
                        </div>
                        <input
                          ref={passwordInputRef}
                          type={showPassword ? "text" : "password"}
                          value={authPassword}
                          onChange={(e) => setAuthPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-10 pr-11 py-2.5 rounded-full bg-surface-2 border border-separator focus:border-accent text-sm text-label placeholder:text-label-3 outline-none transition-all font-sans"
                          autoComplete={
                            authMode === "signup"
                              ? "new-password"
                              : "current-password"
                          }
                          required
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          aria-label={
                            showPassword ? "ซ่อนรหัสผ่าน" : "แสดงรหัสผ่าน"
                          }
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-label-2 hover:text-label transition-colors cursor-pointer p-1"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>

                      {/* Password Strength Meter for Signup */}
                      {authMode === "signup" && authPassword.length > 0 && (
                        <div className="mt-2.5 space-y-1.5 px-0.5">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-label-2 flex items-center gap-1 font-normal">
                              <ShieldCheck className="w-3.5 h-3.5 text-label-3" />
                              ความปลอดภัยรหัสผ่าน:
                            </span>
                            <span className={`font-medium ${passwordStrength.textColor}`}>
                              {passwordStrength.text}
                            </span>
                          </div>
                          <div className="w-full h-1.5 bg-surface-2 rounded-full overflow-hidden flex gap-1">
                            <div
                              className={`h-full flex-1 rounded-full transition-all duration-300 ${
                                passwordStrength.score >= 1
                                  ? passwordStrength.color
                                  : "bg-transparent"
                              }`}
                            />
                            <div
                              className={`h-full flex-1 rounded-full transition-all duration-300 ${
                                passwordStrength.score >= 2
                                  ? passwordStrength.color
                                  : "bg-transparent"
                              }`}
                            />
                            <div
                              className={`h-full flex-1 rounded-full transition-all duration-300 ${
                                passwordStrength.score >= 3
                                  ? passwordStrength.color
                                  : "bg-transparent"
                              }`}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* 4. Confirm Password (for Signup) */}
                  {authMode === "signup" && (
                    <div>
                      <div className="flex items-center justify-between mb-1.5 ml-1">
                        <label className="block text-xs font-medium text-label-2">
                          ยืนยันรหัสผ่านอีกครั้ง <span className="text-danger">*</span>
                        </label>
                        {passwordsMatch !== null && (
                          <span
                            className={`text-xs font-medium flex items-center gap-1 ${
                              passwordsMatch
                                ? "text-success"
                                : "text-danger"
                            }`}
                          >
                            {passwordsMatch ? (
                              <>
                                <Check className="w-3 h-3" />
                                <span>รหัสผ่านตรงกัน</span>
                              </>
                            ) : (
                              <>
                                <XCircle className="w-3 h-3" />
                                <span>รหัสผ่านไม่ตรงกัน</span>
                              </>
                            )}
                          </span>
                        )}
                      </div>
                      <div className="relative">
                        <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-label-3 pointer-events-none">
                          <KeyRound className="w-4 h-4" />
                        </div>
                        <input
                          type={showConfirmPassword ? "text" : "password"}
                          value={authConfirmPassword}
                          onChange={(e) =>
                            setAuthConfirmPassword(e.target.value)
                          }
                          placeholder="••••••••"
                          className="w-full pl-10 pr-11 py-2.5 rounded-full bg-surface-2 border border-separator focus:border-accent text-sm text-label placeholder:text-label-3 outline-none transition-all font-sans"
                          autoComplete="new-password"
                          required
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setShowConfirmPassword(!showConfirmPassword)
                          }
                          aria-label={
                            showConfirmPassword
                              ? "ซ่อนรหัสผ่านยืนยัน"
                              : "แสดงรหัสผ่านยืนยัน"
                          }
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-label-2 hover:text-label transition-colors cursor-pointer p-1"
                        >
                          {showConfirmPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* 5. Remember Me (Login) or Agree Terms (Signup) */}
                  {authMode === "login" && (
                    <div className="flex items-center justify-between pt-1">
                      <label className="flex items-center gap-2 cursor-pointer select-none group">
                        <input
                          type="checkbox"
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="w-4 h-4 rounded border-separator bg-surface-2 text-accent focus:ring-accent cursor-pointer"
                        />
                        <span className="text-xs text-label-2 group-hover:text-label transition-colors">
                          จดจำการเข้าสู่ระบบ
                        </span>
                      </label>
                      <span className="text-xs text-label-3 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-link" />
                        <span>เข้ารหัสปลอดภัย</span>
                      </span>
                    </div>
                  )}

                  {authMode === "signup" && (
                    <div className="pt-1">
                      <label className="flex items-start gap-2 cursor-pointer select-none group">
                        <input
                          type="checkbox"
                          checked={agreeTerms}
                          onChange={(e) => setAgreeTerms(e.target.checked)}
                          className="w-4 h-4 mt-0.5 rounded border-separator bg-surface-2 text-accent focus:ring-accent cursor-pointer"
                        />
                        <span className="text-xs text-label-2 group-hover:text-label transition-colors leading-relaxed">
                          ฉันยอมรับ{" "}
                          <span className="text-link underline">
                            ข้อตกลงและเงื่อนไขการใช้งาน
                          </span>{" "}
                          และนโยบายความเป็นส่วนตัวของร้านค้า
                        </span>
                      </label>
                    </div>
                  )}

                  {/* Primary Submit Button */}
                  <button
                    type="submit"
                    disabled={authLoading}
                    className="w-full mt-2 py-3 px-4 rounded-full bg-accent hover:bg-accent-hover text-white font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shadow-sm active:scale-[0.99] group"
                  >
                    {authLoading ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                        <span>กำลังดำเนินการ...</span>
                      </>
                    ) : (
                      <>
                        <span>
                          {authMode === "login" && "เข้าสู่ระบบ"}
                          {authMode === "signup" && "สร้างบัญชีและเริ่มต้นใช้งาน"}
                          {authMode === "forgot" && "ส่งลิงก์รีเซ็ตรหัสผ่าน"}
                        </span>
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </button>
                </form>

                {/* Bottom Switch Links */}
                <div className="mt-6 pt-5 border-t border-separator text-center text-xs text-label-2">
                  {authMode === "login" && (
                    <p>
                      ยังไม่มีบัญชีสมาชิกใช่หรือไม่?{" "}
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode("signup");
                          setAuthPassword("");
                          setAuthConfirmPassword("");
                        }}
                        className="text-link hover:underline font-medium cursor-pointer ml-1 inline-flex items-center gap-0.5"
                      >
                        <span>สมัครสมาชิกฟรี</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </p>
                  )}

                  {authMode === "signup" && (
                    <p>
                      มีบัญชีอยู่แล้วใช่หรือไม่?{" "}
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode("login");
                          setAuthPassword("");
                          setAuthConfirmPassword("");
                        }}
                        className="text-link hover:underline font-medium cursor-pointer ml-1 inline-flex items-center gap-0.5"
                      >
                        <span>เข้าสู่ระบบที่นี่</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </p>
                  )}

                  {authMode === "forgot" && (
                    <p>
                      จำรหัสผ่านได้แล้วใช่หรือไม่?{" "}
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode("login");
                          setAuthPassword("");
                          setAuthConfirmPassword("");
                        }}
                        className="text-link hover:underline font-medium cursor-pointer ml-1 inline-flex items-center gap-0.5"
                      >
                        <span>กลับสู่หน้าเข้าสู่ระบบ</span>
                      </button>
                    </p>
                  )}
                </div>

                {/* Security Footnote */}
                <div className="mt-4 text-center">
                  <p className="text-xs text-label-3 flex items-center justify-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-success" />
                    <span>ข้อมูลและการเชื่อมต่อได้รับการคุ้มครองด้วยการเข้ารหัส SSL 256-Bit</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
);

export default AuthView;

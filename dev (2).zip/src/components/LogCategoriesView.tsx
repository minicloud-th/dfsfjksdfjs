import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Folder, Lock, Search, Download, FileText, Image as ImageIcon, ChevronRight, Gift, X, Copy, Check } from 'lucide-react';
import Swal from 'sweetalert2';
import axios from 'axios';
export interface ContentItem {
  id: string;
  categoryId: string;
  type: 'free' | 'premium';
  title: string;
  keyword?: string;
  attachments?: any[];
  unlockAt?: string;
  createdAt?: string;
}

export interface LogCategory {
  id: string;
  name: string;
  subtitle: string;
  icon: string;
  isVisible: boolean;
  isVip: boolean;
  order: number;
}

interface LogCategoriesViewProps {
  userPlan: any;
  onNavigateAction: (action: string) => void;
  filterType?: 'all' | 'vip' | 'free';
  isAdmin?: boolean;
}

function getSafeUrl(url: string | undefined): string | null {
  if (!url) return null;
  const trimmed = url.trim();
  if (/^https?:\/\//i.test(trimmed) || /^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(trimmed)) {
    return trimmed;
  }
  return null;
}

export const LogCategoriesView: React.FC<LogCategoriesViewProps> = ({ userPlan, filterType = 'all' }) => {
  const [categories, setCategories] = useState<LogCategory[]>([]);
  const [items, setItems] = useState<ContentItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<LogCategory | null>(null);
  const [search, setSearch] = useState('');
  const [isVip, setIsVip] = useState(false);
  const [activeModalItem, setActiveModalItem] = useState<ContentItem | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get('/api/logs-system');
        setCategories((res.data.categories || []).filter((c: any) => c.isVisible));
        setItems(res.data.items || []);
        setIsVip(res.data.isVip || false);
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
  }, []);

  const handleOpenItem = (item: ContentItem) => {
    if (item.type === 'premium' && !isVip) {
       Swal.fire({
          icon: 'warning',
          title: 'สำหรับสมาชิก VIP เท่านั้น!',
          text: 'คุณต้องเป็น VIP จึงจะสามารถดูหรือดาวน์โหลดได้',
          background: '#09090b',
          color: '#fff',
          confirmButtonText: 'ตกลง',
          confirmButtonColor: '#2563EB'
       });
       return;
    }

    if (!item.attachments || item.attachments.length === 0) {
        Swal.fire({
            icon: 'error',
            title: 'ไม่พบเนื้อหา',
            text: 'ถูกซ่อนหรือไม่มีข้อมูล',
            background: '#09090b',
            color: '#fff'
        });
        return;
    }

    setActiveModalItem(item);
  };

  const handleCopyText = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  useEffect(() => {
    setSelectedCategory(null);
  }, [filterType]);

  const currentItems = selectedCategory 
    ? items.filter(i => i.categoryId === selectedCategory.id && i.title.toLowerCase().includes(search.toLowerCase()))
    : [];

  const filteredCategories = categories.filter(c => {
    if (filterType === 'vip') return c.isVip;
    if (filterType === 'free') return !c.isVip;
    return true;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pt-20 text-label font-sans">
       <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
         <div>
            <h1 className="text-2xl sm:text-3xl font-semibold text-label tracking-tight flex items-center gap-3">
              <Gift className="w-7 h-7 text-accent" /> {filterType === 'vip' ? 'คลังทรัพยากร VIP' : filterType === 'free' ? 'คลังทรัพยากรฟรี' : 'ทรัพยากรและเครื่องมือ'}
            </h1>
            <p className="text-xs sm:text-sm font-normal text-label-2 mt-1">ดาวน์โหลดไฟล์และเอกสารข้อมูลสำหรับสมาชิก</p>
         </div>
       </div>

       {selectedCategory ? (
         <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <div className="flex items-center gap-4 mb-6">
               <button onClick={() => setSelectedCategory(null)} className="px-4 py-2 bg-surface-2 hover:bg-surface border border-separator text-label font-medium text-xs rounded-full transition-all cursor-pointer">
                 ย้อนกลับ
               </button>
               <h2 className="text-lg font-semibold text-label flex items-center gap-2">
                 {selectedCategory.name}
                 {selectedCategory.isVip && <span className="bg-warning/15 text-warning px-2.5 py-0.5 rounded-full text-xs font-semibold">VIP</span>}
               </h2>
               <div className="ml-auto w-48 relative">
                 <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-label-3" />
                 <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ค้นหา..." className="w-full bg-surface border border-separator pl-9 pr-4 py-2 text-xs text-label rounded-full outline-none focus:border-accent" />
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {currentItems.map((item) => {
                 const isLocked = item.type === 'premium' && !isVip;
                 return (
                    <div key={item.id} onClick={() => handleOpenItem(item)} className={`bg-surface border border-separator p-5 cursor-pointer hover:border-accent/50 transition-all rounded-3xl shadow-sm ${isLocked ? 'opacity-70' : 'hover:-translate-y-0.5'}`}>
                      <div className="flex justify-between items-start mb-3">
                        <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${item.type === 'premium' ? 'bg-warning/15 text-warning' : 'bg-accent/15 text-accent'}`}>
                          {item.type === 'premium' ? 'VIP' : 'ทั่วไป'}
                        </span>
                        {isLocked ? <Lock className="w-4 h-4 text-label-3"/> : <Download className="w-4 h-4 text-accent"/>}
                      </div>
                      <h3 className="text-base font-semibold text-label mb-1.5">{item.title}</h3>
                      {item.keyword && <span className="text-xs text-label-3 font-normal">#{item.keyword}</span>}
                   </div>
                 );
              })}
              {currentItems.length === 0 && <div className="col-span-full py-12 text-center text-label-3 text-xs">ไม่พบเนื้อหาในหมวดหมู่นี้</div>}
            </div>
         </motion.div>
       ) : (
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
           <AnimatePresence>
             {filteredCategories.sort((a,b)=>a.order-b.order).map((c, i) => {
               const catItemsCount = items.filter(it => it.categoryId === c.id).length;
               return (
                 <motion.div
                   key={c.id} 
                   initial={{ opacity: 0, y: 15 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ delay: i * 0.04 }}
                   onClick={() => { setSelectedCategory(c); setSearch(''); }}
                   className="bg-surface border border-separator hover:border-accent/40 rounded-3xl overflow-hidden transition-all cursor-pointer group flex flex-col shadow-sm"
                 >
                   <div className="p-6 flex-1 flex flex-col">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-12 h-12 bg-surface-2 border border-separator flex items-center justify-center text-accent rounded-2xl group-hover:scale-105 transition-transform">
                          <Folder className="w-6 h-6" />
                        </div>
                        {c.isVip && <span className="bg-warning/15 text-warning border border-warning/20 px-3 py-1 rounded-full text-xs font-semibold">VIP</span>}
                      </div>
                      <h2 className="text-lg font-semibold text-label group-hover:text-accent transition-colors tracking-tight">{c.name}</h2>
                      <p className="text-xs text-label-2 mt-1 mb-4 flex-1 font-normal leading-relaxed">{c.subtitle}</p>
                      
                      <div className="w-full flex items-center justify-between pt-4 border-t border-separator mt-auto">
                        <span className="text-xs font-normal text-label-3">{catItemsCount} รายการ</span>
                        <div className="w-8 h-8 rounded-full bg-surface-2 flex items-center justify-center text-label-2 group-hover:text-label transition-all">
                          <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-all" />
                        </div>
                      </div>
                   </div>
                 </motion.div>
               );
             })}
           </AnimatePresence>
         </div>
       )}

       {/* Safe React Attachment Modal (Immune to DOM XSS) */}
       <AnimatePresence>
         {activeModalItem && (
           <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xl" role="dialog" aria-modal="true">
             <motion.div 
               initial={{ opacity: 0, scale: 0.95 }}
               animate={{ opacity: 1, scale: 1 }}
               exit={{ opacity: 0, scale: 0.95 }}
               className="bg-surface border border-separator rounded-3xl w-full max-w-xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl text-label"
             >
               {/* Header */}
               <div className="flex items-center justify-between p-5 border-b border-separator">
                 <h2 className="text-base font-semibold text-label truncate pr-4">{activeModalItem.title}</h2>
                 <button 
                   onClick={() => setActiveModalItem(null)} 
                   className="text-label-3 hover:text-label p-1.5 rounded-full hover:bg-surface-2 transition-all cursor-pointer"
                   aria-label="ปิด"
                 >
                   <X className="w-4 h-4" />
                 </button>
               </div>

               {/* Attachments list */}
               <div className="p-5 overflow-y-auto space-y-4 flex-1">
                 {activeModalItem.attachments?.map((att: any, idx: number) => {
                   const safeUrl = getSafeUrl(att.data);
                   
                   if (att.type === 'image') {
                     return (
                       <div key={idx} className="rounded-2xl overflow-hidden border border-separator bg-surface-2">
                         {safeUrl ? (
                           <img 
                             loading="lazy" 
                             src={safeUrl} 
                             alt={activeModalItem.title} 
                             className="w-full object-contain max-h-80"
                             referrerPolicy="no-referrer"
                           />
                         ) : (
                           <div className="p-4 text-xs text-label-3 text-center">URL รูปภาพไม่ปลอดภัยหรือไม่ถูกต้อง</div>
                         )}
                       </div>
                     );
                   }

                   if (att.type === 'file') {
                     return (
                       <div key={idx}>
                         {safeUrl ? (
                           <a 
                             href={safeUrl} 
                             target="_blank" 
                             rel="noopener noreferrer"
                             className="flex items-center justify-center gap-2 w-full py-2.5 bg-accent hover:bg-accent-hover text-white rounded-full text-center font-medium text-xs transition-all shadow-sm"
                           >
                             <Download className="w-4 h-4" /> ดาวน์โหลดไฟล์
                           </a>
                         ) : (
                           <div className="p-3 bg-danger/10 border border-danger/20 text-danger text-xs rounded-2xl text-center font-normal">
                             ลิงก์ไฟล์ไม่ถูกต้อง
                           </div>
                         )}
                       </div>
                     );
                   }

                   // Plain text / Account data
                   return (
                     <div key={idx} className="relative bg-surface-2 border border-separator rounded-2xl p-4">
                       <div className="flex items-center justify-between mb-2">
                         <span className="text-xs font-medium text-label-2 flex items-center gap-1.5">
                           <FileText className="w-3.5 h-3.5 text-accent" /> ข้อมูลเนื้อหา
                         </span>
                         <button
                           onClick={() => handleCopyText(att.data || '', idx)}
                           className="flex items-center gap-1 px-3 py-1 text-xs font-medium text-label-2 hover:text-label bg-surface hover:bg-surface-2 border border-separator rounded-full transition-all cursor-pointer"
                         >
                           {copiedIndex === idx ? (
                             <>
                               <Check className="w-3.5 h-3.5 text-success" />
                               <span className="text-success">คัดลอกแล้ว</span>
                             </>
                           ) : (
                             <>
                               <Copy className="w-3.5 h-3.5" />
                               <span>คัดลอก</span>
                             </>
                           )}
                         </button>
                       </div>
                       <pre className="text-xs font-mono text-label whitespace-pre-wrap break-all select-all max-h-48 overflow-y-auto bg-surface p-3 rounded-xl border border-separator">
                         {att.data || '(ไม่มีข้อมูล)'}
                       </pre>
                     </div>
                   );
                 })}
               </div>

               {/* Footer */}
               <div className="p-4 border-t border-separator bg-surface-2/40 flex justify-end">
                 <button 
                   onClick={() => setActiveModalItem(null)} 
                   className="px-5 py-2 bg-surface hover:bg-surface-2 border border-separator text-label font-medium text-xs rounded-full transition-all cursor-pointer"
                 >
                   ปิด
                 </button>
               </div>
             </motion.div>
           </div>
         )}
       </AnimatePresence>
    </div>
  );
};

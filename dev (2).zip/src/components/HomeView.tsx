import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import axios from "axios";
import { Product, SiteStats, Category } from "../types";
import { ProductCard } from "./ProductCard";
import { ProductCardSkeleton } from "./ui/Skeleton";
import {
  Users,
  ShoppingBag,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Zap,
  ShieldCheck,
  CreditCard,
  Headphones,
  Package,
  Gamepad2,
  Tv,
  Wrench,
  Tag,
  Clock,
  Layers,
  CheckCircle2,
} from "lucide-react";

interface RecentPurchaseItem {
  id: string;
  productName: string;
  username: string;
  price: number;
  date: string;
  imageUrl?: string;
  productId?: string;
  dbId?: string;
}

interface HomeViewProps {
  products: Product[];
  categories: Category[];
  stats: SiteStats;
  user?: any;
  siteSettings?: any;
  purchaseHistory?: any[];
  isLoading?: boolean;
  setActiveView: (view: any) => void;
  onProductClick: (id: string) => void;
  onSelectCategory?: (categoryId: string) => void;
}

const formatTimeAgo = (dateStr: string) => {
  try {
    const diffMs = Date.now() - new Date(dateStr).getTime();
    if (isNaN(diffMs) || diffMs < 0) return "เมื่อสักครู่";
    const diffSec = Math.floor(diffMs / 1000);
    if (diffSec < 60) return "เมื่อสักครู่";
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin} นาทีที่แล้ว`;
    const diffHour = Math.floor(diffMin / 60);
    if (diffHour < 24) return `${diffHour} ชั่วโมงที่แล้ว`;
    const diffDay = Math.floor(diffHour / 24);
    return `${diffDay} วันที่แล้ว`;
  } catch {
    return "เมื่อสักครู่";
  }
};

export const HomeView: React.FC<HomeViewProps> = ({
  products = [],
  categories = [],
  stats,
  user,
  siteSettings,
  purchaseHistory = [],
  isLoading = false,
  setActiveView,
  onProductClick,
  onSelectCategory,
}) => {
  const [currentBanner, setCurrentBanner] = useState<number>(0);
  const [selectedCategoryTab, setSelectedCategoryTab] = useState<string>("all");
  const [livePurchases, setLivePurchases] = useState<RecentPurchaseItem[]>([]);
  const bannerTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Poll live purchases from server
  useEffect(() => {
    let isMounted = true;
    const fetchLatestPurchases = async () => {
      try {
        const res = await axios.get("/api/latest-purchases");
        if (
          res.data &&
          Array.isArray(res.data) &&
          res.data.length > 0 &&
          isMounted
        ) {
          setLivePurchases(res.data);
        }
      } catch (e) {
        // Fallback gracefully
      }
    };
    fetchLatestPurchases();
    const interval = setInterval(fetchLatestPurchases, 15000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const safeProducts = useMemo(
    () => (Array.isArray(products) ? products : []),
    [products]
  );

  const safeCategories = useMemo(
    () => (Array.isArray(categories) ? categories : []),
    [categories]
  );

  const banners = useMemo(() => {
    if (
      siteSettings?.banners &&
      Array.isArray(siteSettings.banners) &&
      siteSettings.banners.length > 0
    ) {
      return siteSettings.banners.filter(
        (b: any) => typeof b === "string" && b.trim() !== ""
      );
    }
    return [
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80",
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1600&q=80",
    ];
  }, [siteSettings]);

  useEffect(() => {
    if (banners.length <= 1) return;
    bannerTimerRef.current = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length);
    }, 6000);
    return () => {
      if (bannerTimerRef.current) clearInterval(bannerTimerRef.current);
    };
  }, [banners.length]);

  const handlePrevBanner = () => {
    if (bannerTimerRef.current) clearInterval(bannerTimerRef.current);
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const handleNextBanner = () => {
    if (bannerTimerRef.current) clearInterval(bannerTimerRef.current);
    setCurrentBanner((prev) => (prev + 1) % banners.length);
  };

  const totalSales =
    siteSettings?.stats_sales_override != null
      ? Number(siteSettings.stats_sales_override)
      : stats?.sales ?? 0;

  const totalMembers =
    siteSettings?.stats_users_override != null
      ? Number(siteSettings.stats_users_override)
      : stats?.users ?? 0;

  // Filter products by selected category tab
  const filteredProducts = useMemo(() => {
    if (selectedCategoryTab === "all") {
      // Prioritize popular items first
      const popular = safeProducts.filter((p) => p.isPopular);
      return popular.length > 0 ? popular : safeProducts.slice(0, 8);
    }
    return safeProducts.filter(
      (p) =>
        p.category === selectedCategoryTab ||
        (typeof p.category === "string" &&
          p.category.toLowerCase().includes(selectedCategoryTab.toLowerCase()))
    );
  }, [safeProducts, selectedCategoryTab]);

  // Clean list of recent purchases strictly from DB / props
  const recentPurchases = useMemo(() => {
    const combined: RecentPurchaseItem[] = [];

    if (Array.isArray(livePurchases) && livePurchases.length > 0) {
      livePurchases.forEach((lp) => {
        if (
          !combined.some(
            (c) => c.id === lp.id || (lp.dbId && c.dbId === lp.dbId)
          )
        ) {
          combined.push(lp);
        }
      });
    }

    if (Array.isArray(purchaseHistory) && purchaseHistory.length > 0) {
      purchaseHistory.slice(0, 10).forEach((item: any, idx: number) => {
        const rawUser =
          item.username ||
          (item.userEmail ? item.userEmail.split("@")[0] : "user");
        const masked =
          rawUser.length > 3
            ? rawUser.substring(0, 3) + "***"
            : rawUser + "***";
        const itemId = item.id || item.dbId || `prop-${idx}`;
        if (!combined.some((c) => c.id === itemId)) {
          combined.push({
            id: itemId,
            productName:
              item.productName || item.product_name || "สินค้าดิจิทัล",
            username: masked,
            price: Number(item.price) || 0,
            date: item.date || item.created_at || new Date().toISOString(),
            imageUrl: item.imageUrl,
            productId: item.productId,
          });
        }
      });
    }

    return combined.slice(0, 6);
  }, [purchaseHistory, livePurchases]);

  // Latest purchase activity ticker
  const latestOrder = recentPurchases[0] || null;

  return (
    <div className="w-full min-h-screen text-label bg-bg font-sans antialiased selection:bg-accent/30 selection:text-white pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-12 sm:space-y-16">

        {latestOrder && (
          <div className="pt-2 flex justify-center">
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={() => {
                if (latestOrder.productId) {
                  onProductClick(latestOrder.productId);
                }
              }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-surface-2 border border-separator text-xs text-label-2 transition-all cursor-pointer backdrop-blur-xl shadow-sm hover:scale-[1.01]"
            >
              <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
              <span className="text-label-3 text-xs font-medium">คำสั่งซื้อล่าสุด</span>
              <span className="text-label-3">·</span>
              <span className="text-label font-medium truncate max-w-[180px] sm:max-w-xs">
                {latestOrder.productName}
              </span>
              <span className="text-label-2 text-xs font-sans tabular-nums">
                (฿{latestOrder.price.toLocaleString()})
              </span>
              <span className="text-label-3 text-xs">
                {formatTimeAgo(latestOrder.date)}
              </span>
            </motion.div>
          </div>
        )}

        <section className="text-center pt-2 sm:pt-4">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-semibold tracking-tight text-label leading-[1.08] max-w-4xl mx-auto">
            Astrax Store
          </h1>

          <p className="text-sm sm:text-base lg:text-lg text-label-2 max-w-2xl mx-auto mt-4 sm:mt-5 leading-relaxed font-normal">
            ไอดีเกม บัญชีสตรีมมิ่ง และโค้ดเติมเงิน ส่งเข้าบัญชีอัตโนมัติหลังชำระเงิน พร้อมการรับประกันตลอดการใช้งาน
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 mt-7 sm:mt-8">
            <button
              onClick={() => {
                setActiveView("categories");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="px-6 py-2.5 rounded-full bg-accent hover:bg-accent-hover text-white text-xs sm:text-sm font-medium transition-all duration-150 shadow-sm hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2 cursor-pointer"
            >
              <span>สำรวจสินค้าทั้งหมด</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                setActiveView(user ? "wallet" : "login");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="px-6 py-2.5 rounded-full bg-surface-2 hover:bg-surface text-label border border-separator text-xs sm:text-sm font-medium transition-all duration-150 active:scale-[0.98] cursor-pointer"
            >
              <span>เติมเงินเข้าบัญชี</span>
            </button>
          </div>
        </section>

        <section className="relative w-full">
          <div className="relative aspect-[16/9] sm:aspect-[21/9] w-full rounded-3xl overflow-hidden border border-separator bg-surface group shadow-2xl">
            {banners.map((bannerUrl: string, idx: number) => (
              <div
                key={idx}
                className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
                  idx === currentBanner
                    ? "opacity-100 z-10"
                    : "opacity-0 z-0 pointer-events-none"
                }`}
              >
                <img
                  src={bannerUrl}
                  alt={`Astrax Feature ${idx + 1}`}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  loading={idx === 0 ? "eager" : "lazy"}
                />
                {/* Apple Vignette Gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent pointer-events-none" />
              </div>
            ))}

            {/* Carousel Controls */}
            {banners.length > 1 && (
              <>
                <button
                  onClick={handlePrevBanner}
                  className="absolute left-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md text-white/80 hover:text-white transition-all flex items-center justify-center z-20 cursor-pointer opacity-0 group-hover:opacity-100 border border-white/10 active:scale-95"
                  aria-label="Previous Banner"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextBanner}
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md text-white/80 hover:text-white transition-all flex items-center justify-center z-20 cursor-pointer opacity-0 group-hover:opacity-100 border border-white/10 active:scale-95"
                  aria-label="Next Banner"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </>
            )}
          </div>

          {/* Dots Indicator */}
          {banners.length > 1 && (
            <div className="flex items-center justify-center gap-1.5 mt-3.5">
              {banners.map((_: string, dotIdx: number) => (
                <button
                  key={dotIdx}
                  onClick={() => {
                    if (bannerTimerRef.current)
                      clearInterval(bannerTimerRef.current);
                    setCurrentBanner(dotIdx);
                  }}
                  className={`transition-all duration-300 rounded-full cursor-pointer ${
                    dotIdx === currentBanner
                      ? "w-6 h-1 bg-accent"
                      : "w-1 h-1 bg-label-3/40 hover:bg-label-3"
                  }`}
                  aria-label={`Slide ${dotIdx + 1}`}
                />
              ))}
            </div>
          )}
        </section>

        {/* ── 4. Apple Department Rail (Category Selector) ── */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl sm:text-2xl font-semibold tracking-tight text-label">
                หมวดหมู่สินค้า
              </h2>
              <p className="text-xs sm:text-sm text-label-2 mt-0.5">
                เลือกดูบริการและสินค้าตามประเภทที่ต้องการ
              </p>
            </div>
            <button
              onClick={() => {
                setActiveView("categories");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="text-xs font-medium text-link hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>ดูหมวดหมู่ทั้งหมด</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Segmented Pill Rail */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedCategoryTab("all")}
              className={`px-4 py-2 rounded-full text-xs font-medium transition-all duration-150 shrink-0 cursor-pointer ${
                selectedCategoryTab === "all"
                  ? "bg-label text-bg shadow-sm"
                  : "bg-surface-2 text-label-2 hover:bg-surface hover:text-label"
              }`}
            >
              ยอดนิยมทั้งหมด
            </button>

            {safeCategories.slice(0, 6).map((cat) => {
              const catId = cat.id || cat.name;
              const isSelected = selectedCategoryTab === catId;
              return (
                <button
                  key={catId}
                  onClick={() => setSelectedCategoryTab(catId)}
                  className={`px-4 py-2 rounded-full text-xs font-medium transition-all duration-150 shrink-0 cursor-pointer ${
                    isSelected
                      ? "bg-label text-bg shadow-sm"
                      : "bg-surface-2 text-label-2 hover:bg-surface hover:text-label"
                  }`}
                >
                  {cat.title || cat.name}
                </button>
              );
            })}
          </div>
        </section>

        <section className="space-y-4">
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
              <ProductCardSkeleton count={8} />
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onClick={onProductClick}
                />
              ))}
            </div>
          ) : (
            <div className="py-16 px-4 text-center rounded-3xl bg-surface border border-separator">
              <Package className="w-8 h-8 text-label-3 mx-auto mb-2" />
              <p className="text-sm font-semibold text-label">
                ยังไม่มีสินค้าในหมวดหมู่นี้
              </p>
              <p className="text-xs text-label-2 mt-1">
                กรุณาเลือกหมวดหมู่อื่นเพื่อดูรายการสินค้าพร้อมจัดส่ง
              </p>
            </div>
          )}
        </section>

        <section className="pt-6 sm:pt-10">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-label">
              บริการของเรา
            </h2>
            <p className="text-xs sm:text-sm text-label-2 mt-1 max-w-md mx-auto">
              ความมั่นใจและมาตรฐานในทุกคำสั่งซื้อ
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
            <div className="p-6 rounded-3xl bg-surface border border-separator">
              <h3 className="text-sm sm:text-base font-semibold text-label tracking-tight mb-1">
                จัดส่งอัตโนมัติ
              </h3>
              <p className="text-xs text-label-2 leading-relaxed font-normal">
                ส่งมอบไอดีและโค้ดเข้าบัญชีทันทีหลังชำระเงินสำเร็จ
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-surface border border-separator">
              <h3 className="text-sm sm:text-base font-semibold text-label tracking-tight mb-1">
                รับประกันคุณภาพ
              </h3>
              <p className="text-xs text-label-2 leading-relaxed font-normal">
                สินค้าทุกชิ้นผ่านการตรวจสอบ พร้อมทีมงานดูแลและรับประกัน
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-surface border border-separator">
              <h3 className="text-sm sm:text-base font-semibold text-label tracking-tight mb-1">
                ระบบสมาชิก VIP
              </h3>
              <p className="text-xs text-label-2 leading-relaxed font-normal">
                สะสมยอดสั่งซื้อเพื่อรับส่วนลดและสิทธิพิเศษเพิ่มเติม
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-surface border border-separator">
              <h3 className="text-sm sm:text-base font-semibold text-label tracking-tight mb-1">
                ทีมงานดูแลลูกค้า
              </h3>
              <p className="text-xs text-label-2 leading-relaxed font-normal">
                ติดต่อสอบถามและรับการช่วยเหลือผ่านช่องทางบริการลูกค้า
              </p>
            </div>
          </div>
        </section>

        {(totalMembers > 0 || totalSales > 0) && (
          <section className="p-8 sm:p-10 rounded-3xl bg-surface border border-separator">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8 text-center divide-y sm:divide-y-0 sm:divide-x divide-separator">
              <div className="pt-4 sm:pt-0">
                <div className="text-3xl sm:text-4xl font-semibold text-label tracking-tight tabular-nums font-sans">
                  {totalMembers.toLocaleString()}+
                </div>
                <div className="text-xs text-label-2 mt-1">สมาชิกในระบบ</div>
              </div>

              <div className="pt-4 sm:pt-0">
                <div className="text-3xl sm:text-4xl font-semibold text-label tracking-tight tabular-nums font-sans">
                  {totalSales.toLocaleString()}+
                </div>
                <div className="text-xs text-label-2 mt-1">คำสั่งซื้อจัดส่งสำเร็จ</div>
              </div>
            </div>
          </section>
        )}

      </div>
    </div>
  );
};

export default HomeView;

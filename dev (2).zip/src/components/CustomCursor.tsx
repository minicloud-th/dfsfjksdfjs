import React from 'react';

/**
 * Native hardware-accelerated cursor for zero latency & 60fps smooth scrolling.
 */
export const CustomCursor: React.FC = () => {
  return null;
};

export default CustomCursor;

import React, { useState, useEffect, useRef } from "react";
import {
  Search,
  Menu,
  X,
  Wallet,
  ShieldCheck,
  User,
  ShoppingBag,
  CreditCard,
  LogOut,
  ChevronDown,
  LogIn,
  Sun,
  Moon,
} from "lucide-react";
import { DevLogo } from "./DevLogo";
import { getAvatarUrl } from "../lib/avatar";
import { useTheme } from "../lib/theme";
import { motion, AnimatePresence } from "motion/react";

interface HeaderNavbarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  user: any;
  userPlan: any;
  isAdmin: boolean;
  onLogout: () => void;
  onOpenSearch: () => void;
  onOpenContact: () => void;
  onOpenSupabaseConfig?: () => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
  isDesktopUserMenuOpen?: boolean;
  setIsDesktopUserMenuOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  isUserMenuOpen?: boolean;
  setIsUserMenuOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  settingsImport?: () => void;
  historyImport?: () => void;
}

export const HeaderNavbar: React.FC<HeaderNavbarProps> = ({
  activeView,
  setActiveView,
  user,
  userPlan,
  isAdmin,
  onLogout,
  onOpenSearch,
  onOpenContact,
  isMobileMenuOpen,
  setIsMobileMenuOpen,
  isDesktopUserMenuOpen,
  setIsDesktopUserMenuOpen,
}) => {
  const { theme, toggleTheme } = useTheme();
  const [internalUserMenuOpen, setInternalUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const isUserDropdownOpen =
    isDesktopUserMenuOpen !== undefined ? isDesktopUserMenuOpen : internalUserMenuOpen;
  const setUserDropdownOpen = (open: boolean) => {
    if (setIsDesktopUserMenuOpen) {
      setIsDesktopUserMenuOpen(open);
    } else {
      setInternalUserMenuOpen(open);
    }
  };

  // Keyboard shortcut '/' to open search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === "/" &&
        !["INPUT", "TEXTAREA"].includes((e.target as HTMLElement)?.tagName)
      ) {
        e.preventDefault();
        onOpenSearch();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onOpenSearch]);

  // Close desktop user dropdown on click outside or Escape
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserDropdownOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isUserDropdownOpen) {
        setUserDropdownOpen(false);
      }
    };

    if (isUserDropdownOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isUserDropdownOpen]);

  const isShopActive =
    activeView === "categories" ||
    activeView === "category_products" ||
    activeView === "product_detail";

  const isHistoryActive =
    activeView === "log_categories" ||
    activeView === "vip_logs" ||
    activeView === "free_logs" ||
    activeView === "logs" ||
    activeView === "history" ||
    activeView === "order_history" ||
    activeView === "random_history" ||
    activeView === "wallet_history";

  const navLinks = [
    { id: "home", label: "หน้าแรก", view: "home", isActive: activeView === "home" },
    { id: "categories", label: "ร้านค้า", view: "categories", isActive: isShopActive },
    { id: "wallet", label: "เติมเงิน", view: user ? "wallet" : "login", isActive: activeView === "wallet" },
    { id: "history", label: "ประวัติการซื้อ", view: user ? "history" : "login", isActive: isHistoryActive },
    { id: "contact", label: "ติดต่อเรา", action: onOpenContact, isActive: false },
  ];

  const username =
    userPlan?.username || user?.name || user?.email?.split("@")[0] || "ผู้ใช้งาน";
  const userEmail = user?.email || "";
  const avatarUrl =
    userPlan?.avatarUrl ||
    getAvatarUrl(
      userPlan?.username || user?.name || user?.email?.split("@")[0] || user?.id || "guest"
    );
  const initialChar = (username.charAt(0) || "U").toUpperCase();
  const balance =
    userPlan?.balance !== undefined
      ? Math.floor(userPlan.balance)
      : user?.balance !== undefined
      ? Math.floor(user.balance)
      : 0;

  return (
    <>
      {/* Apple-style Frosted Translucent Navigation Bar */}
      <header className="fixed top-0 left-0 right-0 z-50 h-[54px] sm:h-[58px] bg-bg/80 backdrop-blur-2xl border-b border-separator select-none transition-colors">
        <div className="max-w-6xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-4">
          
          {/* Left: Brand Logo & Apple-Style Clean Links */}
          <div className="flex items-center gap-6 lg:gap-8 min-w-0">
            {/* Logo Button */}
            <button
              onClick={() => {
                setActiveView("home");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="flex items-center cursor-pointer transition-transform duration-200 hover:opacity-85 active:scale-[0.98] rounded-full focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none shrink-0"
              aria-label="หน้าแรก Astrax"
            >
              <DevLogo className="h-8 sm:h-9 w-auto" />
            </button>

            {/* Main Navigation Links directly beside Logo */}
            <nav
              aria-label="เมนูนำทางหลัก"
              className="hidden lg:flex items-center gap-1"
            >
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    if (link.action) {
                      link.action();
                    } else if (link.view) {
                      setActiveView(link.view);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }
                  }}
                  className={`px-3 py-1 rounded-full text-xs font-medium tracking-normal transition-all duration-150 cursor-pointer active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none ${
                    link.isActive
                      ? "text-label font-medium bg-surface-2"
                      : "text-label-2 hover:text-label hover:bg-surface-2/60"
                  }`}
                >
                  <span>{link.label}</span>
                </button>
              ))}

              {isAdmin && (
                <button
                  onClick={() => {
                    setActiveView("admin");
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium transition-all duration-150 cursor-pointer ml-1 active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-warning focus-visible:outline-none ${
                    activeView === "admin"
                      ? "bg-warning/15 text-warning border border-warning/25"
                      : "text-warning/80 hover:text-warning hover:bg-warning/10"
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>จัดการระบบ</span>
                </button>
              )}
            </nav>
          </div>

          {/* Right: Search, Theme Toggle, Balance & Apple User Profile */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Minimal Search Button */}
            <button
              onClick={onOpenSearch}
              className="w-8 h-8 rounded-full flex items-center justify-center text-label-2 hover:text-label hover:bg-surface-2 transition-all duration-150 cursor-pointer active:scale-95 focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none"
              aria-label="ค้นหาสินค้า (กด /)"
              title="ค้นหาสินค้า (กด /)"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Theme Switcher Button */}
            <button
              onClick={(e) => toggleTheme(e)}
              className="w-8 h-8 rounded-full flex items-center justify-center text-label-2 hover:text-label hover:bg-surface-2 transition-all duration-150 cursor-pointer active:scale-95 focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none relative overflow-hidden"
              aria-label={theme === "dark" ? "เปลี่ยนเป็นโหมดสว่าง" : "เปลี่ยนเป็นโหมดมืด"}
              title={theme === "dark" ? "เปลี่ยนเป็นโหมดสว่าง" : "เปลี่ยนเป็นโหมดมืด"}
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={theme}
                  initial={{ y: -10, opacity: 0, scale: 0.7 }}
                  animate={{ y: 0, opacity: 1, scale: 1 }}
                  exit={{ y: 10, opacity: 0, scale: 0.7 }}
                  transition={{ duration: 0.15 }}
                  className="flex items-center justify-center"
                >
                  {theme === "dark" ? (
                    <Sun className="w-4 h-4 text-label-2" />
                  ) : (
                    <Moon className="w-4 h-4 text-label-2" />
                  )}
                </motion.div>
              </AnimatePresence>
            </button>

            {/* Apple Wallet-Style Balance Pill */}
            {user && (
              <button
                onClick={() => {
                  setActiveView("wallet");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="h-8 px-3 rounded-full bg-surface-2 hover:bg-surface border border-separator text-label transition-all duration-150 cursor-pointer active:scale-[0.98] flex items-center gap-1.5 focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none"
                aria-label={`ยอดเงินคงเหลือ ฿${balance.toLocaleString()} คลิกเพื่อเติมเงิน`}
                title="ยอดเงินคงเหลือ คลิกเพื่อเติมเงิน"
              >
                <Wallet className="w-3.5 h-3.5 text-link shrink-0" />
                <span className="font-sans tabular-nums font-medium text-xs text-label">฿{balance.toLocaleString()}</span>
              </button>
            )}

            {/* Apple User Dropdown */}
            {user ? (
              <div className="relative hidden lg:block" ref={userMenuRef}>
                <button
                  onClick={() => setUserDropdownOpen(!isUserDropdownOpen)}
                  className="h-8 pl-1.5 pr-2.5 rounded-full hover:bg-surface-2 border border-separator transition-all duration-150 cursor-pointer active:scale-[0.98] flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none"
                  aria-expanded={isUserDropdownOpen}
                  aria-haspopup="true"
                  aria-label="เมนูผู้ใช้งาน"
                >
                  <div className="w-5 h-5 rounded-full overflow-hidden bg-surface-2 flex items-center justify-center shrink-0">
                    {userPlan?.avatarUrl ? (
                      <img
                        src={userPlan.avatarUrl}
                        alt={username}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full bg-accent text-white font-medium text-xs flex items-center justify-center">
                        {initialChar}
                      </div>
                    )}
                  </div>
                  <span className="text-xs font-medium text-label max-w-[100px] truncate">
                    {username}
                  </span>
                  <ChevronDown
                    className={`w-3 h-3 text-label-3 transition-transform duration-200 ${
                      isUserDropdownOpen ? "rotate-180 text-label" : ""
                    }`}
                  />
                </button>

                {/* Apple Frosted Dropdown Card */}
                {isUserDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-surface/95 backdrop-blur-2xl border border-separator shadow-2xl p-2 z-50 text-label select-none animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="px-3 py-2 rounded-xl bg-surface-2 mb-1">
                      <p className="text-xs font-medium truncate text-label">{username}</p>
                      {userEmail && <p className="text-xs text-label-2 truncate">{userEmail}</p>}
                    </div>

                    <div className="space-y-0.5 text-xs">
                      <button
                        onClick={() => {
                          setActiveView("profile");
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-label-2 hover:text-label hover:bg-surface-2 transition-colors cursor-pointer"
                      >
                        <User className="w-4 h-4 text-label-3" />
                        <span>บัญชีของฉัน</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveView("history");
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-label-2 hover:text-label hover:bg-surface-2 transition-colors cursor-pointer"
                      >
                        <ShoppingBag className="w-4 h-4 text-label-3" />
                        <span>ประวัติการซื้อ</span>
                      </button>

                      <button
                        onClick={() => {
                          setActiveView("wallet");
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-label-2 hover:text-label hover:bg-surface-2 transition-colors cursor-pointer"
                      >
                        <CreditCard className="w-4 h-4 text-label-3" />
                        <span>เติมเงิน</span>
                      </button>

                      {isAdmin && (
                        <button
                          onClick={() => {
                            setActiveView("admin");
                            setUserDropdownOpen(false);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-warning hover:bg-warning/10 transition-colors cursor-pointer"
                        >
                          <ShieldCheck className="w-4 h-4 text-warning" />
                          <span>จัดการระบบแอดมิน</span>
                        </button>
                      )}

                      <div className="my-1 border-t border-separator" />

                      <button
                        onClick={() => {
                          setUserDropdownOpen(false);
                          onLogout();
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-danger hover:text-danger hover:bg-danger/10 transition-colors cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>ออกจากระบบ</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => {
                  setActiveView("login");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="hidden sm:inline-flex items-center gap-1.5 h-8 px-4 rounded-full bg-accent hover:bg-accent-hover text-white text-xs font-medium transition-all duration-150 cursor-pointer shadow-sm hover:scale-[1.02] active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>เข้าสู่ระบบ</span>
              </button>
            )}

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden w-8 h-8 rounded-full flex items-center justify-center text-label-2 hover:text-label hover:bg-surface-2 transition-all duration-150 cursor-pointer active:scale-95 focus-visible:ring-2 focus-visible:ring-accent focus-visible:outline-none"
              aria-label={isMobileMenuOpen ? "ปิดเมนู" : "เปิดเมนู"}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-drawer"
              title="เมนู"
            >
              {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Spacer to prevent content overlap */}
      <div className="h-[54px] sm:h-[58px] w-full shrink-0" aria-hidden="true" />
    </>
  );
};

export default HeaderNavbar;

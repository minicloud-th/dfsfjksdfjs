import React, { useState, useEffect } from 'react';
import { ShoppingCart, Key, CreditCard, Gift, Star, History, ChevronRight, ChevronLeft, Receipt, Calendar } from 'lucide-react';
import { ReceiptModal } from './modals/ReceiptModal';
import { motion, AnimatePresence } from 'motion/react';
import { AnimatedScroll } from './AnimatedScroll';
import { Skeleton } from './ui/Skeleton';

interface HistoryViewProps {
  purchaseHistory?: any[];
  topupHistory?: any[];
  usedKeysHistory?: any[];
  defaultTab?: string | null;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ 
  purchaseHistory = [], 
  topupHistory = [], 
  usedKeysHistory = [], 
  defaultTab = null 
}) => {
  const [currentCategory, setCurrentCategory] = useState<string | null>(defaultTab);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (currentCategory) {
      setIsLoading(true);
      const timer = setTimeout(() => setIsLoading(false), 150);
      return () => clearTimeout(timer);
    }
  }, [currentCategory]);

  const categories = [
    {
      id: 'normal_product',
      title: 'ประวัติการซื้อสินค้า',
      subtitle: 'Order History',
      icon: ShoppingCart,
      bg: 'bg-blue-500/10 border border-blue-500/20 text-blue-400',
      color: 'text-blue-400'
    },
    {
      id: 'topup_slip',
      title: 'ประวัติการเติมเงิน (โอนเงิน / สแกนสลิป)',
      subtitle: 'Bank Slip Scanner History',
      icon: CreditCard,
      bg: 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400',
      color: 'text-emerald-400'
    }
  ];

  const getStatusBadge = (status: string) => {
    switch(status?.toLowerCase()) {
      case 'success':
        return <span className="bg-success/15 text-success px-3 py-1 text-xs font-medium border border-success/25 rounded-full flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-success rounded-full"></div>สำเร็จ</span>;
      case 'pending':
        return <span className="bg-warning/15 text-warning px-3 py-1 text-xs font-medium border border-warning/25 rounded-full flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-warning rounded-full animate-pulse"></div>รอดำเนินการ</span>;
      case 'failed':
        return <span className="bg-danger/15 text-danger px-3 py-1 text-xs font-medium border border-danger/25 rounded-full flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-danger rounded-full"></div>ล้มเหลว</span>;
      default:
        return <span className="bg-surface-2 text-label-2 px-3 py-1 text-xs font-medium border border-separator rounded-full flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-label-3 rounded-full"></div>{status || 'สำเร็จ'}</span>;
    }
  };

  const getFilteredData = (categoryId: string) => {
    switch(categoryId) {
      case 'normal_product':
        return purchaseHistory.filter(p => !p.is_special).map(p => ({ ...p, type: 'normal_product', title: p.productName || 'ซื้อสินค้า', icon: ShoppingCart, color: 'text-link', bg: 'bg-accent/15 border border-accent/25', money: -(p.price || 0), date: p.date || p.timestamp }));
      case 'special_product':
        return purchaseHistory.filter(p => p.is_special).map(p => ({ ...p, type: 'special_product', title: p.productName || 'สินค้าพิเศษ', icon: Star, color: 'text-warning', bg: 'bg-warning/15 border border-warning/25', money: -(p.price || 0), date: p.date || p.timestamp }));
      case 'topup_gift':
        return topupHistory.filter(t => t.method?.toLowerCase().includes('gift') || t.method?.toLowerCase().includes('อั่งเปา')).map(t => ({ ...t, type: 'topup_gift', title: 'TrueMoney Wallet (อั่งเปา)', icon: Gift, color: 'text-warning', bg: 'bg-warning/15 border border-warning/25', money: t.amount, date: t.date || t.timestamp }));
      case 'topup_slip':
        return topupHistory.map(t => ({ ...t, type: 'topup_slip', title: t.title || t.method || 'โอนผ่านธนาคาร (สแกนสลิป)', icon: CreditCard, color: 'text-success', bg: 'bg-success/15 border border-success/25', money: t.amount || t.money, date: t.date || t.timestamp }));
      default:
        return [];
    }
  };

  const currentCategoryData = categories.find(c => c.id === currentCategory);
  const data = currentCategory ? getFilteredData(currentCategory) : [];

  return (
    <AnimatedScroll direction="up" hideOnScroll={true}>
      <div className="w-full max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-label min-h-[85vh]">
        {/* Header Title */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-separator text-link text-xs font-medium mb-2">
              <History className="w-3.5 h-3.5" />
              <span>Activity Log</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-label tracking-tight">
              ประวัติการทำรายการ
            </h1>
            <p className="text-label-2 text-xs sm:text-sm font-normal mt-1">
              ตรวจสอบประวัติการสั่งซื้อ และเติมเงินทั้งหมดของคุณ
            </p>
          </div>
        </div>

        {/* View Selection or Category View */}
        {!currentCategory ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {categories.map((category, idx) => {
              const Icon = category.icon;
              return (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: idx * 0.05 }}
                  whileHover={{ y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setCurrentCategory(category.id)}
                  className="bg-surface border border-separator hover:border-separator/80 p-6 rounded-3xl cursor-pointer group relative overflow-hidden transition-all shadow-md"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-surface-2 text-label flex items-center justify-center shrink-0 shadow-sm border border-separator">
                      <Icon className="w-6 h-6 text-link" strokeWidth={2} />
                    </div>
                    <div className="w-8 h-8 rounded-full bg-surface-2 border border-separator flex items-center justify-center text-label-2 group-hover:text-label transition-colors">
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="text-base sm:text-lg font-semibold text-label mb-1 group-hover:text-link transition-colors">
                    {category.title}
                  </h3>
                  <p className="text-xs text-label-2 font-normal">
                    {category.subtitle}
                  </p>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Top Return & Header */}
            <div className="flex items-center justify-between">
              <button 
                onClick={() => setCurrentCategory(null)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-surface-2 hover:bg-surface border border-separator text-label-2 hover:text-label transition-all font-medium text-xs cursor-pointer active:scale-95 shadow-sm"
              >
                <ChevronLeft className="w-4 h-4 text-link" />
                <span>ย้อนกลับไปหมวดหมู่ทั้งหมด</span>
              </button>

              <div className="flex items-center gap-2 px-3.5 py-1.5 bg-surface-2 border border-separator rounded-full text-xs text-label-2">
                <span>ทั้งหมด: <strong className="text-label font-sans tabular-nums">{data.length}</strong> รายการ</span>
              </div>
            </div>

            {/* List Table / Card */}
            <div className="bg-surface border border-separator rounded-3xl overflow-hidden p-4 sm:p-6 shadow-xl">
              {isLoading ? (
                <div className="space-y-3 py-4">
                  <div className="h-16 bg-surface-2 rounded-2xl animate-pulse" />
                  <div className="h-16 bg-surface-2 rounded-2xl animate-pulse" />
                  <div className="h-16 bg-surface-2 rounded-2xl animate-pulse" />
                </div>
              ) : data.length === 0 ? (
                <div className="text-center py-16">
                  <History className="w-12 h-12 text-label-3 mx-auto mb-3" />
                  <h3 className="text-base font-semibold text-label mb-1">ยังไม่มีประวัติในหมวดหมู่นี้</h3>
                  <p className="text-xs text-label-2">เมื่อคุณทำรายการ ข้อมูลจะแสดงที่นี่โดยอัตโนมัติ</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {data.map((item: any, i: number) => {
                    const dateStr = item.date ? new Date(item.date).toLocaleString('th-TH') : '-';
                    const displayBill = item.billNumber || `#${(item.id || '000000').substring(0, 8).toUpperCase()}`;

                    return (
                      <div 
                        key={item.id || i}
                        className="py-3.5 px-3.5 sm:px-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-surface-2 border border-separator hover:border-separator/80 rounded-2xl transition-colors"
                      >
                        <div className="flex items-center gap-3.5">
                          <div className="w-11 h-11 rounded-2xl bg-surface text-label flex items-center justify-center shrink-0 shadow-sm border border-separator">
                            {currentCategoryData ? <currentCategoryData.icon className="w-5 h-5 text-link" strokeWidth={2} /> : <History className="w-5 h-5 text-link" strokeWidth={2} />}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm sm:text-base font-semibold text-label">
                                {item.title || item.productName || 'รายการ'}
                              </span>
                              <span className="text-xs font-sans tabular-nums text-label-2 bg-surface px-2.5 py-0.5 rounded-full border border-separator">
                                {displayBill}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-xs text-label-2 mt-1">
                              <Calendar className="w-3.5 h-3.5 text-label-3" />
                              <span>{dateStr}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 self-end sm:self-auto">
                          {item.money !== undefined && item.money !== 0 && (
                            <span className={`font-sans tabular-nums font-semibold text-sm sm:text-base ${item.money > 0 ? 'text-success' : 'text-danger'}`}>
                              {item.money > 0 ? `+฿${item.money.toLocaleString()}` : `-฿${Math.abs(item.money).toLocaleString()}`}
                            </span>
                          )}

                          {getStatusBadge(item.status || 'success')}

                          <button 
                            onClick={() => setSelectedItem(item)}
                            className="p-2.5 bg-surface hover:bg-surface-2 text-label-2 hover:text-label border border-separator rounded-full transition-all active:scale-95 cursor-pointer"
                            title="ดูใบเสร็จ"
                          >
                            <Receipt className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* Receipt Modal */}
        {selectedItem && (
          <ReceiptModal 
            selectedItem={selectedItem} 
            setSelectedItem={setSelectedItem} 
          />
        )}
      </div>
    </AnimatedScroll>
  );
};

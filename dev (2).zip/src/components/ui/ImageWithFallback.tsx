import React, { useState } from 'react';
import { ImageIcon } from 'lucide-react';

interface ImageWithFallbackProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackSrc?: string;
  fallbackIcon?: React.ReactNode;
}

export const ImageWithFallback: React.FC<ImageWithFallbackProps> = ({
  src,
  alt,
  fallbackSrc = '/placeholder.svg',
  fallbackIcon,
  className = '',
  loading = 'lazy',
  ...props
}) => {
  const [error, setError] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (error || !src) {
    if (fallbackIcon) {
      return (
        <div className={`flex items-center justify-center bg-zinc-900 border border-white/[0.08] text-zinc-500 ${className}`}>
          {fallbackIcon}
        </div>
      );
    }
    return (
      <img
        src={fallbackSrc}
        alt={alt || 'Fallback image'}
        className={className}
        loading={loading}
        {...props}
      />
    );
  }

  return (
    <img
      src={src}
      alt={alt || ''}
      className={`${className} ${!loaded ? 'opacity-90' : 'opacity-100'} transition-opacity duration-300`}
      loading={loading}
      onLoad={() => setLoaded(true)}
      onError={() => setError(true)}
      {...props}
    />
  );
};

export default ImageWithFallback;

import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, FileText } from 'lucide-react';
import Markdown from 'react-markdown';

interface PageViewProps {
  page: { title: string; content: string; slug: string } | null;
  onBack: () => void;
}

export const PageView: React.FC<PageViewProps> = ({ page, onBack }) => {
  if (!page) return null;

  return (
    <div className="w-full animate-in fade-in duration-500 max-w-4xl mx-auto py-8">
      <div className="flex items-center gap-2 mb-8 text-sm">
        <button onClick={onBack} className="text-zinc-400 hover:text-white transition-colors flex items-center gap-1.5 font-bold px-4 py-2 bg-[#141414] border border-[#2A2A2A] rounded-full cursor-pointer active:scale-95">
          <ArrowLeft className="w-4 h-4" />
          <span>กลับหน้าหลัก</span>
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#141414] border border-[#2A2A2A] overflow-hidden p-8 md:p-12 min-h-[60vh] rounded-3xl shadow-xl"
      >
        <h1 className="text-2xl sm:text-3xl font-black text-white mb-8 border-b border-[#262626] pb-6 flex items-center gap-3">
           <FileText className="w-7 h-7 text-blue-500 hidden sm:block" />
           <span>{page.title.replace(/^#+\s*/, '')}</span>
        </h1>
        
        <div className="prose prose-zinc max-w-none prose-headings:font-black prose-a:text-blue-600 hover:prose-a:text-[#1D4ED8]">
           <div className="markdown-body">
             <Markdown>{page.content || '*ไม่มีเนื้อหา*'}</Markdown>
           </div>
        </div>
      </motion.div>
    </div>
  );
};

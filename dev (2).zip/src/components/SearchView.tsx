import React, { useState, useEffect } from 'react';
import { Search, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { ProductCard } from './ProductCard';
import { ProductCardSkeleton } from './ui/Skeleton';

interface SearchViewProps {
  products: any[];
  isLoading?: boolean;
  onBack: () => void;
  onProductClick: (id: string) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({ 
  products, 
  isLoading = false,
  onBack, 
  onProductClick 
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 250);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(debouncedQuery.toLowerCase()) || 
    (p.description && p.description.toLowerCase().includes(debouncedQuery.toLowerCase())) ||
    (p.details && p.details.toLowerCase().includes(debouncedQuery.toLowerCase()))
  );

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="max-w-5xl mx-auto w-full p-4 sm:p-6 lg:p-8 font-sans text-label min-h-[85vh]"
    >
      {/* Search Header Bar */}
      <div className="flex items-center gap-3 sm:gap-4 mb-8">
        <button 
          onClick={onBack}
          aria-label="ย้อนกลับ"
          className="w-10 h-10 bg-surface hover:bg-surface-2 border border-separator rounded-full flex items-center justify-center text-label-2 hover:text-label transition-all active:scale-95 cursor-pointer shrink-0 shadow-sm"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="w-4 h-4 text-link" />
          </div>
          <input 
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="พิมพ์ชื่อสินค้า หรือคีย์เวิร์ดที่ต้องการค้นหา..."
            className="w-full bg-surface border border-separator py-2.5 pl-11 pr-5 outline-none focus:border-accent rounded-full transition-all text-label placeholder:text-label-3 text-sm font-normal shadow-sm"
            autoFocus
          />
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-base sm:text-xl font-semibold text-label flex items-center gap-2">
          <Search className="w-4 h-4 text-link" />
          <span>ผลการค้นหา {searchQuery && <span className="text-label-2 font-normal">สำหรับ "{searchQuery}"</span>}</span>
        </h2>
        <span className="text-xs text-label-2 font-sans tabular-nums">
          พบ {filteredProducts.length} รายการ
        </span>
      </div>

      {/* Results Grid */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-3 sm:gap-5">
            <ProductCardSkeleton count={6} />
          </div>
        ) : searchQuery && filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-surface border border-separator rounded-3xl p-8 shadow-sm">
            <Search className="w-12 h-12 text-label-3 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-label mb-1">ไม่พบสินค้าที่คุณค้นหา</h3>
            <p className="text-xs text-label-2 font-normal">ลองเปลี่ยนคำค้นหา หรือค้นหาด้วยชื่อหมวดหมู่อื่นๆ</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-3 sm:gap-5">
            {filteredProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onClick={onProductClick}
              />
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default SearchView;

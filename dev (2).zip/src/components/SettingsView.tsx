import React, { useState, useEffect } from 'react';
import { Shield, Key, Trash2, Lock, ShieldAlert, Settings, ShieldCheck, UserCheck, Eye, EyeOff } from 'lucide-react';
import Swal from 'sweetalert2';
import axios from 'axios';
import { AnimatedScroll } from './AnimatedScroll';
import { motion, AnimatePresence } from 'motion/react';

interface SettingsViewProps {
  user?: any;
  setActiveView: (view: any) => void;
  useCustomCursor?: boolean;
  toggleCustomCursor?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ setActiveView, user, useCustomCursor, toggleCustomCursor }) => {
  const [currentTab, setCurrentTab] = useState<'password' | 'delete' | 'preferences'>('password');
  const [isLoading, setIsLoading] = useState(false);
  
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 150);
    return () => clearTimeout(timer);
  }, [currentTab]);

  const handleChangePassword = async () => {
    if (!oldPassword) {
      return Swal.fire({ icon: 'error', title: 'ข้อผิดพลาด', text: 'กรุณากรอกรหัสผ่านเดิม', background: '#0c0c12', color: '#fff' });
    }
    if (!newPassword || !confirmPassword) {
      return Swal.fire({ icon: 'error', title: 'ข้อผิดพลาด', text: 'กรุณากรอกข้อมูลให้ครบถ้วน', background: '#0c0c12', color: '#fff' });
    }
    if (newPassword !== confirmPassword) {
      return Swal.fire({ icon: 'error', title: 'ข้อผิดพลาด', text: 'รหัสผ่านใหม่และยืนยันรหัสผ่านไม่ตรงกัน', background: '#0c0c12', color: '#fff' });
    }

    try {
      setIsLoading(true);
      const { supabase } = await import('../lib/supabase');
      
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user?.email || '',
        password: oldPassword,
      });

      if (signInError) {
        throw new Error('รหัสผ่านเดิมไม่ถูกต้อง');
      }

      const { error } = await supabase.auth.updateUser({ password: newPassword });
      
      if (error) throw error;

      Swal.fire({
        title: 'เปลี่ยนรหัสผ่านสำเร็จ',
        text: 'รหัสผ่านของคุณถูกอัปเดตเรียบร้อยแล้ว',
        icon: 'success',
        background: '#0c0c12',
        color: '#fff',
        confirmButtonColor: '#2563eb'
      });
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (error: any) {
      Swal.fire({
         title: 'เกิดข้อผิดพลาด',
         text: error.message || 'ไม่สามารถเปลี่ยนรหัสผ่านได้',
         icon: 'error',
         background: '#0c0c12',
         color: '#fff',
         confirmButtonColor: '#2563eb'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    const { value: password } = await Swal.fire({
      title: 'ยืนยันการลบบัญชี',
      text: 'กรุณากรอกรหัสผ่านเพื่อยืนยันการลบบัญชี ข้อมูลทั้งหมดจะถูกลบถาวร',
      input: 'password',
      inputPlaceholder: 'รหัสผ่านของคุณ',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#18181b',
      confirmButtonText: 'ลบบัญชีถาวร',
      cancelButtonText: 'ยกเลิก',
      background: '#0c0c12',
      color: '#fff',
      customClass: {
        input: 'bg-[#181820] border-white/10 text-white rounded-xl'
      }
    });

    if (password) {
      try {
        setIsLoading(true);
        const { supabase } = await import('../lib/supabase');
        
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: user?.email || '',
          password: password,
        });

        if (signInError) {
          throw new Error('รหัสผ่านไม่ถูกต้อง');
        }

        await axios.delete(`/api/users/${user.id}`);
        await supabase.auth.signOut();
        
        Swal.fire({
          title: 'ลบบัญชีสำเร็จ',
          text: 'บัญชีของคุณถูกลบออกจากระบบเรียบร้อยแล้ว',
          icon: 'success',
          background: '#0c0c12',
          color: '#fff',
          confirmButtonColor: '#2563eb'
        }).then(() => {
          window.location.reload();
        });
      } catch (error: any) {
        Swal.fire({
          title: 'เกิดข้อผิดพลาด',
          text: error.message || 'ไม่สามารถลบบัญชีได้',
          icon: 'error',
          background: '#0c0c12',
          color: '#fff',
          confirmButtonColor: '#2563eb'
        });
      } finally {
        setIsLoading(false);
      }
    }
  };

  return (
    <AnimatedScroll direction="up" hideOnScroll={true}>
      <div className="w-full max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-label min-h-[85vh]">
        {/* Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-2 border border-separator text-link text-xs font-medium mb-2">
            <Settings className="w-3.5 h-3.5" />
            <span>Account Settings</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-label tracking-tight">
            การตั้งค่าบัญชี
          </h1>
          <p className="text-label-2 text-xs sm:text-sm font-normal mt-1">
            จัดการรหัสผ่าน ความปลอดภัย และการตั้งค่าความเป็นส่วนตัวของคุณ
          </p>
        </div>

        {/* Apple Segmented Controls */}
        <div className="flex gap-1.5 p-1 bg-surface-2 border border-separator rounded-full mb-8 backdrop-blur-xl w-fit">
          <button
            onClick={() => setCurrentTab('password')}
            className={`px-5 py-2 rounded-full text-xs font-medium transition-all cursor-pointer ${
              currentTab === 'password'
                ? 'bg-accent text-white shadow-sm'
                : 'text-label-2 hover:text-label hover:bg-surface'
            }`}
          >
            เปลี่ยนรหัสผ่าน
          </button>
          <button
            onClick={() => setCurrentTab('delete')}
            className={`px-5 py-2 rounded-full text-xs font-medium transition-all cursor-pointer ${
              currentTab === 'delete'
                ? 'bg-danger text-white shadow-sm'
                : 'text-label-2 hover:text-danger hover:bg-surface'
            }`}
          >
            ลบบัญชี
          </button>
        </div>

        {/* Tab Content */}
        <div className="bg-surface border border-separator rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          {currentTab === 'password' && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-xl"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-surface-2 border border-separator rounded-2xl text-link">
                  <Lock className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-semibold text-label">เปลี่ยนรหัสผ่านใหม่</h2>
                  <p className="text-label-2 text-xs font-normal">กรุณาตั้งรหัสผ่านที่มีความยาวอย่างน้อย 6 ตัวอักษร</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-label-2 mb-2 ml-1">
                    รหัสผ่านเดิม
                  </label>
                  <input
                    type="password"
                    value={oldPassword}
                    onChange={(e) => setOldPassword(e.target.value)}
                    placeholder="กรอกรหัสผ่านปัจจุบันของคุณ"
                    className="w-full bg-surface-2 border border-separator focus:border-accent rounded-2xl p-4 text-label text-sm outline-none transition-all placeholder:text-label-3"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-label-2 mb-2 ml-1">
                    รหัสผ่านใหม่
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="กรอกรหัสผ่านใหม่"
                    className="w-full bg-surface-2 border border-separator focus:border-accent rounded-2xl p-4 text-label text-sm outline-none transition-all placeholder:text-label-3"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-label-2 mb-2 ml-1">
                    ยืนยันรหัสผ่านใหม่
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="กรอกรหัสผ่านใหม่อีกครั้ง"
                    className="w-full bg-surface-2 border border-separator focus:border-accent rounded-2xl p-4 text-label text-sm outline-none transition-all placeholder:text-label-3"
                  />
                </div>

                <div className="pt-4">
                  <button
                    onClick={handleChangePassword}
                    disabled={isLoading}
                    className="w-full py-3.5 rounded-full bg-accent hover:bg-accent-hover text-white font-medium text-sm transition-all shadow-sm active:scale-[0.98] cursor-pointer disabled:opacity-50"
                  >
                    {isLoading ? 'กำลังบันทึก...' : 'อัปเดตรหัสผ่าน'}
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {currentTab === 'delete' && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-xl"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-danger/15 border border-danger/25 rounded-2xl text-danger">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-semibold text-label">ลบบัญชีผู้ใช้งานถาวร</h2>
                  <p className="text-label-2 text-xs font-normal">การดำเนินการนี้จะไม่สามารถย้อนกลับได้</p>
                </div>
              </div>

              <div className="bg-danger/10 border border-danger/25 p-5 rounded-2xl mb-6">
                <p className="text-xs sm:text-sm text-danger leading-relaxed font-normal">
                  เมื่อคุณลบบัญชี ข้อมูลทั้งหมดรวมถึงยอดเงินคงเหลือ ประวัติการสั่งซื้อ และประวัติการ Redeem คีย์ จะถูกลบทิ้งอย่างถาวร
                </p>
              </div>

              <button
                onClick={handleDeleteAccount}
                disabled={isLoading}
                className="w-full py-3.5 rounded-full bg-danger hover:bg-danger/90 text-white font-medium text-sm transition-all shadow-sm active:scale-[0.98] cursor-pointer disabled:opacity-50"
              >
                {isLoading ? 'กำลังลบบัญชี...' : 'ยืนยันการลบบัญชีถาวร'}
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </AnimatedScroll>
  );
};

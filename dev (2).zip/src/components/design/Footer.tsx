import React from "react";
import { DevLogo } from "../DevLogo";
import { ShieldCheck, Lock } from "lucide-react";

interface FooterProps {
  setActiveView: (view: string) => void;
  siteSettings?: any;
  onOpenPrivacy?: () => void;
  onOpenTerms?: () => void;
  onOpenContact?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  setActiveView,
  siteSettings,
  onOpenPrivacy,
  onOpenTerms,
  onOpenContact,
}) => {
  const currentYear = new Date().getFullYear();
  const siteName = siteSettings?.site_name || "Astrax";

  return (
    <footer className="w-full border-t border-separator bg-surface mt-20 py-10 text-label-2 select-none">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Top Disclaimer / Trust Note */}
        <div className="pb-8 border-b border-separator text-xs text-label-3 leading-relaxed space-y-1.5">
          <p>
            * ระบบจัดส่งสินค้าเป็นแบบอัตโนมัติ 100% ภายหลังการชำระเงินสำเร็จ ไอดีและโค้ดจะถูกส่งมอบเข้าสู่ประวัติการสั่งซื้อทันที
          </p>
          <p>
            บริการทั้งหมดดำเนินการภายใต้ระบบความปลอดภัยระดับสากล และรองรับการทำรายการผ่าน PromptPay QR อัตโนมัติ ปลอดภัยตลอด 24 ชั่วโมง
          </p>
        </div>

        {/* Bottom Bar: Copyright, Brand & Clean Links */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          {/* Brand & Copyright */}
          <div className="flex items-center gap-3">
            <div
              onClick={() => {
                setActiveView("home");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="cursor-pointer hover:opacity-80 transition-opacity"
            >
              <DevLogo className="h-6 sm:h-7 w-auto" />
            </div>
            <p className="text-label-2 text-xs">
              Copyright © {currentYear} {siteName}. All rights reserved.
            </p>
          </div>

          {/* Apple-style Flat Text Links */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-label-2 text-xs">
            <button
              onClick={() => {
                if (onOpenTerms) {
                  onOpenTerms();
                } else {
                  setActiveView("terms");
                }
              }}
              className="hover:text-label transition-colors cursor-pointer"
            >
              เงื่อนไขการใช้งาน
            </button>
            <span className="text-label-3">·</span>
            <button
              onClick={() => {
                if (onOpenPrivacy) {
                  onOpenPrivacy();
                } else {
                  setActiveView("privacy");
                }
              }}
              className="hover:text-label transition-colors cursor-pointer"
            >
              นโยบายความเป็นส่วนตัว
            </button>
            <span className="text-label-3">·</span>
            <button
              onClick={() => {
                if (onOpenContact) {
                  onOpenContact();
                } else {
                  setActiveView("contact");
                }
              }}
              className="hover:text-label transition-colors cursor-pointer"
            >
              ติดต่อฝ่ายสนับสนุน
            </button>
            <span className="text-label-3">·</span>
            <div className="flex items-center gap-1.5 text-xs text-label-2 font-sans tabular-nums">
              <Lock className="w-3.5 h-3.5 text-success" />
              <span>SSL 256-Bit</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

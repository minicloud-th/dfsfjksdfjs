import React, { useState } from 'react';
import { Product } from '../types';
import { ArrowLeft, CheckCircle2, ChevronRight, ShoppingCart, ShieldCheck, Zap } from 'lucide-react';
import Swal from 'sweetalert2';

interface ProductDetailViewProps {
  product: Product;
  user: any;
  onBack: () => void;
  handlePurchase: (product: Product, quantity: number) => Promise<void>;
  setActiveView: (view: any) => void;
}

export const ProductDetailView: React.FC<ProductDetailViewProps> = ({ 
  product, 
  user, 
  onBack, 
  handlePurchase, 
  setActiveView 
}) => {
  const [purchaseQuantity, setPurchaseQuantity] = useState(1);
  const [isPurchasing, setIsPurchasing] = useState(false);

  const calculateDiscount = (originalPrice?: number, price?: number) => {
    if (!originalPrice || !price || originalPrice <= price) return null;
    return Math.round(((originalPrice - price) / originalPrice) * 100);
  };

  const discount = calculateDiscount(product.originalPrice, product.price);
  const isAvailable = (product.stock || 0) > 0;
  const totalPrice = (product.price || 0) * purchaseQuantity;

  const onConfirmBuy = async () => {
    if (!user) {
      Swal.fire({
        icon: 'info',
        title: 'กรุณาเข้าสู่ระบบ',
        text: 'คุณจำเป็นต้องเข้าสู่ระบบก่อนทำการสั่งซื้อสินค้า',
        confirmButtonText: 'ไปหน้าเข้าสู่ระบบ',
        confirmButtonColor: '#0071E3',
        background: '#161618',
        color: '#fff',
      }).then((res) => {
        if (res.isConfirmed) setActiveView('login');
      });
      return;
    }

    setIsPurchasing(true);
    try {
      await handlePurchase(product, purchaseQuantity);
    } finally {
      setIsPurchasing(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 font-sans text-white">
      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 mb-6 text-xs sm:text-sm">
        <button 
          onClick={onBack} 
          className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-zinc-300 hover:text-white transition-all cursor-pointer active:scale-95"
          title="ย้อนกลับ"
        >
          <ArrowLeft className="w-4 h-4 text-zinc-300" />
        </button>
        <span className="text-zinc-500">/</span>
        <button
          onClick={onBack}
          className="text-zinc-400 hover:text-white transition-colors cursor-pointer text-xs"
        >
          ร้านค้า
        </button>
        <span className="text-zinc-500">/</span>
        <span className="text-zinc-300 font-medium truncate max-w-[200px] sm:max-w-md text-xs">{product.name}</span>
      </div>

      {/* Main Apple Product Card */}
      <div className="rounded-3xl border border-separator bg-surface overflow-hidden flex flex-col md:flex-row shadow-2xl">
        {/* Left: Product Image */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex items-center justify-center bg-bg border-b md:border-b-0 md:border-r border-separator">
          <div className="w-full aspect-square relative rounded-2xl overflow-hidden bg-surface-2 border border-separator/60 p-4 flex items-center justify-center">
            {product.imageUrl ? (
              <img 
                src={product.imageUrl} 
                alt={product.name}
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-label-3 font-semibold text-sm">
                ASTRAX
              </div>
            )}
            {discount && (
              <span className="absolute top-3 left-3 bg-danger/15 border border-danger/25 text-danger font-medium px-2.5 py-0.5 rounded-full text-xs backdrop-blur-md">
                ลด {discount}%
              </span>
            )}
          </div>
        </div>

        {/* Right: Product Info & Actions */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            {/* Status & Category */}
            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
                isAvailable ? 'bg-success/15 text-success border border-success/25' : 'bg-surface-2 text-label-3'
              }`}>
                <CheckCircle2 className="w-3 h-3" />
                <span>{isAvailable ? `มีสินค้า (${product.stock} ชิ้น)` : 'สินค้าหมด'}</span>
              </span>
              {product.tag && (
                <span className="px-3 py-1 rounded-full text-xs font-medium bg-surface-2 text-label-2 border border-separator">
                  {product.tag}
                </span>
              )}
            </div>

            {/* Title */}
            <h1 className="text-xl sm:text-2xl font-semibold text-label tracking-tight leading-snug">
              {product.name}
            </h1>

            {/* Price */}
            <div className="flex items-baseline gap-2.5 pt-1">
              <span className="text-3xl font-semibold text-label font-sans tabular-nums tracking-tight">
                ฿{(product.price || 0).toLocaleString()}
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-sm text-label-3 line-through tabular-nums">
                  ฿{product.originalPrice.toLocaleString()}
                </span>
              )}
            </div>

            {/* Description */}
            <div className="pt-2 text-label-2 text-xs sm:text-sm leading-relaxed border-t border-separator">
              {product.description || 'สินค้าคุณภาพ ส่งมอบทันทีผ่านระบบอัตโนมัติ'}
            </div>

            {/* Guarantees */}
            <div className="grid grid-cols-2 gap-2 pt-2 text-xs text-label-2">
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-link shrink-0" />
                <span>จัดส่งทันที 24 ชม.</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-success shrink-0" />
                <span>รับประกันการใช้งาน</span>
              </div>
            </div>
          </div>

          {/* Quantity & Buy Action */}
          <div className="space-y-4 pt-4 border-t border-separator">
            {isAvailable && (
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-label-2">จำนวนที่ต้องการ</span>
                <div className="flex items-center gap-2 bg-surface-2 border border-separator rounded-full p-1">
                  <button
                    type="button"
                    onClick={() => setPurchaseQuantity(Math.max(1, purchaseQuantity - 1))}
                    className="w-6 h-6 flex items-center justify-center rounded-full bg-surface hover:bg-surface-2 text-label text-xs font-medium transition-colors cursor-pointer active:scale-95"
                  >
                    -
                  </button>
                  <span className="w-6 text-center text-xs font-semibold text-label tabular-nums">
                    {purchaseQuantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setPurchaseQuantity(Math.min(product.stock, purchaseQuantity + 1))}
                    className="w-6 h-6 flex items-center justify-center rounded-full bg-surface hover:bg-surface-2 text-label text-xs font-medium transition-colors cursor-pointer active:scale-95"
                  >
                    +
                  </button>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={onConfirmBuy}
              disabled={!isAvailable || isPurchasing}
              className={`w-full py-3 px-5 rounded-full text-sm font-medium flex items-center justify-center gap-2 transition-all duration-150 cursor-pointer shadow-sm active:scale-98 ${
                isAvailable
                  ? 'bg-accent hover:bg-accent-hover text-white hover:scale-[1.01]'
                  : 'bg-surface-2 text-label-3 cursor-not-allowed'
              }`}
            >
              {isPurchasing ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4" />
                  <span>{isAvailable ? `สั่งซื้อทันที (฿${totalPrice.toLocaleString()})` : 'สินค้าหมดชั่วคราว'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailView;

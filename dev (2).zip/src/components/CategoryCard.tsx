import React from "react";
import { Package, ArrowRight } from "lucide-react";

interface CategoryCardProps {
  title: string;
  label?: string;
  itemCountDesc?: string;
  priceRangeStr?: string;
  bgImage?: string;
  index?: number;
  onClick: () => void;
  accentColor?: string;
  glowColor?: string;
  gradientFrom?: string;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({
  title,
  label,
  itemCountDesc,
  priceRangeStr,
  bgImage,
  onClick,
}) => {
  const count = itemCountDesc?.replace(/[^0-9]/g, "") || "0";

  return (
    <div
      onClick={onClick}
      className="group relative overflow-hidden rounded-3xl border border-white/[0.06] hover:border-white/[0.16] bg-[#161618] hover:bg-[#1c1c1e] transition-all duration-300 flex flex-col cursor-pointer hover:-translate-y-1 hover:shadow-2xl select-none p-4 sm:p-5"
    >
      {/* Banner / Cover */}
      <div className="relative aspect-[16/9] w-full overflow-hidden shrink-0 bg-black/40 rounded-2xl border border-white/[0.04]">
        {bgImage ? (
          <img
            src={bgImage}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90 group-hover:opacity-100"
            referrerPolicy="no-referrer"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-zinc-600">
            <Package className="w-8 h-8 opacity-40" />
          </div>
        )}

        {/* Subtle Vignette Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

        {/* Quiet Category Pill */}
        {label && (
          <div className="absolute top-3 left-3 z-10">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold text-zinc-200 bg-black/60 backdrop-blur-md border border-white/10 shadow-sm">
              {label}
            </span>
          </div>
        )}
      </div>

      {/* Content Area */}
      <div className="mt-4 flex flex-col justify-between flex-1 gap-3">
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-sm sm:text-base font-semibold text-white tracking-tight truncate group-hover:text-[#2997FF] transition-colors">
            {title}
          </h3>
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/[0.06] group-hover:bg-[#0071E3] text-zinc-400 group-hover:text-white flex items-center justify-center transition-all duration-200 shrink-0">
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>

        {/* Stats Bar */}
        <div className="flex items-center justify-between gap-2 text-xs pt-3 border-t border-white/[0.06]">
          <span className="inline-flex items-center gap-1.5 text-zinc-400 text-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>พร้อมส่ง {count} ชิ้น</span>
          </span>

          {priceRangeStr && (
            <span className="text-xs font-semibold text-white">
              {priceRangeStr}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoryCard;
